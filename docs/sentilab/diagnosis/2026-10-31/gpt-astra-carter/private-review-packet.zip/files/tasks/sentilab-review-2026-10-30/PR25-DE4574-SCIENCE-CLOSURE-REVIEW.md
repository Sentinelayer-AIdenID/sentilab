# PR25 de4574 scientific correction review

Exact head: `de4574af5c2061fa0f8bbad76a5c4037899fc1bf`. This closes the two remaining source defects from `PR25-AAAF128-CLOSURE-REVIEW.md`: reference admission after an invalid cheap baseline, and loss of partial timeout output. CPU enforcement, the known `lease(immediate_kill)` integration failure, final CI and numerical execution release are separate and remain open.

## Verified corrections

The actual `run_headroom` now records `reference_skip_reason=cheap_baseline_incomplete` and never enters reference restarts when `_freeze_cheap_baseline` fails. The exact shipping regression preserves the full 24-lane schedule with a remaining reference allowance and forces reproduction disagreement. It completes **768 synthetic calls, zero reference calls**, records the failed baseline and all charges, writes the attempt result and returns INCONCLUSIVE. This addresses the previous case that consumed a 769th reference call without a usable C.

The actual worker opens file-backed binary stdout/stderr before the subprocess invocation. Its timeout path retains byte/text payloads and a structured `EXIT.json`, with `status=timeout`, null return code, timeout duration, payload types and byte counts. The selected exact-source test covers invalid UTF-8 byte payloads, text payloads and absent payloads, as well as the ordinary error path. The readable replacement-decoded text is separate from preserved original binary bytes. No child process executed in these checks.

The previous prospective wire-domain, frozen search-score/reproduction identity, start-bound preregistration and unique-attempt retention closures remain supported by source inspection; unchanged tests for those defects were not repeated. Ascend v3 evidence remains historical INCONCLUSIVE. No measured micro150 result is asserted.

## Numerical representation clarification

An additional synthetic helper case uses C=100.1 and an eligible reference J=96.15. `_v4_verdict` subtracts binary floats and obtains `3.9499999999999886`, returning INCONCLUSIVE for a partial reference. Subtracting the serialized decimal values gives exactly 3.95, the written inclusive threshold.

This is a **low-severity ambiguity in the numerical boundary contract**, not evidence of a measured incorrect result. The exact binary values are slightly below the decimal boundary; the current implementation is consistent with that binary interpretation. Freeze whether the criterion uses those exact binary values or decimal serialization, and test realistic nonzero-baseline equality cases under that choice. If decimal semantics are intended, use exact decimal arithmetic from canonical finite values, rather than widening the threshold with an arbitrary epsilon. Do not change the interpretation after outcomes.

## Evidence and limits

- All **39** source/supporting files in `pr25-de4574-science/all-source-manifest.json` were verified against Git blob IDs and SHA256 hashes before execution.
- Exactly **two selected shipping tests passed**. Their names and output are retained in `targeted-tests.log`; unittest reported 21.746 seconds. No broader previously passed suite was repeated.
- `review_science.py` additionally records the threshold representation example in `science-review-output.json`.
- Total audit elapsed time: **24.34027331 seconds**; measured reviewer process CPU: **13.416314 seconds**. These are review costs, not experiment charges.
- Runtime: WSL Ubuntu 24.04 Python 3.12.3. Temporary source copy used a clearly marked non-executable binary-path file for catalog/source-hash metadata only.
- Real subprocess and worker launch paths were denied, with **zero attempted native launches**, zero HotSpot/model calls and zero CI reruns.
- `ProcessTreeScope` was replaced with an explicit no-op only for these synthetic scientific cases; process control is independently assigned to the CPU reviewer. No affinity, subreaper or CPU-limit claim follows from these tests.

The source/test files and retained historical audit were not edited. This report is a bounded correction review, not a full PR approval, resource-compliance finding, physical validation or permission to execute micro150.
