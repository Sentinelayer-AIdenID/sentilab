# PR25 independent review — fa7ed8f

Exact head: `fa7ed8ff09c35a3745e3e2fef6acfbeac1d1e3a4`  
Base: `691d79be5a2241c366b8122126f0467cb908d668`  
PR: https://github.com/Sentinelayer-AIdenID/sentilab/pull/25  
Reviewer: gpt-astra-carter / requirements_audit  
Scope: committed evidence consistency, pure tests, feasibility and proposed micro150-only PREREG v4. No native/thermal solve, model call, CI rerun, product edit or external post was made for this review.

**Decision: preserve Ascend910 v3 as INCONCLUSIVE; no +1 for micro150 execution or the amendment.** The proposed one-sided early-PASS rule is mathematically defensible in principle, but the current implementation and missing eligibility/budget definitions do not establish its prerequisites. The committed Ascend arithmetic is internally consistent. Its feasible domain also differs from the fixed-initial-wire task used by the live conductor.

## Independently verified recorded evidence

All seven cached files byte-match their immutable Git blobs and manifest SHA256 values. The RESULT's preregistration and runner hashes match the committed files. All 26 nonempty winner design hashes recompute through the exact-head `Design.hash`, and all pass the actual TAP geometry checker, including chiplet dimensions, substrate, bump halos, margin and grid. All 96 recorded cheap reproduction entries equal their returned lane winner's temperature and design hash. This verifies stored values, not an independent thermal rerun. One common solver version and one common problem hash are recorded across the 26 winners; neither identity string alone establishes physical validity or independent reproduction.

| Item | Independently recomputed value |
|---|---:|
| Cheap lanes | 24 = 3 methods × 8 seeds |
| Per cheap lane | 28 search, including initialization, + 4 fresh reproduction entries |
| Cheap calls / reproduction calls | 768 / 96 |
| Random / greedy / short-SA median best | 118.145 / 117.685 / 118.190 °C |
| Frozen cheap median in this record | 117.685 °C |
| Best observed | 116.090 °C, long-SA seed 101 |
| Gap / threshold | 1.595 / 0.800 °C |
| Cheap seed spread | 1.660 °C |
| Long-SA calls | 1,000 / 882 / 0 / 0 |
| Long-SA fresh reproductions | 0 / 0 / 0 / 0 |
| Total calls | 2,650 |
| CPU in RESULT and SPEND | 1,440.294565 seconds |
| CPU above 24-minute fixture limit | 0.294565 seconds |
| Durable active reservation | null |
| Diagnostics | none; declared reference incomplete |
| Protocol verdict | INCONCLUSIVE |

The stored spend equals the sum of stored lane call counts, and RESULT's allocation snapshot equals SPEND. This does not recover raw measurements for all 2,650 calls. Ascend's numerical gap must not be promoted to v3 PASS, nor retrospectively relabeled under v4.

## Findings and release conditions

### P1 — the headroom search does not enforce the fixed initial wire constraint

Relevant source: `sundai_controller/headroom.py:254`, `sundai_controller/experiment.py:25`, `sundai_controller/controller.py:454`, `sundai_hotspot/tap_oracle.py:592`, `sundai_hotspot/tap_oracle.py:639`.

The candidate/controller/oracle path checks TAP geometry but never rejects a candidate for exceeding a frozen wire cap. `_wirelength_mm` computes the weighted mean Manhattan center-distance proxy; it is not an admission constraint. Offline calculation from the exact committed configuration and winner positions gives initial wire 27.6993464052 mm. **25 of 26 stored winners exceed it.** The overall best, seed 101 / hash `32f9304667455368f64cd7b805ea055758d0d9c3fea4a78f444efcc86eb5c60a`, has wire 40.5294117647 mm, a ratio of 1.4631901840 (+46.319%). It has zero fresh reproduction calls.

The live conductor's documented cap is the initial layout's weighted Manhattan proxy. The general plan allows a separately frozen alpha; PR25's prereg does not define one or an explicit relaxation. Therefore this result supports only the geometry-constrained, unrestricted-wire headroom experiment actually run. It cannot establish headroom for the fixed-initial-wire task. This is a domain mismatch, not evidence that PR25 violated an explicit wire clause in its own sparse preregistration.

Before prospective micro150 release, freeze the exact common feasible domain: initial coordinates, catalog, powers/package, connectivity, wire metric and units, alpha/absolute cap, geometry tolerances and objective. Apply it to every cheap/reference candidate before expensive admission and winner eligibility. If unrestricted wire is intended for a separate screen, name that scope explicitly. Do not silently refilter stored Ascend winners: absent full search histories, that does not recover the constrained search experiment.

### P1 — reproduction count does not establish reproducibility or an eligible witness

Relevant source: `sundai_controller/headroom.py:231`, `sundai_controller/headroom.py:326`, `sundai_controller/headroom.py:348`, `sundai_controller/headroom.py:364`.

Every lower `_LaneOracle` return can replace `best_result`, including a reproduction. Cheap reproduction calls compare neither temperature agreement nor solver/problem/evidence identity to the frozen search winner. `complete` only tests the number of calls. The long-SA path requests zero reproductions.

Two actual fake-oracle proofs at this head:

- Search score 100 followed by reproductions [90, 110, 120, 130] is marked complete and returns best 90.
- Reproductions returning a new solver version and `different-problem` at 99 replace the original solver/problem winner at 100 and remain complete.

The recorded Ascend cheap repro values do agree, so these proofs do not allege drift in those 96 stored entries. They show why the proposed partial-reference PASS cannot use the current minimum-ever accumulator as its eligibility test.

Freeze a score/consistency policy and tolerance; retain the search score separately; require matching candidate, fixture/problem, solver/source/grid and evidence identities; verify feasibility and fresh-process reproduction; reserve reproduction calls within the declared caps. The long reference needs an eligible reproduced witness before early PASS. No hidden extra solves may be added to the 9,700 total or the per-fixture schedule.

### P1 for prospective release — the proposed budget and clocks are not implemented

Relevant source: `sundai_controller/headroom.py:146`, `sundai_controller/headroom.py:169`, `sundai_controller/headroom.py:217`, `sundai_controller/headroom.py:587`.

The parser accepts only v1–v3 and ascend910; the CLI accepts only ascend910. The runner always supplies six Ascend centers. Calling the exact-head micro150 geometry constructor with those centers independently raises `TAP layout must provide one center per chiplet` for the eight-chiplet fixture.

Limits are additionally clamped in code to 48 total headroom CPU minutes and 24 per fixture. A document-only v4 cannot enable 72 total / 48 micro minutes. The budget checks an absolute release/deadline and CPU between calls; it does not enforce the accepted independent 90-minute per-job solving-wall ceiling. An admitted evaluation can exceed the CPU cap, as both the stored 0.294565-second overrun and a zero-burn fake-clock proof demonstrate (0.9 seconds at admission, 1.1 after a call under a 1-second limit; the next call is denied). The report correctly acknowledges this behavior.

Pin a defensible in-flight CPU enforcement/reservation policy or explicitly approve and bound the overshoot semantics; do not label between-call admission an absolute CPU maximum. Enforce the independent job wall ceiling and absolute 12:00Z deadline. All constructor/startup/retry/failure work, child CPU and resumed work must remain charged. Retain the existing durable lock and reserve-before-call behavior.

For proposed total headroom 72 minutes, Ascend's stored spend leaves **2,879.705435 seconds = 47.995090583 minutes**, before any other headroom charges. It does not leave a fresh 48 minutes. Proposed aggregate 84 minutes must retain prior preflight costs and any unresolved CI costs; it is not permission to reset either ledger. The 9,700 headroom / 10,000 aggregate solve ceilings remain unchanged. Methods, seeds and cheap 28+4 stay fixed unless explicitly amended.

### P2 — end-of-run hashes can attest different preregistration bytes

Relevant source: `sundai_controller/headroom.py:376`, `sundai_controller/headroom.py:493`.

The run parses preregistration at start but rereads the file for its hash at the end. A fake oracle changing the local fixture file from `k=5` to `k=999` during the first call yields a result that executed k=5 yet records the hash of the k=999 file. Current recorded files match their hashes; this demonstrates a binding failure rather than tampering in Ascend.

Capture immutable preregistration bytes and source identities at admission, hash those captured bytes, and detect changed artifacts before acceptance. Bind the full relevant source/config/binary environment rather than presenting a runner-file hash as full execution provenance.

### P2 — subsequent invocations erase earlier result/history evidence

Relevant source: `sundai_controller/headroom.py:336`, `sundai_controller/headroom.py:514`, `sundai_controller/headroom.py:527`; worker workspace cleanup in `sundai_hotspot/tap_oracle.py:403`.

The lane's signed flight record is closed in memory and discarded from the returned result. Only winners and compact reproduction entries are retained. RESULT/REPORT use fixed filenames and are overwritten on a second invocation; the durable budget survives but per-lane progress does not. The fake proof ran two two-call schedules: the surviving RESULT reported two calls while the retained ledger reported four, and the output directory held only the second RESULT/REPORT. An actual restart after exhaustion can therefore replace prior scientific evidence even while respecting spend.

Use immutable per-invocation/run output directories, append-only proposal/admission/result/reproduction/correction receipts, full raw solver input/output retention and a stable cumulative manifest. Resume from persisted scientific state or record a separately identified new attempt; never silently replace an earlier run. This is also required by the user's complete proposal→review→correction→acceptance and replay/RLAIF evidence goals.

### Clarify diagnostic eligibility

PREREG `rule.best` includes diagnostics, while `extra_diagnostics.note` says diagnostics do not affect PASS/FAIL. The code includes diagnostics in `all_bests` (`headroom.py:473`). No diagnostics ran for Ascend and the current full 4,768-call schedule leaves no room under the 4,768 fixture cap, so this did not change its result. Freeze one inclusion rule prospectively; do not choose after seeing diagnostic values.

## Bounded assessment of Warden's micro150-only v4 proposal

Room #56204 / sourceId `bf97624d-7399-4c43-aa1c-4ceafa44b6c4` at 2026-10-31T07:00:00.173Z proposes PASS for a partial-reference gap ≥5e, FAIL only on a completed reference below5e, otherwise INCONCLUSIVE. This is **not approved by this review**.

With a complete, frozen cheap baseline C and a monotonically growing set E_t of fully eligible, finally scored candidates, `C - min(J in E_t)` cannot decrease. A witnessed partial gap is then a lower bound on the final gap. That supports a prospectively declared early-PASS screening rule; early FAIL remains unjustified. It does not establish an LLM advantage, global optimum, statistical significance, manufacturing validity or independent physics confirmation.

Before explicit +1, the revised contract/code must establish: all 24 cheap lanes and 96 reproductions complete with a fixed score policy; the same frozen feasible domain across arms; a reproduced reference witness with pinned identities and reserved calls; unambiguous diagnostic inclusion; immutable start-bound inputs and full attempt evidence; preserved cumulative allocation including CI; the CPU and independent wall/deadline semantics; and actual v4/micro150 fixture support. Warden's micro e=0.79°C gives threshold3.95°C, but its empirical mesh maximum remains an observed fixture/package/grid calibration, not a universal physical or probabilistic error bound. Preserve Ascend v3 unchanged and pin the micro calibration provenance separately.

## Verification and CI are separate evidence

Independently run here: **54/54 shipping headroom tests passed**, Python3.12.3 in WSL Ubuntu24.04, zero failures/errors/skips. Real HotSpotOracle construction, `subprocess.Popen`, and `asyncio.create_subprocess_exec` were forcibly denied. Five fake-only adversarial cases above also asserted successfully. No native executable was built or run, and there was no independent thermal reproduction.

Prior readback of GitHub run41178801855 showed browser/contracts/container green, secret-scan failed; container finished07:02:19Z. Worker VALIDATION says its box lacked Docker and did not run historical native/container gates; later CI is separate evidence. **CI allocation/accounting remains unresolved:** green container CI does not establish that its native work was authorized or charged to the shared preflight allocation, and SPEND alone does not account for it. No CI was rerun during this review. Scanner failure must receive a precise finding/location analysis rather than a broad bypass.

Audit artifacts are in `tasks/sentilab-review-2026-10-30/pr25-fa7ed8f/`:

- `recorded-summary.json`: seven immutable source/hash comparisons.
- `recorded-details-proof.json`: arithmetic, 96 reproduction entries, 26 design/geometry/wire checks, micro initial-layout failure.
- `shipping-tests.json` and `shipping-tests.log`: independently executed 54-test suite.
- `adversarial-proof.json`: five bounded fake-oracle failure demonstrations.
- Corresponding read-only audit scripts and immutable source copies.
