# PR25 a10063d corrective review

**Exact head:** `a10063d432d776f3bf43ee6d8b8efbee4d6b5032`  
**Reviewed baseline:** `38563e2c77985cc82d35877a2a1da2a39adda4dc`  
**Tree:** `e420f4d8072f320ed756c7532e4039a9cc1f915a`

**Disposition: both prior P2s close within the bounded source/mock review; no new material defect found in the headroom delta.** This is a technical correction finding, not final CI acceptance, deployment validation or scientific execution authorization. Existing exact-head CI run `41198656538` still has its container job in progress in the retained snapshot; its other four jobs passed. No CI job was initiated or rerun by this review.

## Corrected identity and admitted-policy evidence

At `headroom_supervisor.py:195`, `LinuxTree.done()` synchronously reaps children and records the leader's exit code. The revised `kill()` at line 212 only sends the original process-group signal while the leader has not been reaped. Once `returncode` is set, cleanup uses the existing descendant snapshot/start-time checks. The new finite tests reproduce the old leader-reaped/owned-orphan sequence: the original numeric group receives no signal, the owned orphan is drained, and changed or missing descendant identities are refused. The live-leader group control still passes. This supervisor owns its synchronous wait/reap sequence; it does not rely on the asynchronous cached-returncode design reviewed separately in PR43.

At lines69–88, `load_policy()` reads bytes once, parses and validates that buffer, and returns its SHA256. `run()` saves that hash and the admitted declaration in the durable reservation at lines342–349, then copies the reservation identity into settlement at line 372. The exact new author test verifies one policy read and reservation/settlement identity despite replacing the file. An independent finite backend also replaces the policy during `start()`, exercises the unchanged actual `supervise()` loop and actual `settle()`, and confirms the original hash throughout. It records 0.65 synthetic CPU seconds, retains the original Ascend charge and the observed fake rate-cap evidence, and never invokes the worker closure.

These checks close the two findings in the retained [prior corrective review](../pr25-38563e2-review/CPU-CORRECTIVE-REVIEW.md). They are not a proof against arbitrary hostile code escaping the trusted tree, arbitrary OS identity races outside the reviewed lifecycle, or an unconditional scheduler/cleanup bound.

## Warden operating conditions

The retained [Warden message 56483](WARDEN-56483.json), timestamp 2026-10-31T10:19:35.551Z, accepts best-effort CPU risk subject to a container quota equal to Q, measured H, complete charging and a whole-allocation halt after one overshoot greater than H. It explicitly states that it authorizes no micro150 execution.

| Condition | Exact implementation and bounded result |
| --- | --- |
| Measured reserve | `Policy` validates positive finite L and Q∈{1,2,8}; H=2×L×Q at line 57. `load_policy()` requires L and a nonblank evidence reference and refuses H smaller than the declared burst, observation, kill, reap and settlement reserves at lines79–87. |
| Stop with H reserved | The unchanged parent loop subtracts H and already-consumed parent CPU before start, and stops when observed CPU+H reaches allowance at lines239–260. The new fake Q=2 test confirms the measured H governs the threshold. |
| Container quota | `verify_cpu_max()` at lines91–106 requires the current cgroup-v2 quota/period to equal Q and rejects unlimited, malformed, mismatching, missing or escaping membership. `run()` checks before writing the reservation and copies the observation into reservation and receipt. Synthetic files exercise Q=1,2,8. |
| Retain charges and every overshoot | `settle()` preserves the maximum of whole-parent CPU plus declared tail and worker charges, retains historical Ascend 1440.294565 CPU seconds, and appends each lifetime receipt. The micro150 upper bound remains 2879.705435 before further charges. |
| Halt after a single excess>H | Lines307–314 persist reason, actual excess, H and reservation ID; `remaining_cpu()` and `SolveBudget.__init__()` refuse halted-ledger reuse, including both fixture names. Tests check below/equal/above H, durable reread, rejected resource acceptance and preserved prior charges. A further low-charge settlement does not clear an existing halt. |
| No invented deployment evidence | The shipped policy records Warden's conditional acceptance but retains null L/evidence. Actual `load_policy()` refuses it. No deployment latency samples, native process confinement, live cgroup setting or cap persistence were verified here. |

The grant's phrase about a per-wall-second bound is too strong for `cpu.max`. The changed policy/docs correctly specify quota-period behavior, possible bursts and no guarantee for every rolling second. They also retain `hard_cap=false`, an unbounded unconditional overshoot, an unmeasured terminal tail reserve and the operator duty to preserve the cap. This review does not promote the rate quota into an unconditional cumulative CPU guarantee.

The reviewed deadline remains 2026-10-31T12:00:00Z; this review does not renew it or modify any allocation. Later execution would still require applicable scientific gates, real deployment evidence and an explicit valid execution release.

## Prior closures preserved

All 57 previous source instances were revalidated against their recorded SHA256/Git blobs and exact baseline identities. All 59 current captured files also match exact-head blobs. Of the 57 earlier objects, 52 are unchanged; the five changed objects are the supervisor, the runner's new halt guard, the supervisor test, and the two supervisor policy/docs files. Two new identity/policy test files complete the seven-file delta.

`headroom.py` differs only inside `SolveBudget.__init__`; every other top-level definition is AST-identical, as are its other budget methods. In particular, the scientific runner and complete frozen-C prerequisite are preserved. `tap_oracle_worker.py`, the scientific/cap tests and the historical evidence are byte-identical to the previously reviewed objects. The earlier complete-C, preserved timeout output, fixed wire domain, frozen score/reproduction identity, unique attempt, start-bound preregistration and binary64 arithmetic conclusions remain supported; the earlier passed suites were not repeated.

The actual parent `supervise()` function and lifetime-wall helper are AST-identical to the previous review. The earlier finite startup/output accounting, 0.1-remaining refusal, parent independence and kill-to-reap charge findings therefore retain their original limits. Historical Ascend v3 remains INCONCLUSIVE. No measured micro150 result or new scientific generalization follows.

## Verification and execution scope

**14 tests pass:** all 11 newly added author identity/policy tests plus 3 independent finite checks. The full supervisor source executes against an explicitly fake process-budget boundary; only the exact `SolveBudget` and supplied `FakeTree` AST definitions are loaded from the other modules. No numerical modules were imported. All fork/exec/subprocess, real signal/wait and affinity mutation paths are denied; the tests override relevant boundaries with finite fakes. There were zero forbidden attempts, zero production worker-closure calls and zero numerical/device/SSH/Docker/CI actions.

The WSL Ubuntu 24.04/Python 3.12.3 harness window was 0.88690806 seconds and self CPU 0.197786 seconds, excluding interpreter/WSL startup. These are reviewer overhead, not experiment charges or an OS-compliance measurement. The new deployment measurements and real subprocess tests were not run.

Artifacts: [source manifest](SOURCE-MANIFEST.json), [exact delta](EXACT-DELTA.patch), [finite harness](review_finite.py), [test output](finite-test-output.txt), [observations](finite-observations.json), [summary](finite-summary.json), [existing CI snapshot](CI-SNAPSHOT.json), [CI run metadata](CI-RUN.json), [validation](VALIDATION.json), and [seal](REVIEW-SEAL.json).
