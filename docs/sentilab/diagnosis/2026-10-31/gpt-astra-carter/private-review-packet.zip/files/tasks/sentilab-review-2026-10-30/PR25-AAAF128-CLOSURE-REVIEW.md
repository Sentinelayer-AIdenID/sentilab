# PR25 aaaf128 closure review

**Decision: changes requested; no prospective micro150 execution clearance.** The revision materially fixes the wire-domain, reproduction-score and attempt-retention defects. Two reproducible source issues remain, and its admission-only CPU/deadline semantics still require a separately accepted prospective policy. Preserve Ascend910 v3 **INCONCLUSIVE**. The proposed 72 headroom / 84 aggregate CPU minutes are **not approved by this review**; historical CPU and numerical CI accounting remain unresolved.

- PR: https://github.com/Sentinelayer-AIdenID/sentilab/pull/25
- Exact reviewed head: `aaaf128dce11d14033ec693177bc761f1ff346f3`.
- Base: `691d79be5a2241c366b8122126f0467cb908d668`.
- Reviewer: root's `aneta_packet` subagent; this is not an Aneta review or a second whole-plan decision.
- Scope: exact source, retained evidence and fake-only tests. No native solver execution, model call, CI rerun, product edit or external post.
- Prior findings: `PR25-FA7ED8F-REVIEW.md` at `fa7ed8ff09c35a3745e3e2fef6acfbeac1d1e3a4`.

## Remaining findings

### P2 — reject reference admission when the cheap baseline cannot be frozen

Source: `sundai_controller/headroom.py:667-678`.

`_freeze_cheap_baseline` can return `None` after a cheap reproduction disagreement. The code omits `CHEAP_BASELINE.json` but still enters every long-SA restart. This contradicts the preregistration/validation promise that the complete frozen C is persisted before any reference call. Once a cheap lane is invalid, later reference results cannot make C valid, so those calls consume a scarce allowance without being able to change the run's INCONCLUSIVE verdict.

An independent fake-oracle case kept the exact 24-lane 28+4 schedule, made the first cheap reproduction disagree, and lowered only the total allowance to 769 calls. Observed: `cheap_baseline_complete=false`, no baseline file, first cheap winner unverified, **768 cheap calls followed by one reference call**, final INCONCLUSIVE. With the full allowance, the same unconditional loop can continue into the declared 4,000 reference calls. Only one reference call was needed to establish the defect; no native evaluation was run.

Before entering the reference loop, require the frozen baseline to exist and pass its consistency checks. If it cannot be frozen, retain the completed attempt and charges, report the reason and stop reference admission. Add a regression where cheap reproduction fails while unused reference allowance remains.

### P2 — retain partial stdout/stderr on the timeout failure path

Source: `sundai_hotspot/tap_oracle_worker.py:250-258`.

The new retained-output path writes stdout/stderr and the exit record only after `subprocess.run` returns. `TimeoutExpired` instead writes `str(exc)` to `TIMEOUT.txt` and raises. The exception's captured partial stdout and stderr are lost even though timeout is a normal bounded-run failure. This leaves the prior full-failure-evidence requirement only partially closed.

An independent fake subprocess timeout supplied `partial stdout` and `partial stderr`. The retained directory held `REQUEST.json`, `TIMEOUT.txt` and generated inputs, but **neither stdout.txt nor stderr.txt**. The fake process was never executed. Persist the exception's partial output with deliberate bytes/text handling and a structured timeout/status record before raising; test both bytes and text exception payloads.

## CPU/deadline policy remains a release condition

Source: `sundai_controller/headroom.py:262-305`, `sundai_hotspot/tap_oracle.py:505-518`, and `PREREG-v4.json`'s `overshoot_policy`.

The new code records overshoot and prevents later admission, which is useful. It still does not enforce an absolute CPU or deadline maximum during an already admitted evaluation. The default oracle retains a 45-second solver timeout and a 55-second worker timeout; the remaining job allowance is not passed into those limits.

A zero-burn fake-clock case admitted one evaluation with only **0.205435 CPU seconds** of total headroom allowance left and one second before 12:00Z. A simulated 30 CPU-second / 55 wall-second evaluation completed; the retained ledger reported **29.794565 CPU seconds** of headroom/aggregate overshoot and **54 seconds beyond the deadline**. The next call was correctly refused. This is an illustration of the declared admission policy, not evidence that such real overrun occurred.

Therefore the earlier “budget/clocks not implemented” finding is partly closed: fixture support, preserved cumulative counts, conservative non-headroom reservation and between-call checks now exist. An absolute-cap claim remains unsupported. Before prospective release, either enforce a defined in-flight reservation/cancellation bound that fits the remaining allowances, or obtain an explicit versioned approval for quantified overshoot semantics. This review supplies neither that approval nor a reset of prior charges.

## Verified closures and preserved boundaries

| Prior issue | Exact-source disposition |
| --- | --- |
| No fixed initial wire constraint | Closed prospectively in source. `_ConstrainedOracle` computes one initial ceiling and validates candidate geometry/proxy before admission, including shared designs and reproduction. The exact micro150 catalog/initial coordinates give a **31.0 mm** proxy ceiling. The ceiling does not follow improved winners. |
| Reproduction scores replace search winner | Closed for v4. Search design/score are frozen; fresh results must agree within absolute `1e-6 C`, with matching candidate/solver/problem identity and valid converged finite output. Reproduction temperatures do not re-rank the frozen winner. |
| Reference lacks a verified witness | Closed in eligibility logic. Each restart reserves 999 search + one reproduction within 1,000 calls; incomplete/unverified winners cannot supply PASS. FAIL requires all reference restarts complete. This source check does not independently reproduce thermal values. |
| Unsupported v4 / six-chip initial layout | Closed in source: a micro150-only parser/profile and explicit eight-chip initial centers exist. Fixed schedule/discrepancy/tolerance checks reject supplied weakening. |
| End-of-run preregistration hash differs from executed bytes | Specific reread defect closed: original preregistration and runner bytes are captured before execution, snapshotted per attempt and used for the reported hashes. Broader source/environment attestation remains separate. |
| Later invocations overwrite attempt results | Closed prospectively for the tested ordinary paths: unique attempt directories, cumulative spend links, durable signed event streams and retained per-call designs/results. Timeout partial-output retention remains open as above. |
| Diagnostic eligibility ambiguity | Closed for v4: no diagnostic solves, excluded from gate eligibility; fixed cheap/reference schedule retains all 4,768 fixture calls. |

`PREREG.json`, `RESULT.json`, `REPORT.md` and `VALIDATION.md` are byte-identical to the prior head. `SPEND.json` retains **2,650 calls and 1,440.2945650000001 CPU seconds** for Ascend, adding the original **1,525.852038-second** interval and explicit non-headroom/unknown-accounting fields. No stored Ascend winner was retroactively refiltered or promoted to PASS.

The stored non-headroom row records 62 known timing/development calls, reserves 300 calls/720 CPU seconds and explicitly leaves historical CPU/CI reconciliation unknown. A reservation is not proof of actual historical consumption or compliance. Even if the proposed 72-minute total were later approved, Ascend alone leaves at most **2,879.705435 seconds**, before any other headroom charges. Retain the unchanged 9,700 headroom / 10,000 aggregate call ceilings.

## Verification evidence

The GitHub source capture contains 18 selected changed/supporting files plus 19 dependency files; each byte stream is checked against its immutable Git blob. The historical comparison and independent fake counterexamples are saved under `.sentinelayer/sentilab-planning/gpt-astra-carter/pr25-aaaf128/`.

The **86-test shipping fake-only suite passed**, with zero failures, errors or skips, in WSL Ubuntu 24.04 / Python 3.12.3. Elapsed time was **283.240009 seconds**; measured reviewer process CPU was **265.357977 seconds**, recorded separately from experimental/native spend. Real `subprocess.Popen`, `asyncio.create_subprocess_exec` and HotSpot worker launch were denied, with zero blocked launch attempts. Three metadata/catalog/retention tests require a binary path: the isolated test tree used a clearly marked, non-executable text fixture for hashing only. This verifies catalog/retention logic without asserting a real binary or solve. The initial import-only attempt lacked captured `trust.py`; that audit setup omission was repaired from the exact GitHub blob and retained as `shipping-setup-failure.*`, not counted as a product failure.

Independent counterexamples are in `adversarial-proof.json`; all three assertions completed in **9.172335 wall seconds** with zero native/model/process launches. CPU was not separately measured for that short run and is not asserted as zero. GitHub was re-read at the same aaaf128 head with five successful CI jobs (browser, container, contracts, live-conformance, secret-scan). These existing jobs were not rerun, and their green status does not resolve numerical allocation/accounting.

No external review or +1 was posted. Root should reconcile this source decision with the operator's precise prospective allowance before any micro150 numerical work.
