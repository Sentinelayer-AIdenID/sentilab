# Existing CI inventory and PR48 scanner-source reconciliation

**79 unique visible CI run IDs** were created from grant-effective **2026-10-31 07:56:00 UTC** through the fixed cutoff **12:20:29 UTC**, inclusive: **57 `pull_request` runs and22 pushes to `main`**. Every row reports `run_attempt:1`; the recorded attempt sum is79. This is an independently retrieved run inventory, **not CPU, HotSpot solve usage, billing or authoritative grant settlement**.

Two API pages returned153 distinct workflow runs overall. Their visible run numbers are contiguous1–153 and both pages reported total153; the window contains79. The first page/filter inventory was retained at12:21:08.869. At that fetch, the window had64 successful,12 failed and3 in-progress runs. Status/conclusion observations are as fetched, not reconstructed as-of12:20:29. No run was started, rerun, cancelled, edited or deleted by this audit.

The inventory independently reproduces69 visible runs before11:53:00, followed by10 created runs through the cutoff. It supersedes the old69/131 snapshot for visible run-count reporting only. Do not label121 as authoritative available balance: outstanding reservations, operator debits, any unavailable history and other accounting decisions remain Warden-owned.

`VISIBLE-RUN-INVENTORY.json` retains every run ID, source head/branch, event, attempt, created/started/updated timestamps, conclusion/status, check-suite ID, available PR linkage and URL. Timestamp inclusion uses numeric `Date.parse`, never lexical or sequence-only filtering. All pushes in this window are main pushes. Empty PR arrays are preserved as missing API linkage; this audit does not invent a PR number for them.

## PR48's three distinct runs

All three use `.github/workflows/ci.yml`, PR source head `f6e5aae499a5ba63c8745be546b6b31a3678fb92`, `pull_request`, attempt1 and checkout ref `refs/remotes/pull/48/merge`. They are **three distinct run IDs**, not attempt2/3 of one run.

| Run | Created UTC | Actual logged test merge | Actual merge base | Secret scan |
|---|---|---|---|---|
|41199631895|12:06:30|`c19b5e2318abb64170274bf06231462e371aefa6`|`deb24670f53bada97cc965d282f6bcf68c338d1e`|Failed;9 findings|
|41200444978|12:17:36|`c19b5e2318abb64170274bf06231462e371aefa6`|`deb24670f53bada97cc965d282f6bcf68c338d1e`|Failed;9 findings|
|41200455468|12:17:44|`3900f6aa10d6ce44bececdbd8a4473d5d920fcc0`|`2d9eca298261551a8082faa16aebd4442c2d5bea`|Passed;no findings|

The **retained checkout logs, fetched Git commit parents and exact source bytes agree** on these test merges. The current run API's `pull_requests[].base.sha` shows2d9eca2 for all three, including the12:06 run before that commit merged. Therefore that API field is not a reliable historical checkout identity. The logged `git log -1 --format=%H` and pinned fetch SHA establish what each scanner actually checked out.

The PR timeline shows close12:17:29→reopen12:17:34, then close12:17:40→reopen12:17:41. These correlate with the12:17:36 and12:17:44 new runs. The run API states the trigger family `pull_request`; this audit did not retrieve an immutable raw webhook payload proving its sub-action. The workflow has an unqualified `pull_request:` trigger and main-only `push`, with no changed workflow between the two test merges. Do not identify the human behind the shared `mrrCarter` API principal from these records alone.

## Why the scanner results differ

The first two runs used old `.gitleaks.toml` blob `f27980c79cbda671c52b0242bf731f6d79d9e5e9`, SHA256 `6a26b7d294fd3fa2e61003221ca7b946c7ae4ab18e43477f39ad43d9cc2c7113`,1472bytes. The later run used blob `a70dde99025d6291aaff095b61f2e6ab74f808bf`, SHA256 `1e406629e4c79a200f467a7d7bc821a5c58dcf176690aa857e59020bbd00674e`,2923bytes—**exactly PR49's reviewed configuration**.

Both workflow sources have blob `687d389748d7130911cb586061ed1a972e611bf9`. Each scan fetched all branch/tag refs with fetch-depth0 plus its pinned test-merge ref, ran the same Gitleaks8.24.2 image digest `sha256:b5918eb91b8d2473cec722f066abb4352e4ffdc4ec9f4283ec143aba9ec9ebc4`, and logged211 commits scanned. The command was `detect --source /repo --no-banner --redact --exit-code 1`.

Thus the second12:17 run acquired the new PR49 scanner configuration, while the first12:17 run still checked the same older merge as the12:06 failure. This directly resolves the different source/config identity despite identical PR head and superficially identical current API base fields. The nine-count failures are consistent with the previously reviewed PR49 exceptions; these redacted job logs do not enumerate each finding, so this audit does **not independently relabel all nine findings as harmless** or rerun the scanner. Exact final-config safety remains covered by PR49's separate scoped reviews.

## Limits and accounting

This is all currently visible CI workflow history from the repository API at the stated fetch, not proof that deleted/unavailable runs never existed. Contiguous visible run numbers and consistent page totals rule out an observed pagination gap in this capture; they cannot prove complete past retention. `run_attempt` reports no rerun in this capture, but deleted attempts are not independently reconstructed. Jobs can complete after the cutoff; current CPU and dollar totals remain unknown.

No category-specific allocation breach is established by these metadata. No new allowances, balance reset, automatic bootstrap approval or free CI assumption is created. Warden must map the two12:17 PR48 runs and the earlier12:06 run to durable debits, preserving every attempt and any known higher charge. Source/secret-scan success does not establish the container job's eventual success or scientific readiness.

Raw downloaded metadata and redacted-by-Gitleaks job logs are private local evidence. `ANALYSIS.json` carries safe extracted source/result lines; `MANIFEST.json` hashes all retained files. No credential value is reproduced in this report.
