# PR18 micro150 mesh: recorded evidence and CI review

Pinned [PR18](https://github.com/Sentinelayer-AIdenID/sentilab/pull/18) head **`96bf4a03ab4f11a148d1e1a0acf64ece0aa83f6c`**, base `c6d5b0caa0c33402eaa35012306a098701808f22`, reviewed 2026-10-31. All ten changed files, relevant evaluator sources, complete journal, freeze/result lineage and existing CI were inspected. Earlier PR5 and PR12 reviews were read; their solved provenance, heatmap, header/coverage and fixture-identity findings remain closed.

**Recorded-data consistency passes. Resource accounting needs reconciliation before any compliance or remaining-allowance claim.** Existing CI adds real numerical work beyond the documented local study and smoke. This report issues no approval. It ran only local hash, geometry and recorded-data arithmetic checks: no product imports, solver/worker/model calls, CI reruns, product edits or external posts.

## Material operational finding: additional real solver work in completed CI

[CI run 41177168644](https://github.com/Sentinelayer-AIdenID/sentilab/actions/runs/41177168644) executed an uncached Docker smoke layer after the worker's recorded 144 local launches. The eight probe outputs are individually printed in CI. Exact source and successful non-skipped tests/smoke establish **at least 71 completed real HotSpot evaluations** in that CI run; one intended timeout call makes **72 expected native launches**, but CI has no execve trace, so 72 is not an independently enumerated CI launch count.

| CI work | Completed-evaluation lower bound |
|---|---:|
| Oracle tests: binding, four concurrent calls, eight sequential/eight concurrent equality | 21 |
| Individually logged probe results | 8 |
| Four-lane Ascend910 smoke: four initial samples plus four proposals per lane | 32 |
| Existing real mesh regression: four layouts at two grids | 8 |
| Ascend910 and micro150 fixture integration tests | 2 |
| **Total** | **71** |

The new micro150 freeze test is geometry-only and adds no 72-solve study. The repeated workload is the inherited default Docker smoke path. A successful image build is not a pure test. The path also runs on main pushes, so merge-triggered CI or a later rebuild can repeat it.

The committed local accounting is 72 study + 72 traced local smoke launches = **144**, plus a historical lower bound **102**, yielding **246** before this CI. If the new CI belongs to the same 250-solve reservation, the source-derived count gives a conditional lower bound **317**. **Allocation ownership is unresolved, so this is not a confirmed cap-breach finding.** The operator must name the allocation for CI, record this additional workload and reconcile CPU/solve usage before claiming compliance or authorizing another numerical gate. CI wall time is not CPU time, and no CI CPU total is available.

The detailed independent source/count audit is `pr18-96bf4a0-ci/CI-SOLVER-ACCOUNTING-REVIEW.md`, SHA-256 `5695019a46c916d1760500215b53dd15a53e4af6143bd378f80f0cbbed848b6c`. It identifies exact source and CI log lines and verifies 17 source Git blobs. It does not request a rerun or change the pipeline.

## Independent numerical recomputation

The script `pr18-96bf4a0/review_recorded.py` recomputes the metrics independently of the product summary functions, then invokes only the inspected AST-selected artifact checker as an additional consistency check. Decimal arithmetic uses the stated 0.01 C solver output precision; direct artifact decimal errors are also retained and differ from the rounded values by less than 1e-12 C. The initial strict equality to the printed 0.01 C values encountered ordinary binary Kelvin-offset artifacts; the harness was corrected to preserve both forms rather than modifying data.

| Metric | Grid 16 | Grid 32 |
|---|---:|---:|
| Maximum observed absolute discrepancy from grid 64 | 4.28 C | 0.79 C |
| Two-error threshold | 8.56 C | 1.58 C |
| Eligible pairs above two-error threshold | 201 / 276 | 266 / 276 |
| Inversions / coarse ties above two-error threshold | 0 / 0 | 0 / 0 |
| Eligible pairs above fixed 0.01 C threshold | 276 / 276 | 276 / 276 |
| Fixed-threshold inversions / coarse ties | 9 / 0 | 1 / 0 |
| Fixed-threshold agreement fraction | 267/276 | 275/276 |
| Largest misordered reference-grid gap | 4.66 C | 0.24 C |

All ten reported inversion pairs match independent enumeration. The grid-32 pair is **spread-01 versus random-01**: J32 is 170.23 versus 170.31 C, while J64 is 170.89 versus 170.65 C. Thus grid 32 does not preserve every observed rank. The headroom rule's arithmetic **5e = 3.95 C** for this micro150 sample is reproduced; it must not be represented as a general uncertainty bound or transferred from/to Ascend910.

The report correctly explains the triangle-inequality limitation: for two layouts in the same measured set, each coarse error is bounded by the observed maximum e, so a reference gap greater than 2e cannot invert. Passing that same-sample rule is therefore internal consistency, not independent validation of rank fidelity. The fixed tolerance reveals the finer inversions. Grid 64 remains a reference discretization, not a continuum solution. These 24 selected geometric layouts do not establish an error distribution or confidence bound for unseen layouts, new package/power scenarios or another fixture.

## Layout, receipt and source verification

- Frozen-file SHA-256 is **`0a7819d5d062f358c53d27a3fdb294914208f37115cfafb733e13c79bd6ddd6b`**, equal to its sidecar, RESULT and journal header. The file contains 24 unique layouts: eight clustered, eight spread, eight random; seed 1, pool size 384 and fixed tolerance 0.01 C.
- Independent construction of the lower-left-coordinate candidate payload reproduces **all 24 design hashes**. Independent Decimal geometry checks confirm the eight-chiplet/680 W catalog, 1 mm placement grid, 0.5 mm interposer margin including the specified halos, and no halo overlap. The recorded mean pairwise distances also agree. This review did not regenerate all 384 pool members; selection logic was source-reviewed and is geometry-only, with no temperature query.
- The journal SHA-256 is **`094027ea1d7a7a14156ab090e256f8354646dfc3f1f5c8c742af55c73e427598`**. Its 77 records contain one incomplete run header, three grid-provenance records, **72 sequenced evaluation receipts**, and a complete footer. Coverage is exactly one selected-layout/grid pair; header IDs, grids, fixture, expected count and frozen hash agree with RESULT.
- All **72 J values**, all-layer peaks, evaluation/solver timing fields, candidate hashes and receipt-sequence references agree with their journal receipts. All **129,024 heatmap cells** are finite and have the requested grid dimensions; each heatmap hash matches, and each maximum matches its chip-layer peak within 1e-9 C. Fixture/config IDs and per-grid problem/evaluator identities agree. The supplied pure artifact checker returns no errors.
- All **13 recorded generator/config/upstream source hashes** match the exact carried files, including the oracle/worker and micro150 config. The recorded compiled-binary hash is consistent across receipts; its binary bytes are not in this evidence and were not rebuilt or independently verified. Hash agreement and internal consistency are not origin attestation.
- Twenty-four downloaded source/evidence files were verified against their exact Git blob identities. All **four historical Ascend910 evidence blobs** are byte-identical to base. The code delta enables micro150 in the existing factory and updates scope/accounting prose; it does not weaken the solved fixture identity, evaluator pin, heatmap or receipt checks.

## Freeze and execution lineage

The public carry has a first commit `2e1fe3f1fbf2b2ed455005fd3bc9d3135d267c0a` containing the exact final layout/sidecar blobs and **no micro150 RESULT or rows journal**. The next commit adds the measurements without changing the frozen blobs. This establishes the preserved freeze-before-results ordering in Git history.

`VALIDATION.md` separately identifies the actual worker's reconstructed integrated base `f6ec4a0ed8a946a1a85cc4810697bc0b53778d2e` and local freeze/harness commit `cd3df8d88d7ba8dda03bff376b6d10ae944a16e5`, with requested evaluator source `c6d5b0c...` placed in BUILD_SHA. The carried commit IDs differ. The 13 evaluator source hashes independently support the recorded evaluator inputs; the source-patch hash is only a claim without that patch archive. `execution_commit=c6d5b0c` must not be read as the literal executing harness commit.

The journal has no independently trusted wall-clock timestamps or signed pre-registration receipt. Git ordering and the source hashes do not independently prove the worker made no earlier temperature queries. The stated runtime freeze-before-solve chronology remains peer-reported beyond the preserved history. This limitation does not change the reproduced numerical consistency; avoid overstating it as an externally attested preregistration.

## CPU and raw-output limits

The footer, RESULT and VALIDATION study accounting agree: process CPU **0.404398 s** plus reaped-child CPU **129.390509 s** = **129.794907 s**, or **2.16324845 CPU-minutes**. The separately normalized local smoke trace claims 72 launches and **125.069679 s**, or **2.08449465 CPU-minutes**. Their newly measured total is **4.24774310 CPU-minutes**. The study's 138.284318 s and smoke's 133.840088 s are wall times and partly overlap; they are not deployed-host performance measurements. This reviewer did not independently meter those past processes.

The local smoke normalized records preserve PIDs, paths, exec outcomes and terminations, and hashes of the original trace/log. The original `/tmp` trace/log bytes are not included here, so this is author-recorded provenance. Historical CPU, some historical gate counts, setup/preliminary CPU and later CI CPU remain unknown. The original at-most-four solves and at-most-3.75225690 CPU-minutes figures were upper bounds before this observed CI, never certified available capacity.

**Raw HotSpot floorplans, traces/config/layers and grid/steady/stdout outputs remain absent; D02 is explicitly incomplete.** The retained full parsed receipts, input hashes and heatmaps improve auditability, but cannot replace raw-output archival, independent thermal reproduction or physical-model validation. No missing raw output was reconstructed or fabricated during this review.

## CI revision attribution and evidence

All four jobs in run 41177168644 succeeded: contracts **06:34:35Z**, browser-verifier **06:34:37Z**, secret-scan **06:34:45Z**, container **06:36:53Z**. The API associates the run with pinned head `96bf4a0`; checkout is synthetic merge **`763900e39eca4320765adab2dfaf7d17d3eefb75`** into the stated base. Head and synthetic merge share exact tree **`bf8e7e8467c92998c4c099e1eb030beb86aff596`**, so the reviewed source tree matches the tested tree. Existing logs were read, not rerun.

Reproduction of this review's pure recorded-data checks uses bundled Python:

```text
python -X utf8 -I -B review_recorded.py
```

Output is `pr18-96bf4a0/review_recorded_output.json`; complete CI source/log accounting is under `pr18-96bf4a0-ci/`. The review artifact manifest retains SHA-256 values. No full product test suite was invoked because it contains real solver paths.

## Acceptance and resume checkpoint

The bounded numerical, layout, parsed-journal and source-consistency review is complete for this head. No new numerical inconsistency was found. Root should retain the observed-CI allocation issue, missing raw output, partial historical accounting and limits on chronological/physical claims. Any eventual scoped +1 must name that scope; this document grants none.

Before further numerical work, identify and reconcile the CI allocation and its CPU/solve record; do not silently reuse the prior remainder. If a corrective accounting/documentation head arrives, compare it to this exact head and update only affected conclusions. Raw-output archival and independent reproduction remain separately owned follow-ups; they require their own recorded authorization and resource allocation. The 384-pool regeneration and original worker trace/patch authenticity were not independently verified here and should not be reported as completed.
