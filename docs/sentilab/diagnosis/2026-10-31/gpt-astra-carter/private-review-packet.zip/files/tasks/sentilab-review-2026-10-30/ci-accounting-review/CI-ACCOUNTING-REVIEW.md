# CI accounting review against Warden 56314

**Finding: current CI lacks an evidenced implementation of the prospective allocation. No attributed cap breach is established.** Existing metadata supports a bounded run count; sampled logs do not establish exact whole-run HotSpot executions or container-job CPU consumption. These are prospective operations follow-ups, not retrospective noncompliance findings or blockers for unrelated pure reviews.

This is a read-only source/metadata/log review. No CI was triggered or rerun, no numerical/model/test execution occurred, and no product files or external posts were changed. PR23 and PR32 implementation reviews are outside this report.

## Allocation and observation scope

Warden 56314, actor `claude-warden`, UUID `88644193-efef-4edd-bf87-9b622b4f8587`, timestamp `2026-10-31T07:54:09.276Z`, declares a separate CI build-validation allocation effective **2026-10-31 07:56Z**:

- At most **100 HotSpot executions per CI run**.
- At most **15 CPU-minutes (900 CPU-seconds) of container-job time per run**.
- At most **200 CI runs through 2026-11-01 18:00Z**, with all required tests kept enabled.
- Historical roughly 45 container runs x roughly 72 launches = roughly 3,240 launches remains an **estimate**; exact historical per-run counts and CPU are unknown. CI is separate from the experiment's 10,000-solve allocation.

The exact CPU wording is **"15 CPU-min of container job time"**. It names the container-job category, not all five workflow jobs and not just the numerical experiment's solver CPU. The grant does not specify a concrete host/container/cgroup meter. CI currently designates no such meter; that attribution boundary must be settled operationally. Section 2's experiment timeout/deadline rules are not silently substituted for the separate CI allocation.

The collector record is `1cd6e9c9a862e9da87542c29a56d8e4aa5f9d480adefbc08c4daa426fd152dfa.json`; retained-file SHA256 is `4789c2dbaf1be61e6ad87d3095f5a547516ebbdcb539f6a4218fd69fe8aa83b7`. Its recorded source-representation hash is `9e423e28d45b37a380096b8dab2046a4cf40e99219988d7b57b5091accfc1f8b`. Those are different representations.

Repository source was pinned to observed main **`d031c8d25fb581f2355fc632fc8c384ba45cf973`**. The run-list snapshot is **08:51:28.0219195Z**, with job metadata collected through **08:52:31.3225717Z**. This review does not cover runs created afterward or the rest of the allocation window.

## What existing metadata establishes

The unfiltered repository API returned all **89 visible workflow runs in one page**. UTC-offset comparisons identified **15 created and started at or after 07:56Z**, run numbers **75-89**. All visible runs have `run_attempt=1`; there were no older-created runs whose recorded latest start fell after the cutoff and no pre-cutoff run with a recorded update straddling it. A separate server-filtered request also returned 15 prospective records.

For those 15 runs, jobs metadata contains **75 jobs: five per run, including one container job each**, with no observed matrix expansion. Fourteen container jobs were complete and successful at their respective snapshots, with **165-210 seconds of elapsed wall time**; one container job was still active. Several overall workflows failed in other jobs, which does not erase their completed container work.

This is **15 visible workflow IDs / 15 visible attempt pairs**, not a durable allocation-reservation ledger. It does not prove remaining quota, include deleted/inaccessible runs, or settle whether reruns count as new allocation runs. It is not valid to compare GitHub's lifetime `run_number=89` with the prospective 200 allowance. Nor is wall duration, GitHub billable time, or a successful conclusion measured process CPU time.

Three completed container-job logs were retained:

| Workflow run | Container job | Actual checked-out/build SHA from log | Evidence |
| --- | --- | --- | --- |
| [75](https://github.com/Sentinelayer-AIdenID/sentilab/actions/runs/41183186048) | `124484629368` | `63e7891a02b56e5768a1356e27cc56509b4554d4` | Eight-case probe summary; no whole-job usage counter; zero API artifacts |
| [85](https://github.com/Sentinelayer-AIdenID/sentilab/actions/runs/41184797441) | `124489435100` | `d031c8d25fb581f2355fc632fc8c384ba45cf973` | Same evidence types |
| [88](https://github.com/Sentinelayer-AIdenID/sentilab/actions/runs/41185647730) | `124491922055` | `6fd247adc7b5a5b15e554da11ad564558bf113e9` | Same evidence types |

The PR runs execute generated merge commits, which differ from API `head_sha`. Future cost records must retain both identities. No PR32 functional conclusion is drawn from its container log.

Each sampled log prints `HotSpot probe cases ran: 8` and numerous test summaries. Eight is one probe's count, not the entire image-build count. Test counts are not solver execution counts. No complete per-run launch ledger, actual container-job CPU total, allocation ID, or reconciliation artifact was found in these samples. Their exact HotSpot totals and actual CPU remain **null/unknown**, not zero, 72, or presumed compliant.

## Source enforcement and accounting

| Requirement | Current observed implementation | Gap |
| --- | --- | --- |
| 100 executions across the CI run | `.github/workflows/ci.yml` invokes ordinary `docker build`; Dockerfile executes `container_smoke.sh`, which runs legacy numerical entry points and discovers additional test modules automatically. | No shared pre-launch counter/reservation spans the job, subprocesses, or copied scratch binaries. A static historical estimate cannot enforce the cap as tests change. |
| 900 CPU-seconds for container-job work | Container job has `timeout-minutes: 20`; the image build uses `make -j4`; smoke tests and two service containers follow. | The timeout is elapsed wall time. No job-wide CPU meter, CPU admission allowance, or CPU-triggered termination is configured. Parallel work and startup/build costs prevent treating wall seconds as actual CPU. |
| Descendants and cleanup | The ordinary HotSpot adapter has local worker timeouts and process-group termination. A separate conductor oracle/budget has reservation facilities for its own calls. | These are not wired as the CI allocation authority and do not meter the entire Docker/BuildKit tree. Local cleanup code does not demonstrate a reserved whole-job startup/kill allowance or settled cancellation cost. |
| 200 prospective runs and expiry | Workflow triggers on pull requests and main pushes. GitHub supplies run/job/attempt IDs. | No allocation ID, atomic global run reservation, quota check, or 2026-11-01 18:00Z cutoff is present in this workflow. No matrix is configured now; future expansion/retries still need explicit accounting semantics. |
| Auditable final accounting | Ordinary console output and GitHub job timestamps are available. Required tests remain enabled, including automatic test discovery. | No CI accounting artifact upload or always-run settlement records are configured. Sampled artifact listings are empty. |

The standalone `scripts/sentilab_regress.sh` records step wall times and artifacts, but the CI workflow does not invoke it. Its existence cannot establish CI CPU or launch accounting. Likewise, passing `test_budget.py` tests the application component; it does not install a CI budget around all other tests.

The separate `live-conformance` job uses the conductor test's synthetic plate oracle in the inspected source. It is not evidence of a second measured HotSpot allocation. Any additional solver-producing job or future matrix cell must nevertheless join the same explicitly scoped per-run HotSpot counter rather than silently receive another 100.

## Concrete remaining evidence and fix requirements

1. **Bind and reserve the CI allocation.** Use a durable allocation ID for 56314 and record repository/workflow, workflow run ID, attempt, job ID, matrix identity (explicitly empty now), event, PR head and actual checkout/build commit, source-policy hash, reservation time, and expiry. Atomically reserve against 200 before admitted work; explicitly define rerun/attempt and in-flight-at-expiry treatment. Keep failed and cancelled attempts charged rather than silently removing them.
2. **Gate every actual HotSpot launch.** One shared atomic pre-launch authority must cover all entry points, descendants, startup/reference/warmup probes, failures, retries, and `/tmp/probe` copies. Record reserved/started/finished/unknown-start separately. Unknown starts retain their reservation until reconciled. The limit belongs to the run, not each test, worker, or matrix cell.
3. **Meter the declared CPU boundary.** First freeze with the allocator which host/container processes comprise "container job time"; do not replace that category with whole-workflow CPU or the experiment's numerical-only meter. Record actual cumulative user+system CPU for all processes inside the selected boundary, explicitly addressing build/test/service startup and Docker/BuildKit descendants outside the immediate client process. Bind admission and stopping to remaining CPU with a conservative allowance for concurrent in-flight work, startup, observation delay and termination/reaping. Record that reserve and actual kill latency; a 20-minute wall timeout or end-only measurement is insufficient.
4. **Retain settlement on every terminal path.** Publish a hash-bound accounting artifact/log on success, failure, cancellation and timeout, including actual/reserved/unknown counts, CPU scope and units, process/cgroup identity, remaining quota, termination evidence and source identities. Preserve unknowns when a crash prevents measurement. Reconcile available historical receipts without inventing values from test counts or successful status.
5. **Keep the full required suite.** If its work cannot fit, fail as budget-exhausted or obtain a revised prospective allocation. Do not report a green result by quietly skipping required tests. Validate counters and stopping behavior first with mocked launches/clocks/process accounting; this review authorizes no new CI or numerical execution.

The main conclusion is a missing enforceable, attributable control layer. It is **not** evidence that any named prospective run exceeded 100 executions or 900 CPU-seconds, and the pre-effective historical estimate is not a retrospective compliance determination.

## Retained evidence

`RUNS-SNAPSHOT.json`, `PROSPECTIVE-RUNS.json`, `JOBS-SNAPSHOT.json`, and `EVIDENCE-SUMMARY.json` retain counting scope and IDs. `LOG-MANIFEST.json` hashes three retained decoded-text logs and describes their local text representation. `SOURCE-MANIFEST.json` identifies nine read-only source files, all independently verified against their Git blob IDs.

The primary CI-source SHA256 values are:

- Workflow: `bc60311f16c9c295b00f1ec21752ea07d6836e04c4623c4c738b97c8a31a8cc5`.
- Dockerfile: `f53beb2760452f71275720f2e3e42d8e3d759ce5106212940959ac2a0d0efbfb`.
- Container smoke script: `81abdb75d74709680b9a47cc55df2025e55dca03f44eda6c91bc37aef61e934d`.

No external allocation ledger or host-level telemetry was available in this inspected evidence. If such records exist, reconcile them with these exact run/attempt/job identities before changing unknown usage into a compliance verdict.
