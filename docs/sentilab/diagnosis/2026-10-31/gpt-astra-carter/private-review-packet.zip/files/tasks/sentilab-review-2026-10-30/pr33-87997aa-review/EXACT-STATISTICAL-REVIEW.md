# PR33 direction-before-Holm correction review

Exact head **87997aa85b90e6c1d80626d95af20e56cc27d1ce**, compared with reviewed **6d8b6cdd5da87376e9fc0ab2c10d8240c48ca6ca**.

**The coupled-imputation P2 is closed in this source/protocol slice. No new blocking finding was found.** Root retains final statistical/design, merge and release decisions. The actual draft remains execution-ineligible, with all **three numerical parameters and38 execution pins null**.

`freeze.py:367–375` adds `beneficial_sign_test`: it retains the raw two-sided sign-test p only when wins exceed losses; otherwise it returns1. `holm` remains generic, but its docstring now requires this transformation for **both** primary inputs before sorting or threshold comparisons. Document40–84 and JSON43,49–59 state the same rule, retain both endpoint names, forbid post-Holm-only direction filtering, and preserve raw p-values and measured/imputed counts for descriptive reporting. The document's JSON appendix equals the external JSON.

The independent review swaps the two primary names in the original counterexample. Whether the six measured beneficial signs belong to sharing or worker, the other endpoint's1-win/11-loss imputed result has raw p=.00634765625 but confirmatory p=1. The six-win endpoint retains p=.03125. **Neither passes Holm in either assignment.** The generic helper still reproduces the old result when deliberately fed raw p-values, which confirms why the caller rule matters; this is not an unresolved finding after the rule is explicitly bound and tested.

A bounded arithmetic check covers234 single unknown-sign replacements across all win/loss counts with at most12 family positions, considering latent wins, losses and ties. Replacing each unknown sign by an adverse sign never decreases its confirmatory p. Across36 possible confirmatory p-values for the other endpoint and both primary-name assignments, **16,848 coupled comparisons** produce no newly enabled Holm rejection. These are exact finite count checks, not experiment outcomes or proof of family independence. Genuine favorable8/8 plus6/6 second-stage success remains available in either endpoint order.

The two newly supplied pure tests pass. Independent verification adds83 assertions covering source identity, merge carry, both counterexamples, raw/descriptive preservation, invalid-count rejection, prior logic and null guards. The shipping suite was not broadly rerun.

## Preserved source and scope

The reviewed merge has parents `3b06e158938a543b50aebfd604bd4c372e3eda3a` and main `2d9eca298261551a8082faa16aebd4442c2d5bea`; the correction commit directly follows6d8b6cd. All four freeze source/doc/test files are byte-identical before and after the main merge. Eight source instances match their Git blobs, SHA256 hashes and lengths.

All20 existing function/class definitions retain identical executable ASTs; only the generic Holm docstring changes, alongside the new helper. Non-statistical JSON sections are unchanged. Preserve the earlier margin binding, first measurement-valid selection, independent per-slot evidence before normalization, B2 isolation, exact J/hash order, positive inclusive uncertainty margin, reproduced-J ranking, retry/accounting and one-epoch closures. Their future adapter/runner implementation obligations remain explicit.

Actual readiness, changing status alone, and filling the three parameters while leaving pins null all still refuse execution. The draft does not invent loss limits, tolerances, scientific values or an approved analysis runner. Raw p/count retention is a stated caller/reporting obligation; this helper does not create datasets or execute analyses. The new text explicitly supersedes the earlier unrestricted monotone-Holm assertion.

Retained PR metadata records existing CI41200176614 with four jobs successful and container still in progress at capture; no merge or all-green claim is made here. No CI run was triggered.

`STATISTICAL-VERIFICATION.json`, `SELECTED-TESTS.json`, `SOURCE-MANIFEST.json`, `COMMITS.json` and `EXACT-DELTA.diff` retain the evidence. Only authorized read-only source/metadata capture, local immutable snapshots and finite standard-library tests were performed. No model, solver, GPU, device, scientific workload, product edit, push or room post occurred.
