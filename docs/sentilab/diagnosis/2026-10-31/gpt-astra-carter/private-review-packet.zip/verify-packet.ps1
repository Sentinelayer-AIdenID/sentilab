param([string]$PacketRoot = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$resolvedRoot = [System.IO.Path]::GetFullPath($PacketRoot)
$manifestPath = Join-Path $resolvedRoot 'PACKET-MANIFEST.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$sourceMap = Get-Content -LiteralPath (Join-Path $resolvedRoot 'SOURCE-MAP.json') -Raw | ConvertFrom-Json
$rootPrefix = $resolvedRoot.TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
$failures = [System.Collections.Generic.List[string]]::new()
foreach ($entry in $manifest.files) {
    $path = [System.IO.Path]::GetFullPath((Join-Path $resolvedRoot $entry.relative_path))
    if (-not $path.StartsWith($rootPrefix,[System.StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest path escapes packet root' }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $failures.Add('Missing: ' + $entry.relative_path); continue }
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $entry.sha256 -or (Get-Item -LiteralPath $path).Length -ne $entry.bytes) { $failures.Add('Mismatch: ' + $entry.relative_path) }
}
$expectedPaths = @($manifest.files.relative_path) + @('PACKET-MANIFEST.json')
$actualPaths = @(Get-ChildItem -LiteralPath $resolvedRoot -File -Recurse | ForEach-Object { [System.IO.Path]::GetRelativePath($resolvedRoot,$_.FullName).Replace('\','/') })
$unlisted = @($actualPaths | Where-Object { $_ -notin $expectedPaths })
foreach ($path in $unlisted) { $failures.Add('Unlisted: ' + $path) }
foreach ($entry in $sourceMap.sources) {
    $path = Join-Path $resolvedRoot $entry.packet_relative_path
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { $failures.Add('Source map mismatch: ' + $entry.packet_relative_path) }
}
$reportEntry = $sourceMap.sources | Where-Object { $_.role -eq 'canonical-report' }
$reportPath = Join-Path $resolvedRoot $reportEntry.packet_relative_path
$freezePath = Join-Path $resolvedRoot ($sourceMap.sources | Where-Object { $_.role -eq 'canonical-freeze' }).packet_relative_path
$freeze = Get-Content -LiteralPath $freezePath -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $reportPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $freeze.report.sha256) { $failures.Add('Canonical freeze/report mismatch') }
$report = [System.IO.File]::ReadAllText($reportPath)
$targets = @([regex]::Matches($report,'\]\(<([^>]+)>\)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
foreach ($target in $targets) { if ($target -notin @($sourceMap.sources.original_absolute_path)) { $failures.Add('Unmapped direct citation: ' + $target) } }
foreach ($inputNote in $freeze.input_notes) {
    $entry = $sourceMap.sources | Where-Object { $_.original_absolute_path -eq $inputNote.path }
    if (-not $entry -or $entry.sha256 -ne $inputNote.sha256) { $failures.Add('Frozen note mapping mismatch: ' + $inputNote.path) }
}
$readingCopy = [System.IO.File]::ReadAllText((Join-Path $resolvedRoot 'READING-COPY.md'))
$portableTargets = @([regex]::Matches($readingCopy,'\]\(<(files/[^>]+)>\)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
foreach ($target in $portableTargets) { if (-not (Test-Path -LiteralPath (Join-Path $resolvedRoot $target) -PathType Leaf)) { $failures.Add('Missing reading-copy citation: ' + $target) } }
$result = [ordered]@{
    schema = 'sentilab-review-packet-verification-v1'
    verified_at_utc = [DateTime]::UtcNow.ToString('o')
    packet_root = $resolvedRoot
    success = ($failures.Count -eq 0)
    manifest_file_hashes_checked = $manifest.files.Count
    source_map_hashes_checked = $sourceMap.sources.Count
    direct_citation_targets_mapped = $targets.Count
    portable_citation_targets_resolved = $portableTargets.Count
    all_three_frozen_note_hashes_checked = ($freeze.input_notes.Count -eq 3)
    canonical_report_sha256 = $freeze.report.sha256
    unlisted_files = $unlisted
    failures = @($failures)
    limitation = 'Checks bytes, map coverage and first-level local links; it does not execute source code or certify scientific validity. PACKET-MANIFEST.json excludes itself; verify its hash against the external archive receipt.'
}
$result | ConvertTo-Json -Depth 8
if ($failures.Count -gt 0) { exit 1 }
