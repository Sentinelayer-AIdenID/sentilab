"""Offline source capture and arithmetic; no product imports, numerical solver or provider use."""
import hashlib,json,math,statistics,subprocess
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
TASK=OUT.parent
ROOT=TASK.parent.parent
REPO=TASK/'pr53-0ce7dc3-worker-review/checkout'
BASE='4b1fc00dc6d6d4972fb77113f03b0997d55fa147'
GIT=r'C:\Program Files\Git\cmd\git.exe'
sources=[]
def read(path,kind='historical-evidence'):
    raw=path.read_bytes();sources.append({'path':str(path),'kind':kind,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});return raw.decode('utf-8-sig')
def load(path,kind='historical-evidence'):return json.loads(read(path,kind))
paths=['sundai_hotspot/temperature_grid.c','sundai_hotspot/temperature_grid.h','sundai_hotspot/PROBE_README.txt',
 'sundai_tap/passive_interposer.py','sundai_tap/util/hotspot.config','sundai_tap/configs/sys_ascend910.cfg',
 'sundai_tap/configs/sys_micro150.cfg','sundai_tap/sim_annealing.py',
 'sentilab_core/conductor.py','sentilab_core/gate.py','sentilab_core/oracle.py',
 'docs/sentilab/admission/registry.json','docs/sentilab/evidence/micro150/TIMING.json',
 'docs/sentilab/evidence/micro150/measure_timing.py','docs/sentilab/evidence/micro150/SPEND.md']
for path in paths:
    blob=subprocess.run([GIT,'rev-parse',BASE+':'+path],cwd=REPO,stdout=subprocess.PIPE,check=True).stdout.decode().strip()
    raw=subprocess.run([GIT,'cat-file','blob',blob],cwd=REPO,stdout=subprocess.PIPE,check=True).stdout
    dest=OUT/'warden-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    sources.append({'path':str(dest),'kind':'immutable-base-source','revision':BASE,'repository_path':path,'git_blob':blob,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
room=load(OUT/'warden-room-record.json','authenticated-room-record')
later=load(ROOT/'.sentinelayer/sentilab-planning/gpt-astra-carter/daytime-2026-10-31/state/records/b96585f7ac6ec8b7090046c0b1bd1d2d13a71c1d674e88288c4f28f0ef88d59b.json','authenticated-followup-room-record')
text=read(OUT/'warden-room-findings.md','room-transcript')
assert room['text'].strip()==text.strip()
receipt=load(OUT/'RECEIPT.json','parent-retrieval-receipt')
ours=read(ROOT/'reports/SentiLab inconclusive results diagnosis.md','frozen-root-report')
assert hashlib.sha256((ROOT/'reports/SentiLab inconclusive results diagnosis.md').read_bytes()).hexdigest()=='132bf28fc6d962ae159a942084b3a7fe4c17fd52dc65da7a13789939a0460a7d'
nf=load(ROOT/'research_notes/SentiLab inconclusive results diagnosis/numerical_forensics_data.json','own-frozen-derived-data')
result=load(TASK/'pr25-a10063d-review/source/docs/sentilab/evidence/SLAB-039/RESULT.json')
prereg=load(TASK/'pr25-a10063d-review/source/docs/sentilab/evidence/SLAB-039/PREREG.json')
for p in ['PR25-FA7ED8F-REVIEW.md','PR25-AAAF128-CLOSURE-REVIEW.md','PR25-DE4574-SCIENCE-CLOSURE-REVIEW.md','pr25-a10063d-review/EXACT-CORRECTION-REVIEW.md']:
    read(TASK/p,'historical-source-review')
for p in ['PREREG-v4.json','SUPERVISOR-POLICY.json']:
    read(TASK/'pr25-a10063d-review/source/docs/sentilab/evidence/SLAB-039'/p,'prospective-policy')
initial=nf['domain']['initial_design']
def gaps(design):
    ps=design['positions']; cs=design['chiplets'];a=ps[0];ac=cs[0];out=[]
    for i in range(2,6):
        b=ps[i];bc=cs[i]
        dx=max(a[0]-(b[0]+bc['width_mm']),b[0]-(a[0]+ac['width_mm']),0)
        dy=max(a[1]-(b[1]+bc['height_mm']),b[1]-(a[1]+ac['height_mm']),0)
        out.append({'chiplet_index':i,'x_gap_mm':dx,'y_gap_mm':dy,'euclidean_rectangle_gap_mm':math.hypot(dx,dy)})
    return out
cheap=[w for w in nf['domain']['all_stored_winners'] if w['method']!='long_sa']
legalcheap=[w for w in cheap if not w['exceeds_fixed_initial_wire']]
bestlane=min([x for x in result['long_sa_results'] if x['best_design']],key=lambda x:x['best_temperature_c'])
data={'scope':'Offline algebra/retained-data arithmetic. No numerical solver, product import, model or new experiment.',
 'room':{'actor':room['actor'],'sequenceId':room['sequenceId'],'sourceId':room['sourceId'],'timestamp':room['timestamp'],
    'text_matches_retained_findings':True,'claimed_canonical_file_sha256':'453cea657025e93a03172107da995ece8feefdc3ee45c2e31d7067dd0ecb8e01','canonical_file_hash_verified':False,
    'followup_sequenceId':later['sequenceId'],'followup_sourceId':later['sourceId'],'followup_timestamp':later['timestamp']},
 'monotone':{'C_c':result['cheap_median_c'],'best_raw_c':result['best_c'],'raw_gap_c':result['gap_c'],
    'best_recorded_freshly_reproduced_cheap_c':min(x['best_temperature_c'] for x in result['reducer_results']),
    'gap_to_best_recorded_freshly_reproduced_cheap_c':result['cheap_median_c']-min(x['best_temperature_c'] for x in result['reducer_results']),
    'long_reference_fresh_reproduction_counts':[x['reproduction_evaluation_count'] for x in result['long_sa_results']]},
 'wire':{'cheap_winners_count':len(cheap),'cheap_winners_within_initial_wire':len(legalcheap),'legal_cheap_winners':legalcheap,
    'initial_die_rectangle_gaps':gaps(initial),'best_die_rectangle_gaps':gaps(bestlane['best_design']),
    'long_winner_wire_ratios':[x['wire_ratio_to_initial'] for x in nf['domain']['all_stored_winners'] if x['method']=='long_sa']},
 'density':{'ascend_compute_w_per_cm2':256/(14.5*31.4/100),'ascend_io_w_per_cm2':14/(10.5*16/100),
    'ascend_hbm_sized_w_per_cm2':20/(7.75*11.87/100),'micro_compute_w_per_cm2':150/(8.25*9/100),
    'ascend_compute_power_fraction':256/350,'claimed_nonself_rise_k_if_92_percent_of_74':.08*74},
 'coupling_algebra':{'Rconv_K_per_W':.009,'sink_side_m':.2,
    'extra_internal_area_resistance_m2K_per_W':.5*.009*.2**2,
    'extra_internal_area_resistance_cm2K_per_W':.5*.009*.2**2*1e4,
    'material_half_sum_area_resistance_m2K_per_W':.5*(.001/400+.0069/400),
    'grid32_cell_area_m2':(.05/32)**2,'grid32_internal_extra_K_per_W':.5*.009*.2**2/(.05/32)**2,
    'uniform_interposer_350W_illustration_K':350*.5*.009*.2**2/.05**2,
    'uniform_compute_256W_footprint_illustration_K':256*.5*.009*.2**2/(14.5*31.4*1e-6),
    'interpretation':'Local resistance terms only; illustrations neglect spreading and bypasses and do not predict the package temperature correction.'}}
for label,path in [('ascend910',TASK/'pr12-73461c3/docs/sentilab/evidence/mesh/ascend910/RESULT.json'),('micro150',TASK/'pr18-96bf4a0/docs/sentilab/evidence/mesh/micro150/RESULT.json')]:
    mesh=load(path)
    stats={}
    for grid in ['16','32','64']:
        vals=[x['J_c'][grid] for x in mesh['layouts']]
        stats[grid]={'n':len(vals),'mean':statistics.mean(vals),'population_sd':statistics.pstdev(vals),'sample_sd':statistics.stdev(vals),'min':min(vals),'max':max(vals)}
    data.setdefault('mesh',{})[label]=stats
    if label=='ascend910':
        def mesh_wire(layout):
            centers=layout['centers_mm'];weights=[(1,200),(2,256),(3,256),(4,256),(5,256)]
            return sum(w*(abs(centers[0][0]-centers[j][0])+abs(centers[0][1]-centers[j][1])) for j,w in weights)/sum(w for _,w in weights)
        witnesses=[]
        for a in mesh['layouts']:
            for b in mesh['layouts']:
                coarse=a['J_c']['16']-b['J_c']['16'];fine=a['J_c']['64']-b['J_c']['64']
                if coarse>.32 and fine<0:witnesses.append({'a':a.get('id',a.get('name',a.get('layout_id'))),'b':b.get('id',b.get('name',b.get('layout_id'))),'coarse_improvement':coarse,'fine_improvement':fine,'a_J':a['J_c'],'b_J':b['J_c'],
                  'a_wire_mm':mesh_wire(a),'b_wire_mm':mesh_wire(b),'both_at_or_below_initial_wire':max(mesh_wire(a),mesh_wire(b))<=nf['domain']['initial_wire_mm'],
                  'scope':'Pairwise recorded mesh values only; not a live accepted transition or new solver replay.'})
        data['ascend_grid16_margin_rank_reversal_witnesses']=witnesses
original_C=TASK/'pr25-fa7ed8f/source/sundai_hotspot/temperature_grid.c'
original_raw=original_C.read_bytes();base_raw=(OUT/'warden-source/sundai_hotspot/temperature_grid.c').read_bytes()
data['coupling_source_identity']={'original_review_source':str(original_C),'original_sha256':hashlib.sha256(original_raw).hexdigest(),
   'base4b1_source_sha256':hashlib.sha256(base_raw).hexdigest(),'byte_identical':original_raw==base_raw}
assert original_raw==base_raw
read(original_C,'historical-source')
(OUT/'WARDEN-ADVERSARIAL-DATA.json').write_text(json.dumps(data,indent=2)+'\n')
(OUT/'WARDEN-ADVERSARIAL-SOURCES.json').write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),'sources':sources},indent=2)+'\n')
print(json.dumps(data,indent=2))
