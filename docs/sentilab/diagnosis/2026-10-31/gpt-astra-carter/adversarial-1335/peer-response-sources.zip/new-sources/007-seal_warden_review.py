import hashlib,json,re
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
report=OUT/'WARDEN-ADVERSARIAL-REVIEW.md'
text=report.read_text(encoding='utf-8')
refs={k:re.sub(r':\d+$','',p) for k,p in re.findall(r'^\[([^\]]+)\]: <([^>]+)>$',text,re.M)}
paths={Path(p) for p in refs.values()}
for p in paths:assert p.is_file(),p
prior=json.loads((OUT/'WARDEN-ADVERSARIAL-SOURCES.json').read_text())
for entry in prior['sources']:
    p=Path(entry['path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['sha256'];paths.add(p)
paths.update([report,OUT/'warden_adversarial_extract.py',OUT/'seal_warden_review.py',OUT/'WARDEN-ADVERSARIAL-DATA.json',OUT/'WARDEN-ADVERSARIAL-SOURCES.json'])
def digest(path):
    raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
records=[digest(p) for p in sorted(paths)]
manifest=OUT/'WARDEN-ADVERSARIAL-MANIFEST.json'
manifest.write_text(json.dumps({'schema':'sentilab-warden-adversarial-manifest-v1','sources':records},indent=2)+'\n',encoding='utf-8')
seal={'sealed_at':datetime.now(timezone.utc).isoformat(),'report':digest(report),'manifest':digest(manifest),
 'source_instances':len(records),'all_citations_exist':True,'all_prior_source_hashes_match':True,
 'root_frozen_report_sha256':'132bf28fc6d962ae159a942084b3a7fe4c17fd52dc65da7a13789939a0460a7d',
 'warden_messages':[56645,56648],'warden_canonical_file_hash_verified':False,
 'scope':'Source/algebra and retained-data analysis only. No solver/GPU/CI/model call, peer post, product edit or execution grant.'}
(OUT/'WARDEN-ADVERSARIAL-SEAL.json').write_text(json.dumps(seal,indent=2)+'\n',encoding='utf-8')
print(json.dumps(seal,indent=2))
