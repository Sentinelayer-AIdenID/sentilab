# SentiLab additive private reviewer and reproduction packet

This is a separate private handoff assembled on 2026-11-01 from four exact, already-accepted components. It improves access to the g1 material-only diagnostic, staging D1, production T1–T4 and ScienceClaw category integration. It is not the recovered original v3 or v4 engineering archive, a salvage kit, a full release, or a new execution authorization. Original-archive recovery remains with ChatGPT and Warden.

Start with `COMPONENTS.json`, the four reports in `acceptance/`, and the mandatory dated production correction in `corrections/`. The component ZIPs are unchanged, including historical wording. The dated reviews and correction state the accepted interpretation; they do not silently rewrite the original evidence.

| Component | Open first after extraction | Accepted use |
|---|---|---|
| `components/g1.zip` | `sentilab-g1-engineer-supplement/README.md` and `PINS.json` | Four-call configured-model material-only diagnostic; raw outputs and separate identity, numerical, accounting and anchor reviews |
| `components/d1.zip` | `README.md`, `EVIDENCE_LEDGER.json` | Dated staging team example and prospective human-comparison outline |
| `components/production.zip` | `README.md`, `SOURCE_RECONCILIATION.md`, plus this packet's dated erratum | Descriptive adaptive production T1–T4 evidence, corrected raw-reference/control distinction and precise scoped CPU arithmetic |
| `components/scienceclaw.zip` | `upstream-scienceclaw-metadata-category/README.md` | Corrected v2 delivery recipe, pinned registry patch and prepared v3 PR text; requester use outcome remains unobserved |

`MANIFEST.json` inventories every other outer file. `SOURCE-PINS.json` provides immutable source references and distinguishes included patches/evidence from complete repositories, native binaries and images, which are not included or fetched by this assembly. Source rights and private handling are recorded in `SOURCE-AND-RIGHTS.json`. This packet grants no new public redistribution rights. No raw room envelopes, signed download queries, broad vendor archives, weights or MicroDuck/Pollen assets were added.

## Offline checks of already saved bytes

Obtain the outer ZIP's full SHA256 and byte length from the separately authenticated handoff. Compare them before trusting the extracted verifier or its manifest. An internal checksum alone does not authenticate its own source. Use a fresh, short extraction directory; never extract over an original packet. Windows paths deep inside a project checkout may exceed MAX_PATH.

From the extracted outer packet with an existing Python 3.11+ installation:

```text
python verify_packet.py
```

This standard-library verifier reads local files and ZIP members only. It checks the outer manifest, absence of extra files, each exact component identity, ZIP CRCs, confined unique non-symlink paths, component manifests, and the original g1 raw ZIP checksums. It does not import or run component code, access a network, install dependencies, validate signatures, or execute a model/solver/container. It does not change the packet. Any hash mismatch stops verification.

For the already-reviewed g1 numerical readback, first verify the component identity against `COMPONENTS.json`, extract `components/g1.zip` to another fresh **short** directory, then change into its `sentilab-g1-engineer-supplement` subdirectory. Its two previously independently reviewed portable commands are:

```text
python reviewer-tools/verify_bytes.py
python reviewer-tools/recheck_numerics.py
```

These recheck retained bytes and reviewer arithmetic, not a new thermal solve. The second command stages saved raw files in a temporary directory and invokes only the pinned reviewer parser. The accepted prior check had 151 passing numerical assertions. This additive assembly carries that result by exact hash and does not rerun either component helper. The original producer scripts, command logs, network capture scripts and the D1/production `VERIFY.py` files remain inert provenance for this handoff. The g1 ledger helper's optional cryptography dependency and separate signature scope remain as documented in its own README.

## Future source setup and newly admitted reproduction

A byte check is different from repeating a scientific/model workload. For a future reproduction, an operator must first arrange an authorized source checkout at the immutable references in `SOURCE-PINS.json`, preserve upstream licenses/notices, and verify exact input, source/tree, binary/image and configuration identities. Full repository copies, the native binary and the image are absent here; pinned references are not claims that those bytes were fetched by this assembly. Do not substitute a current branch, cached image, model or evaluator for an unavailable pin.

Warden owns the **prospective per-job envelope and new job identity** before any new numerical/model execution. The envelope must bind the exact workload, host/operator, payer, allowed calls, CPU/time/other resource limits, expiry, supervision/STOP, persistence, accounting, replay allocation and intended acceptance criteria. Retain actual costs and failures. This README is neither that envelope nor a command to run a job.

The historical **g1 allocation of 234 CPU-seconds is fully consumed**, with zero refund and no calls available for reuse, regardless of the historical deadline written in its receipt. Never reuse `slab049-coupling-g1-20261101`, old grants, old call identities or archived launch commands. The old GB10 attempts 018/047/047b remain closed. No old Start-live button, acceptance report or source approval releases another execution.

The ScienceClaw v2 component contains an exact patch and a Linux recipe for source checkout, patch application, dependency installation, one-command catalog refresh and focused tests. Its registry file must hash to `af36e908c0dd8b8dea42053c78f2992dcde372c26a57f0f8acf9f5ae93fd9fe5` after applying the patch to stock commit `894598cd3a90891a077c254566276bd379038bad`; Fiber is pinned to `5dcdca9676f29d66e63a2b665dfdb85d7173f039`. Those source/setup instructions are a future operator recipe, not part of the offline checks performed here. Review any effects and prospective resource requirements before running them. New solver/model execution still requires the new envelope above. The original upstream-PR command is retained historically; **publication remains held for Carter**. Do not run it from this packet as a routine verification step.

## Facts and remaining gaps

The g1 configured-model diagnostic meets its frozen 17/20 predicate: native all-block maxima 78.76°C (Ascend 910) and 125.52°C (CPU-DRAM), exact fractions 2233/2397 and 10715/11674, floor displays 93% and 91%. Those native values differ from active-grid peaks 78.77°C and 128.50°C. It is not physical validation or proof of authors' intent or a general optimum. Read the separate accounting correction: 14.321631 charged validation CPU-seconds, 13.252760 native solver CPU-seconds and 15.093926 baseline-adjusted cgroup interval are different scopes; the later 15.107 reading is not whole-lifetime job CPU. Unquantified build/startup/tail/model/dollar scopes are not zero.

D1 is a staging **team** example. Its 2.710°C centre-metric change and 0.03487 mm wire-proxy change are descriptive, not a routed-wire beat. Production T1–T4 are adaptive, selected team points, with centre metrics 108.845, 104.615, 98.29 and 96.51°C. Their four token charges sum to 12.843655 CPU-seconds; four individually rounded rows sum differently. The raw reference (115.935°C, 9.38487 mm proxy) differs from the smoke-control geometry (115.955°C, 9.6 mm proxy). One identical control across staging and production does not establish general environment equivalence. Read production v3.1 **with its exact dated erratum**: five other payloads, not six; the change was one modified paragraph, one appended paragraph and a regenerated manifest.

ScienceClaw's captured fixed-topic discovery was 4/242 and 2/244, with directory-order tie effects qualified in the recipe. Historical 22.18 **UNADMITTED** CPU-seconds, the 1.54-second earlier refresh and the 1.91-second category refresh remain separate. Local delivery/source acceptance does not prove requester access or successful use. Upstream publication and that outcome remain open.

This packet does not include the missing intact original archive, new production runtime evidence, a completed human comparison, physical validation, an outside-party completed run, or final deck acceptance. It preserves the original 41 tickets/234 requirements/104 CLI+104 MCP and eight-incomplete-deliverable accounting; it closes none of them merely by repackaging evidence. Component limitations and dated review scopes remain authoritative. Root coordinates the next private handoff and independent review of this outer assembly; no upload was performed here.
