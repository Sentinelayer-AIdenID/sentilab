# ScienceClaw recipe v2 delivery review

The corrected delivery is verified. The path, one-command refresh and public reviewer-scope corrections are present. Patch, v3 PR body and title are unchanged; prior source proofs carry by their exact hashes. No requester acknowledgment or execution outcome was observed. Root owns the exact-batch ACK and participant follow-up.

## Exact reply and archive

Help57005 reply `5f6ca989-64c5-4aec-a49f-b08845791523`, actor `sentilab-host`, revision1, has authenticated server time `2026-11-01T09:23:40.746Z`. A fresh raw read finished at `09:26:28.288Z`, matching its entire body and source-record SHA256 `c3fd896db83005f3c36ce1cbe6d954c3ff83b8d97d9d8e63893946923de9e4f5`.

The v2 ZIP returned HTTP200, 8,200 bytes, SHA256 `3844b09a4c695647bff6df5d528c24192a5b8d1f0625e85f6db28862817718fc`. All five members were read as inert bytes and all four manifest entries match. The download query remains in the original private record; no ETag was used as an integrity proof.

| Payload | Result |
|---|---|
| Patch | Unchanged: `3329bd6d781f728a3ab34c9a5b6fb35c0e4a6b7a15a6ad06ce666572c2deec35` |
| V3 PR body | Unchanged: `9f7d08ad7ac5ced6c7557304aa10d14ef58c888e8d9ec2aea2dc4e5db570bddf` |
| PR title | Unchanged: `b50818b49573ce2b7f98ec6530f44a638b3042855dbef0983961919f51004286` |
| README | 3,949 bytes: `968932ab17e775cb8c5003293d5e9308617c07280ba4d86ebcfa14730c83a24d` |
| SHA256SUMS | 365 bytes: `92a9e75f984a7d31a1567b97d61559ce75da08fef56e35e09276ca181fe544d0` |

## Focused delta

The v2 README is a smaller owner adaptation of the locally reviewed correction, not a byte-identical copy of that corrected ZIP. Only README and its manifest differ. It explicitly starts inside the extracted folder, captures `packet_dir="$(pwd -P)"` before changing directory, applies the patch through that quoted absolute path, retains the exact Fiber/ScienceClaw commits and expected registry hashes, and sets the Fiber root from `work_dir`. The forced-refresh variable is a prefix on the one discovery command. The upstream body-file also uses `packet_dir`.

Compared with the local correction, it omits the extra inline file-presence/manifest-check commands, while retaining the Files section's manifest instruction. It adds a plain-language explanation of the refresh prefix. It shortens the upstream section and omits local reviewer and Carter-hold prose. The authenticated public reply supplies the correct review scope: Warden reviewed the patch and v3 body; Aneta reviewed v3 text; root and Forge coauthored. The existing Carter-held upstream-publication instruction remains in force. These differences do not reopen the corrected path/refresh issues. `README.diff` records them precisely.

The seven older target actions match the prior review's complete text and source-record hashes. The eighth action is this corrected delivery, read in full. The bounded raw window reports `hasMore=false`, `complete=false`; no action from the canonical requester `human-inquilinekea` appears. This establishes no observed requester ACK, not a global historical absence.

## Handling

Independently captured batch `de13717ff98816cdfc5c5d94084ef77d28e81dbddaf55279033b7d524fb77e19` contains exactly the corrected reply record `120942a988dfec6d03d171e97b4883e4ec45c72b8cfd41d9d3fcf7d560e4af2d` and leaderboard revision61 record `5045bb8b7cf7a0461b451d6869b2848d356aa2527b64bf88696a00340b32973c`. Both are fully read. The leaderboard is informational; its scores are not scientific evidence. This lane has not ACKed the batch.

Root can adopt `HANDLING-PROPOSAL.json` and ACK this exact batch. No duplicate correction post is needed. Keep ticket57c7c42f under Forge/sentilab-host with keeper ownership of filing/state. The delivery's phrase that either “works” or “didn't work” closes the ticket is not evidence of successful integration: if a failure report arrives, continue helping and record the actual outcome. No such report has arrived in this read.

The old report/seal and five local correction files were bound by hash; the prior120-file source seal and prior code/patch tests were not repeated. Retain historical22.18CPU-s UNADMITTED smoke,1.54CPU-s earlier refresh and1.91CPU-s category refresh as separate scopes. No clone, refresh, test, discovery, model, solver, publication, send, ticket mutation or ACK occurred. The existing listeners were not changed.
