"""Local byte/ZIP verification only. No component execution, extraction or network."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, stat, zipfile

ROOT=Path(__file__).resolve().parent
def digest(b): return hashlib.sha256(b).hexdigest()
def safe(n):
    assert n and not PurePosixPath(n).is_absolute() and '\\' not in n and ':' not in n
    assert all(p not in ('','.','..') and not p.endswith((' ','.')) for p in n.split('/'))
    assert not any(re.fullmatch(r'(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?',p) for p in n.split('/'))
    return n
def match(b,e):
    assert len(b)==e['bytes'] and digest(b)==e['sha256'], 'byte identity mismatch'
stats={'outerFiles':0,'archives':0,'archiveMembers':0,'innerManifestEntries':0}
def verify_zip(b,kind):
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        names=z.namelist()
        assert len(names)==len(set(n.casefold() for n in names)), 'duplicate/case alias'
        assert z.testzip() is None, 'CRC mismatch'
        content={}
        for i in z.infolist():
            safe(i.filename)
            assert not i.is_dir() and not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
            content[i.filename]=z.read(i)
        if kind=='g1':
            prefix='sentilab-g1-engineer-supplement/'
            manifest=prefix+'MANIFEST.json'
            entries={prefix+e['path']:e for e in json.loads(content[manifest])['files']}
        elif kind in ('d1','production'):
            manifest='MANIFEST_SHA256.json'
            entries=json.loads(content[manifest])['members']
        else:
            prefix='upstream-scienceclaw-metadata-category/' if kind=='scienceclaw' else 'slab049-run-g1/'
            manifest=prefix+('SHA256SUMS' if kind=='scienceclaw' else 'SHA256SUMS.txt')
            entries={}
            for line in content[manifest].decode('utf-8').splitlines():
                h,n=re.split(r'\s+',line,maxsplit=1)
                name=prefix+n.lstrip('*').removeprefix('./')
                assert name not in entries
                entries[name]={'bytes':len(content[name]),'sha256':h}
        assert set(entries)|{manifest}==set(content), 'inner manifest coverage'
        for n,e in entries.items():match(content[n],e)
        stats['archives']+=1;stats['archiveMembers']+=len(content);stats['innerManifestEntries']+=len(entries)
        for n,data in content.items():
            if n.endswith('.zip'):
                assert kind=='g1' and n=='sentilab-g1-engineer-supplement/original/slab049-run-g1.zip'
                verify_zip(data,'raw-g1')

def main():
    assert not ROOT.is_symlink()
    m=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'))
    names=[]
    for e in m['files']:
        n=safe(e['path']);names.append(n);p=ROOT/n
        assert not any(part.is_symlink() for part in [p,*p.parents] if part!=ROOT.parent)
        match(p.read_bytes(),e);stats['outerFiles']+=1
    assert len(names)==len(set(n.casefold() for n in names))
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    assert actual==set(names)|{'MANIFEST.json'}, 'extra/missing outer file'
    for c in json.loads((ROOT/'COMPONENTS.json').read_text(encoding='utf-8'))['components']:
        b=(ROOT/c['path']).read_bytes();match(b,c)
        verify_zip(b,Path(c['path']).stem)
    print(json.dumps({'status':'PASS','checks':'Saved byte identities, CRCs, confined paths and manifests only',**stats},indent=2))
if __name__=='__main__':main()
