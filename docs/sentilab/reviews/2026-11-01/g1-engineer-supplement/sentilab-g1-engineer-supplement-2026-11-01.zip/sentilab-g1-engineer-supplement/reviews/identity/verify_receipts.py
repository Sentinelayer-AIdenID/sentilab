"""Independent existing-byte signature, identity and hash checks; no producer execution."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, importlib.util, json, re

OUT=Path(__file__).resolve().parent
TASK=OUT.parent
BASE=OUT/'files/slab049-run-g1'
PRE=TASK/'coupling-presign-review-1115'
FROZEN=TASK/'pr56-7f70baf-review-2225/source'
tool=TASK/'coupling-postrun-review-1140/verify_ledger.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(tool.read_bytes())=='8088aca74f3b7361da0ca93dcbe124470114dfda4b20962f5acba728325aa7d6'
spec=importlib.util.spec_from_file_location('reviewer_ledger',tool)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
read=lambda p:v.parse(p.read_bytes())
checks=[]
def check(name,ok,detail=None):
    checks.append({'check':name,'passed':bool(ok),**({'detail':detail} if detail is not None else {})})
    if not ok: raise ValueError(name)
def hexhash(p,expected):
    check('file hash '+str(p.relative_to(BASE)),sha(p.read_bytes())==expected)

manifest=read(PRE/'ACCEPTED-COUPLING-MANIFEST.json')
summary=read(BASE/'RUN-RECEIPT.json')
cli=read(OUT/'LEDGER-VERIFIED.json')
entries=[read(BASE/'ledger'/f'{i:06d}.json') for i in range(9)]
check('all nine staged ledger signatures match actual archived bytes',len(cli['signatures'])==9 and all(
    s['rawFileSha256']==sha((BASE/'ledger'/s['file']).read_bytes()) and s['canonicalSignedSha256']==sha(v.canon(entries[i]))
    for i,s in enumerate(cli['signatures'])))
check('entry zero raw bytes identical to pre-run retained copy',(BASE/'ledger/000000.json').read_bytes()==(BASE/'verification/entry0-000000.json').read_bytes())
check('entry zero file hash matches receipt',sha((BASE/'ledger/000000.json').read_bytes())==summary['entry0']['file_sha256']=='504069a1a6673bd4d0edd51ad3209ae5dc7908e536e7deaabfdb64308e70423d')
check('entry zero canonical hash matches receipt and chain',sha(v.canon(entries[0]))==summary['entry0']['canonical_sha256']=='7a9ec45cf96c991de39b7d16816b0b20afaeda9cdb62818c63943aaf24704969')
check('embedded signed entry zero exactly equals actual entry',summary['entry0']['signed_entry']==entries[0])
check('terminal canonical head matches reported value',sha(v.canon(entries[-1]))==summary['ledger_terminal']['head_sha256']=='30b96f2baf4c13048c655611be23072531a5177507ee0ab01e568c0c673fdd2b')
check('run summary source/image/manifest/key/binary pins agree',summary['bound_values']['source_commit']==v.SOURCE
      and summary['bound_values']['image']==v.IMAGE and summary['bound_values']['manifest_sha256']==v.MANIFEST
      and summary['bound_values']['operator_public_key_ed25519']==v.KEY and summary['bound_values']['material_only_binary_sha256']==v.BINARY)
grant_id=entries[0]['grant']['grant_id']; tag_prefix='refs/tags/gate0-'+grant_id+'/'
tag_rows={}
for line in (BASE/'verification/tags-g1.txt').read_text().splitlines():
    h,ref=line.split();v.digest(h,40)
    check('tag listing name confined and unique',ref.startswith(tag_prefix) and ref not in tag_rows)
    tag_rows[ref]=h
expected={tag_prefix+f'admit-{i:02d}' for i in range(1,5)}|{tag_prefix+k+'-'+c for c in v.CALLS for k in ('reserve','launch','settle')}
check('tag listing exact sixteen expected references',set(tag_rows)==expected)
check('tag listing equals RUN-RECEIPT mapping',{k.removeprefix(tag_prefix):h for k,h in tag_rows.items()}==summary['remote_tags']['tags'])
logs=[v.parse(line) for line in (BASE/'coupling/operator-log.jsonl').read_bytes().splitlines()]
opened=[r for r in logs if r['event']=='grant_opened']
check('grant opening log binds canonical entry zero and opening time',len(opened)==1 and opened[0]['entry0_sha256']==sha(v.canon(entries[0]))
      and opened[0]['at']==entries[0]['grant']['not_before_utc'])

TOP=('admission argv binary build_provenance call charged_cpu_s children_cpu_s claim config_sha256 coupling cpu_baseline '
 'cpu_limit_s evaluator exit_status finished_utc geometry grant_id grid host inputs layout_identity manifest_sha256 outputs '
 'overshoot_cpu_s paper_c raw_layout_sha256 reference replay_of reservation_sha256 reserved_utc role role_in_gate runtime '
 'runtime_after schema self_cpu_s signature solve_record solver_cpu_s solver_environment started_utc status temperature_label timeout_s wall_s')
records={}; bindings=[]; receipt_signatures=[]; per_call=[]; file_counts={'frozenInputChecks':0,'rawOutputChecks':0,'solveFileChecks':0,'allRunFileChecks':0}
prov=read(TASK/'coupling-presign-raw-1120/files/slab049-presign-warden/host-presign-review-3f998f7c/runtime-out/provenance-baked.json')
expected_libraries={**prov['libraries'],'libraries':[{k:r[k] for k in ('name','path','realpath','sha256')} for r in prov['libraries']['libraries']]}
for i,call in enumerate(manifest['calls']):
    cid=call['id']; reservation,settlement=entries[2*i+1:2*i+3]
    directory=BASE/'coupling'/PurePosixPath(reservation['out']).name
    raw=(directory/'receipt.json').read_bytes();receipt=v.parse(raw)
    v.fields(receipt,TOP,'receipt');v.signed(receipt)
    receipt_signatures.append({'call':cid,'rawSha256':sha(raw),'canonicalSignedSha256':sha(v.canon(receipt)),'signatureVerified':True})
    check('signed receipt raw hash binds settlement: '+cid,sha(raw)==settlement['receipt_sha256']==summary['calls'][i]['receipt_sha256'])
    check('receipt grant/manifest/call: '+cid,receipt['grant_id']==grant_id and receipt['manifest_sha256']==v.MANIFEST and receipt['call']==cid)
    check('receipt canonical reservation and admission: '+cid,receipt['reservation_sha256']==sha(v.canon(reservation)) and receipt['admission']==reservation['admission'])
    for key in ('status','exit_status','started_utc','finished_utc','wall_s','solver_cpu_s','children_cpu_s','self_cpu_s','charged_cpu_s','overshoot_cpu_s','cpu_baseline','outputs','claim'):
        check('receipt/settlement '+key+': '+cid,receipt[key]==settlement[key])
    check('terminal success has complete known shape: '+cid,receipt['status']=='exited' and receipt['exit_status']==0)
    v.fields(receipt['evaluator'],'kind binary_sha256 upstream','evaluator')
    check('receipt material-only binary pin: '+cid,receipt['evaluator']['kind']=='material_only' and receipt['evaluator']['binary_sha256']==v.BINARY)
    v.fields(receipt['build_provenance'],'path sha256','build provenance')
    check('receipt provenance binds actual pre-sign JSON: '+cid,receipt['build_provenance']['sha256']=='1fc0aa69d3b218abe1d2dd53a1b54321ea9527e599b5ee35196fc9d8c44b1422'
          and receipt['build_provenance']['path']=='/app/sundai_hotspot/hotspot-material-only.provenance.json')
    check('receipt source binary path and private executed argv: '+cid,receipt['binary']['source']=='/app/'+call['binary'] and
          PurePosixPath(receipt['argv'][0]).name=='evaluator-'+v.BINARY[:16] and receipt['argv'][1:]==call['argv'][1:])
    for rk,ck in [('role','role'),('replay_of','replay_of'),('reference','reference'),('grid','grid'),('layout_identity','layout_identity'),('raw_layout_sha256','raw_layout_sha256'),('paper_c','paper_peak_c'),('timeout_s','timeout_s'),('cpu_limit_s','cpu_limit_s')]:
        check('receipt/manifest '+rk+': '+cid,receipt[rk]==call[ck])
    check('runtime libraries match before/after and accepted provenance: '+cid,receipt['runtime']==receipt['runtime_after']==expected_libraries)
    check('host architecture matches manifest: '+cid,receipt['host']['architecture']==manifest['accounting']['host_architecture']=='x86_64')
    frozen_dir=FROZEN/call['inputs']['dir'];sums=frozen_dir/'SHA256SUMS'
    check('frozen checksum list pinned by manifest: '+cid,sha(sums.read_bytes())==call['inputs']['sha256sums_sha256'])
    expected_inputs={}
    for line in sums.read_text().splitlines():
        h,name=line.split(None,1);name=name.lstrip('*');check('frozen input name is basename',PurePosixPath(name).name==name)
        expected_inputs[name]=h
        check('frozen source input and runtime input bytes: '+cid+'/'+name,sha((frozen_dir/name).read_bytes())==h and (directory/name).read_bytes()==(frozen_dir/name).read_bytes())
        bindings.append({'call':cid,'name':name,'frozenSource':str((frozen_dir/name).relative_to(TASK)),'sha256':h})
        file_counts['frozenInputChecks']+=1
    check('signed input map equals frozen source map: '+cid,receipt['inputs']==expected_inputs)
    check('config digest agrees across input/record: '+cid,receipt['config_sha256']==expected_inputs['new_hotspot.config']==receipt['solve_record']['config_sha256'])
    check('raw output map has exact four files: '+cid,set(receipt['outputs'])==v.OUTPUTS)
    for name,h in receipt['outputs'].items():hexhash(directory/name,h);file_counts['rawOutputChecks']+=1
    check('solve record excludes self-referential receipt: '+cid,'receipt.json' not in receipt['solve_record']['files'])
    check('solve record lists every actual file other than receipt: '+cid,set(receipt['solve_record']['files'])=={p.name for p in directory.iterdir() if p.is_file()}-{'receipt.json'})
    for name,meta in receipt['solve_record']['files'].items():
        v.fields(meta,'bytes sha256','solve file metadata');v.digest(meta['sha256'])
        check('solve record file byte binding: '+cid+'/'+name,(directory/name).stat().st_size==meta['bytes'] and sha((directory/name).read_bytes())==meta['sha256'])
        file_counts['solveFileChecks']+=1
    for name,h in summary['calls'][i]['all_files_sha256'].items():hexhash(directory/name,h);file_counts['allRunFileChecks']+=1
    check('all reported per-call files cover actual directory: '+cid,set(summary['calls'][i]['all_files_sha256'])=={p.name for p in directory.iterdir()})
    ad=receipt['admission'];claim=receipt['claim']
    check('signed admission commit/ref binds captured listing: '+cid,tag_rows['refs/'+ad['ref']]==ad['commit_sha'])
    check('signed launch commit/ref binds captured listing: '+cid,tag_rows['refs/'+claim['ref']]==claim['commit_sha'])
    reserve_logs=[row for row in logs if row['event']=='reserved' and row['call']==cid]
    settle_logs=[row for row in logs if row['event']=='settled' and row['call']==cid]
    check('reserve/settle captured refs agree with log and summary: '+cid,len(reserve_logs)==len(settle_logs)==1 and
          tag_rows[tag_prefix+'reserve-'+cid]==reserve_logs[0]['commit']==summary['calls'][i]['tags']['reserve']['commit'] and
          tag_rows[tag_prefix+'settle-'+cid]==settle_logs[0]['settle_commit']==summary['calls'][i]['tags']['settle']['commit'])
    records[cid]=(receipt,directory)
    per_call.append({'call':cid,'receiptRawSha256':sha(raw),'reservationCanonicalSha256':sha(v.canon(reservation)),
      'binarySha256':receipt['evaluator']['binary_sha256'],'buildProvenance':receipt['build_provenance'],
      'host':receipt['host'],'startedUtc':receipt['started_utc'],'finishedUtc':receipt['finished_utc'],
      'admissionCheckedUtc':ad['checked_utc'],'admissionCreatedUtc':ad['created_utc'],'reservationSignedUtc':receipt['reserved_utc']})

replays=[]
for call in manifest['calls']:
    if call['replay_of'] is None:continue
    receipt,directory=records[call['id']];primary,primary_dir=records[call['replay_of']]
    check('fresh replay and primary have distinct signed execution receipts: '+call['id'],sha(v.canon(receipt))!=sha(v.canon(primary)) and
          receipt['reservation_sha256']!=primary['reservation_sha256'] and receipt['started_utc']!=primary['started_utc'])
    for name in v.OUTPUTS:
        check('exact primary/replay output bytes: '+call['id']+'/'+name,(directory/name).read_bytes()==(primary_dir/name).read_bytes())
    replays.append({'primary':call['replay_of'],'replay':call['id'],'fourOutputFilesByteIdentical':True})

hexhash(BASE/'coupling/report-g1.json',summary['report']['sha256'])
result={'at':datetime.now(timezone.utc).isoformat(),'checksPassed':len(checks),'checks':checks,
 'signedLedgerEntries':9,'signedReceipts':4,'totalVerifiedSignatures':13,'receiptSignatures':receipt_signatures,
 'fileChecks':file_counts,'frozenInputBindings':bindings,'callIdentities':per_call,'replays':replays,
 'anchorEvidence':{'listingRefs':16,'listingMappingVerified':True,'signedAdmissionAndLaunchLinksVerified':8,
   'reserveAndSettleLogLinksVerified':8,'rawGitCommitMessageOrParentObjectsReceived':False,
   'independentRemoteReads':0,'commitMessageAndAncestryVerification':'not established by the ZIP listing alone'},
 'preservedToolInputFailures':'LEDGER-STAGING.json records two local input-layout refusals before successful exact-byte staging.',
 'sourceAndImageScope':'pre-sign source/manifest and per-call binary/provenance/library identities bound; current invocation/container evidence owned by storage reviewer',
 'numericalRecomputation':'root lane; not repeated here','accountingTotals':'storage lane; not recomputed here',
 'producerExecution':False,'newSignaturesGrantsModelsSolvers':0}
with (OUT/'RECEIPTS-VERIFIED.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checksPassed':len(checks),'signatures':13,'fileChecks':file_counts,'tagCommitBodiesReceived':False},indent=2))
