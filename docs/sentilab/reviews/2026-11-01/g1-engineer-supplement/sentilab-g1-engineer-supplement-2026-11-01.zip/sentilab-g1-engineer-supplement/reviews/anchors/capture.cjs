const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFile}=require('child_process');
const OUT=__dirname,TASK=path.dirname(OUT),PRIOR=path.join(TASK,'coupling-run-g1-review-1150');
const GH='C:/Program Files/GitHub CLI/gh.exe',REPO='Sentinelayer-AIdenID/sentilab';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const run=(args)=>new Promise(resolve=>execFile(GH,args,{encoding:'buffer',windowsHide:true,timeout:45000,maxBuffer:2*1024*1024},(error,stdout,stderr)=>resolve({error,stdout,stderr})));
async function main(){
 if(fs.existsSync(path.join(OUT,'CAPTURE.json')))throw Error('Capture already exists');
 const sealRaw=fs.readFileSync(path.join(PRIOR,'SEAL.json'));
 if(sha(sealRaw)!=='e8001fad4205130e9102cc2885e5fc951d94f5bc2f512eba38324629f7e314fa')throw Error('Prior seal mismatch');
 const relative='files/slab049-run-g1/verification/tags-g1.txt';
 const binding=JSON.parse(sealRaw).files.find(r=>r.path===relative),raw=fs.readFileSync(path.join(PRIOR,relative));
 if(!binding||raw.length!==binding.bytes||sha(raw)!==binding.sha256)throw Error('Tag input mismatch');
 fs.writeFileSync(path.join(OUT,'tags-g1.txt'),raw,{flag:'wx'});
 fs.writeFileSync(path.join(OUT,'INPUTS.json'),JSON.stringify({repository:REPO,verifiedLocalRemote:'https://github.com/Sentinelayer-AIdenID/sentilab.git',priorSealSha256:sha(sealRaw),tagListing:binding,authorization:'Root authorized bounded read-only capture of the exact16 ref identities and commit objects after sealing the ZIP review'},null,2)+'\n',{flag:'wx'});
 const pairs=raw.toString('utf8').trim().split(/\r?\n/).map(line=>{const [id,ref]=line.split(/\s+/);if(!/^[0-9a-f]{40}$/.test(id)||!ref.startsWith('refs/tags/gate0-slab049-coupling-g1-20261101/'))throw Error('Unexpected anchor identity');return{id,ref};});
 if(pairs.length!==16||new Set(pairs.map(r=>r.ref)).size!==16||new Set(pairs.map(r=>r.id)).size!==16)throw Error('Expected sixteen distinct anchors');
 const requests=pairs.flatMap(r=>[{kind:'ref',id:r.id,ref:r.ref,name:'ref-'+r.ref.split('/').pop(),endpoint:'repos/'+REPO+'/git/ref/'+r.ref.slice('refs/'.length)},
   {kind:'commit',id:r.id,ref:r.ref,name:'commit-'+r.id,endpoint:'repos/'+REPO+'/git/commits/'+r.id}]);
 const results=[];
 for(let offset=0;offset<requests.length;offset+=4){
   await Promise.all(requests.slice(offset,offset+4).map(async req=>{
     const requestedAt=new Date().toISOString();
     const response=await run(['api','--hostname','github.com','--method','GET','--include','-H','Accept: application/vnd.github+json','-H','X-GitHub-Api-Version: 2022-11-28','-H','User-Agent: SentiLab-root-review/1.0',req.endpoint]);
     fs.writeFileSync(path.join(OUT,req.name+'.http'),response.stdout,{flag:'wx'});
     if(response.stderr.length)fs.writeFileSync(path.join(OUT,req.name+'.stderr'),response.stderr,{flag:'wx'});
     const text=response.stdout.toString('utf8'),match=text.match(/\r?\n\r?\n/),cut=match?match.index+match[0].length:-1;
     const status=Number((text.match(/^HTTP\/[^ ]+ ([0-9]{3})/)||[])[1]||0);
     let valid=false,bodyBytes=null;
     if(!response.error&&status===200&&cut>=0){
       bodyBytes=Buffer.from(text.slice(cut),'utf8');
       const value=JSON.parse(bodyBytes);
       valid=req.kind==='ref'?value.ref===req.ref&&value.object?.sha===req.id&&value.object?.type==='commit':value.sha===req.id;
       fs.writeFileSync(path.join(OUT,req.name+'.json'),bodyBytes,{flag:'wx'});
     }
     results.push({...req,requestedAt,finishedAt:new Date().toISOString(),status,exitCode:response.error?response.error.code:0,
       identityMatches:valid,httpBytes:response.stdout.length,httpSha256:sha(response.stdout),jsonBytes:bodyBytes?.length??null,jsonSha256:bodyBytes?sha(bodyBytes):null});
   }));
   if(results.some(r=>!r.identityMatches))break;
 }
 results.sort((a,b)=>a.endpoint.localeCompare(b.endpoint));
 const result={at:new Date().toISOString(),repository:REPO,method:'GET',authenticatedClient:'installed gh CLI; existing authentication, credentials never read or printed',tls:'normal gh HTTPS certificate verification',userAgent:'SentiLab-root-review/1.0',maximumPlannedRequests:32,actualRequests:results.length,retries:0,allIdentityMatches:results.length===32&&results.every(r=>r.identityMatches),requests:results};
 fs.writeFileSync(path.join(OUT,'CAPTURE.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({requests:results.length,allIdentityMatches:result.allIdentityMatches,statuses:[...new Set(results.map(r=>r.status))]}));
 if(!result.allIdentityMatches)process.exitCode=1;
}
main().catch(e=>{console.error(JSON.stringify({error:e.name,message:e.message.replace(/https:\/\/\S+/g,'[URL withheld]')}));process.exitCode=1;});
