# Coupling g1: signed identity and saved-byte review

Reviewer: `/root/api_batch_review`. Scope: the sole ZIP supplied by authenticated Warden source `2104237a-e8eb-4368-b51e-fea2b0811f17`, server 2026-11-01T11:47:02.801Z. This report covers signatures, source/input identities and raw file bindings. Root owns independent numerical recomputation; the separate storage reviewer owns accounting and persistence.

The nine-entry ledger and all four terminal receipt signatures verify against the previously pinned public key. The exact authorized four-call set, runtime order, material-only binary/provenance, frozen inputs and saved outputs agree. Both replays have distinct signed execution identities and four files byte-identical to their respective primaries. No identity or file mismatch was found. The ZIP alone does not contain the Git commit bodies/parents needed to verify all anchor messages and ancestry; that boundary remains explicit and is assigned a separate additive read-only capture.

## Retrieval and integrity

One HTTPS GET used Node `--use-system-ca`, normal certificate verification, redirects refused and honest User-Agent `SentiLab-root-review/1.0`. The ZIP is 706172 bytes, SHA256 `5d87a5fe795d6c45aa1d93f304892d729d083a932f1c3fc6660618282b93c3a2`. Private URL queries remain only in the retained private source record.

The precise count is 130 ZIP files: 129 checksum-listed payload files, all present and matching, plus `SHA256SUMS.txt` itself. Expanded size is 2059577 bytes. All names, confinement, duplicate/case aliases, sizes and CRCs passed safe-extraction checks. The source message's 129-file count corresponds to the payload count. `RUN-RECEIPT.json` is 36997 bytes, SHA256 `6a2a4ac9e60a1d5b98a48c701d1c82333c0e31bd5f06a4d2b89fe5ac533dbb5b`.

## Signed grant and ledger

The independently reviewed strict verifier at SHA256 `8088aca74f3b7361da0ca93dcbe124470114dfda4b20962f5acba728325aa7d6` was used after its nonauthor scoped approval. It pins manifest `9f9febcb43d0c1b967bf6e45ff883121e49d593453a009bab38675c9ccf5afdd`, public key `aedce64bbc007b3538c02d302da9cedbce1465c409efac8589477284bdbd2132`, accepted source/tree and pre-sign image/binary evidence. It rejects duplicate/nonfinite and unknown ledger fields.

Grant `slab049-coupling-g1-20261101` opens at 2026-11-01T11:37:13Z, has cap 234 CPU-s and deadline 2026-11-02T06:00:00Z, and names the canonical operator ledger directory for this manifest. The sorted authorization set is checked separately from the observed primary-Ascend, replay-Ascend, primary-CPU-DRAM, replay-CPU-DRAM sequence. All four signed reservations allocate 58.5 CPU-s each; all four signed settlements report `exited`, exit 0. No aggregate accounting conclusion is substituted for the storage lane's work.

Entry zero is byte-identical to the separately retained pre-run copy. Its raw file SHA256 is `504069a1a6673bd4d0edd51ad3209ae5dc7908e536e7deaabfdb64308e70423d`; its canonical signed-object SHA256 is `7a9ec45cf96c991de39b7d16816b0b20afaeda9cdb62818c63943aaf24704969`. The terminal canonical head is `30b96f2baf4c13048c655611be23072531a5177507ee0ab01e568c0c673fdd2b`.

All nine signatures and contiguous previous-digest links pass. Signed admission times are within the grant window, and the signed accounting intervals are serial. These are signed host statements, not independent process-start timestamps. The helper was not given an independent root-approval timestamp; root retains the authenticated authorization linkage. The packet's attribution to root's earlier approval is preserved as an operator statement.

The archive flattened the directory to `ledger/`. The first local helper invocation assumed a nested directory and refused; a first staging attempt then refused the unaccounted empty `.lock`, leaving an empty destination, which the helper also refused. Neither produced a verification success. `LEDGER-STAGING.json` preserves both local input-layout failures. The final staging copies the nine entries and empty lock byte-for-byte into the expected basename without changing captured files or signed host paths. The unchanged approved verifier then passes. These were reviewer input-layout corrections, not producer/source repairs or repeated solver execution.

## Receipts and source/input/output bindings

The additive receipt verifier passes 421 inert checks and brings the total to 13 verified signatures: nine ledger entries and four receipts. Each signed receipt's raw-file digest equals its settlement's `receipt_sha256`; each receipt binds the canonical reservation digest and the exact signed admission. All identity/timing/status fields common to receipt and settlement agree.

All four receipts bind material-only binary `6ea3b7813412c13d20c92adc6449fbc0bc87c46b521d4d5eaf80b8abc7900609`, provenance `1fc0aa69d3b218abe1d2dd53a1b54321ea9527e599b5ee35196fc9d8c44b1422`, the proper `/app` binary path and content-addressed private executable name, manifest argv, raw layout/reference, grid 64 and configured limits. Runtime library metadata agrees before/after and with the actual baked provenance JSON from the pre-sign packet. The binary/image itself was not downloaded or executed by this reviewer; per-call runtime identity is signed evidence linked to the independently reviewed pre-sign captures.

There are 36 exact comparisons of saved input files against retained frozen source bytes, with each frozen checksum list bound by the accepted manifest. Sixteen raw output hashes, 64 solve-record file bindings, and 68 complete per-call directory file hashes also pass. The solve records exclude `receipt.json` and cover every other actual per-call file, closing the former self-reference issue for this run.

Both replay pairs have distinct receipt/reservation identities and start times. `sample.steady`, `sample.grid.steady`, `stdout.txt` and `stderr.txt` compare byte-for-byte within each primary/replay pair. This review verifies replay artifacts; root separately derives temperatures and exact fractions from those bytes.

## Anchor boundary and disposition

The retained `tags-g1.txt` listing contains exactly the expected 16 refs. Its mapping agrees with the run receipt. The eight signed admission/launch ref-to-commit identities agree with that listing; the eight reserve/settle mappings agree with the captured operator log and summary. The ZIP does not include Git commit message/tree/parent objects. Those content and ancestry claims cannot be independently reconstructed from an `ls-remote` mapping alone. No extra network request was made as part of this ZIP review. Root has authorized a separate capture of those exact refs/objects after this report is sealed.

The raw report file hashes to `5b0f81ff4a7f057ebee11225f047945b08fa553523423255110b495954e2f0ba`. Its scientific result is not independently recomputed in this lane. Storage, actual operational CPU scopes and invocation/container correlation belong to the separate review. No grant, signature, producer-code execution, model, solver, build, room post, ACK or checkpoint change was performed here. Existing failures, scopes and charges remain intact.
