# SLAB-049 g1 raw numerical review

The retained four-call diagnostic meets the frozen 17/20 predicate for both layouts. This is an independent re-evaluation of raw files, not a new solve. Reviewer-authored `check_raw.py` imports no producer code and passes 151 checks, including corruption rejection controls.

| Frozen reference | HS7 baseline | HS6 baseline | Raw native all-block maximum | Exact fraction | Whole percent, floor |
|---|---:|---:|---:|---:|---:|
| Ascend 910 | 123.42 C | 75.48 C | 78.76 C | 2233/2397 | 93% |
| CPU-DRAM | 232.67 C | 115.93 C | 125.52 C | 10715/11674 | 91% |

The fraction is `(HS7 - variant) / (HS7 - HS6)` using exact decimal raw values and rational arithmetic. The corresponding thresholds are 82.6710 C and 133.4410 C. All native block rows, including package nodes, participate in the maximum. Ascend ties `layer_3_Chiplet_0` and `layer_4_Chiplet_0`; CPU-DRAM ties `layer_4_Chiplet_0` through `layer_4_Chiplet_3`. The report's named maximizer is one of each tied set.

Each primary/replay pair is byte-identical for all four required files: `sample.steady`, `sample.grid.steady`, `stdout.txt`, and `stderr.txt`. Independent parsing validates exactly eight grid layers and 4096 unique cells per layer for every call. The active-layer grid peaks are separately 78.77 C and 128.50 C. They are not substituted for the frozen all-block statistic. The one/two/four-cell centre sets are independently derived from the retained floorplan bounds, then their weights and values are checked. All same-index active-layer/TIM/spreader/sink values and drops agree with the report. Floating representation differences are checked only for derived display fields with a 1e-9 numerical tolerance; the admission predicate remains exact rational arithmetic.

The report is 85,555 bytes, SHA256 `5b0f81ff4a7f057ebee11225f047945b08fa553523423255110b495954e2f0ba`. The authorized packet is separately verified by the identity lane; this review covers numerical/replay contents, not its signatures or accounting.

The accepted result is the prospective bounded HotSpot 7 material-only diagnostic under the already-reviewed source/configuration. It supports the frozen statement that changing this one link removes the displayed fractions of the difference to HotSpot 6 in this configured model. It does not establish physical accuracy, authors' intent, general optimality, or a new production build label. The old failures, baselines, charges and other diagnostics remain distinct.
