# Coupling g1: independent GitHub anchor closure

Reviewer: `/root/api_batch_review`. This is an additive review following the sealed ZIP review at `coupling-run-g1-review-1150` (report SHA256 `4d6cf2403be2aea91af0a2200f6e96d8427e1198b2b2fd38559bfc56c95d5291`, seal `e8001fad4205130e9102cc2885e5fc951d94f5bc2f512eba38324629f7e314fa`). It closes that report's missing raw anchor-message/tree/parent evidence at the authenticated GitHub API scope. No mismatch was found.

Root explicitly authorized a bounded read-only capture of the 16 exact ref identities and their 16 commit objects. The existing local checkout `C:/Users/carth/senti-visitor-integration-repair` identifies its origin as `https://github.com/Sentinelayer-AIdenID/sentilab.git`. The installed authenticated GitHub CLI made exactly 32 GET requests with normal HTTPS verification and User-Agent `SentiLab-root-review/1.0`. Every response was HTTP 200 and matched the exact expected ref or commit SHA. There were no retries, writes, artifact re-downloads or credential reads/prints. Complete response headers/bodies and their SHA256 values are retained separately from the ZIP.

The reviewer first reverified all 151 files in the existing ZIP-review seal. The new anchor checker then passed 157 inert checks. The 16 live reference mappings exactly equal the frozen listing from the ZIP, with no extra or missing names in this requested set.

Every commit message parses without duplicate or nonfinite JSON fields, has exactly the expected fields and values, and equals its canonical JSON bytes. All messages bind grant `slab049-coupling-g1-20261101`, manifest `9f9febcb43d0c1b967bf6e45ff883121e49d593453a009bab38675c9ccf5afdd` and the intended call. All 16 commit objects name source tree `8dfa9e889b316da745c71a453daf5d42e388d120`.

The exact parent and payload relationships are verified for all four calls:

- Each reserve commit has accepted main `3f998f7cfea3f55eec9267b03ff6e2ad207af72b` as its sole parent.
- Admission 1 has its reserve commit as parent; admissions 2–4 each have the preceding admission commit as parent. Their `previous_sha`, sequence and 58.5/117.0/175.5/234.0 envelope totals agree with the signed reservations.
- Each launch commit has its reserve commit as parent, and its message binds the canonical signed reservation digest. Its ref/SHA equals the signed receipt/settlement launch claim.
- Each settle commit has its launch commit as parent. Its message binds the terminal status, exact raw receipt-file SHA256, four output hashes and charged-CPU field recorded by the signed settlement. This checks equality of the accounting field without recomputing the separate accounting lane's totals.

The hash domains remain separate. Git commit SHAs identify the authenticated GitHub objects; admission `previous_sha` links those commit SHAs. The operator ledger's previous digests hash canonical signed JSON. A launch message's reservation digest is that canonical signed reservation digest, while a settle message's receipt digest hashes actual serialized receipt-file bytes. Neither domain is substituted for another.

GitHub reports these 16 Git commits as unsigned (`verified: false`, reason `unsigned`). That is distinct from the 13 valid operator Ed25519 signatures already independently verified in the ZIP review. Current API retrieval verifies the saved ref/object relationships; commit author/committer dates remain Git metadata, not independent solver-start timestamps or a separate physical observation.

An optional local attempt to reconstruct raw Git object SHA1 values using the API-normalized identity dates, simple UTC header serialization and either final-message-LF convention did not match. No raw Git object bytes or original header serialization were supplied by these JSON responses. The initial probe/script is preserved in `INITIAL-RECONSTRUCTION-REFUSAL.json` and `verify_anchors.initial-utc-reconstruction.py`; the final result records zero reconstructed raw objects. No speculative candidate was accepted and no extra request was made. This does not change the successful authenticated API ref/commit identities or exact message/tree/parent checks.

The original ZIP report remains immutable. Its anchor-content boundary is closed by this additive packet at the stated scope. Root's independent numerical work and the separate storage/accounting report remain their own evidence. No producer or historical helper top-level code, solver, model, build, grant, signature, room post, ACK, checkpoint edit or remote mutation was executed here.
