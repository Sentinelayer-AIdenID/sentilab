"""Independent inert raw-output review; never imports or executes producer code."""
from pathlib import Path
from decimal import Decimal as D, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction as F
import hashlib, json, re

HERE = Path(__file__).resolve().parent
PACK = HERE.parent / 'coupling-run-g1-review-1150/files/slab049-run-g1'
C = PACK / 'coupling'
K0 = D('273.15')
checks = []
def check(label, value):
    checks.append({'check': label, 'pass': bool(value)})
    if not value: raise AssertionError(label)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def uniq(items):
    out = {}
    for k,v in items:
        if k in out: raise ValueError('duplicate key '+k)
        out[k] = v
    return out
def read_json(p):
    return json.loads(p.read_text(), object_pairs_hook=uniq, parse_float=D,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def native(text):
    out = {}
    for line in text.splitlines():
        if not line.strip(): continue
        name, value = line.split()
        if name in out: raise ValueError('duplicate node')
        value = D(value)
        if not value.is_finite(): raise ValueError('nonfinite node')
        out[name] = value
    if not out: raise ValueError('empty native')
    return out
def grid(text):
    out, current = {}, None
    for line in text.splitlines():
        if not line.strip(): continue
        m = re.fullmatch(r'Layer (\d+):', line)
        if m:
            current = int(m[1])
            if current in out: raise ValueError('duplicate layer')
            out[current] = {}
        else:
            i, value = line.split(); i, value = int(i), D(value)
            if current is None or i in out[current] or not value.is_finite(): raise ValueError('invalid cell')
            out[current][i] = value
    if set(out) != set(range(8)): raise ValueError('layer set')
    if any(set(x) != set(range(4096)) for x in out.values()): raise ValueError('cell cardinality/index')
    return out
def close(a,b): return abs(D(str(a))-D(str(b))) < D('0.000000001')
def centres(lo,hi): return sorted({(lo+hi-1)//2,(lo+hi)//2})
def centre_map(directory, grids):
    units = []
    for line in (directory/'sampleL4_ChipLayer.flp').read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        fields = line.split(); units.append((fields[0], *map(D,fields[1:5])))
    width = max(x+w for _,w,h,x,y in units)
    height = max(y+h for _,w,h,x,y in units)
    results = []
    for name,w,h,x,y in units:
        if not name.startswith('Chiplet_'): continue
        col0 = int((x*64/width).to_integral_value(rounding=ROUND_FLOOR))
        col1 = int(((x+w)*64/width).to_integral_value(rounding=ROUND_CEILING))
        row0 = int(((height-y-h)*64/height).to_integral_value(rounding=ROUND_FLOOR))
        row1 = int(((height-y)*64/height).to_integral_value(rounding=ROUND_CEILING))
        cells = [(r,c) for r in centres(row0,row1) for c in centres(col0,col1)]
        value = sum(grids[4][r*64+c] for r,c in cells)/len(cells)-K0
        results.append({'name':name,'cells':cells,'centre_C':value})
    return results

report = read_json(C/'report-g1.json')
receipt = read_json(PACK/'RUN-RECEIPT.json')
check('report raw SHA256',sha(C/'report-g1.json')=='5b0f81ff4a7f057ebee11225f047945b08fa553523423255110b495954e2f0ba')
check('report bytes', (C/'report-g1.json').stat().st_size==85555)
expected = [('ascend910-tap25d-fig6a-raw','123.42','75.48'),('micro150-tap25d-fig5a-raw','232.67','115.93')]
all_results = []
for ref, hs7, hs6 in expected:
    hs7,hs6=D(hs7),D(hs6)
    row = next(x for x in report['rows'] if x['reference']==ref)
    replay_files = {}
    primary = next(C.glob('p-hs7material-'+ref+'-g64-*'))
    replay = next(C.glob('r-hs7material-'+ref+'-g64-*'))
    for name in ('sample.steady','sample.grid.steady','stdout.txt','stderr.txt'):
        same=(primary/name).read_bytes()==(replay/name).read_bytes()
        check(ref+' replay exact '+name,same)
        replay_files[name]={'bytes':(primary/name).stat().st_size,'sha256':sha(primary/name),'byte_identical':same}
    for role,directory in [('primary',primary),('replay',replay)]:
        blocks = native((directory/'sample.steady').read_text())
        grids = grid((directory/'sample.grid.steady').read_text())
        max_k = max(blocks.values()); max_c=max_k-K0
        maximizers = [k for k,v in blocks.items() if v==max_k]
        fraction = F(hs7-max_c)/F(hs7-hs6)
        threshold = hs7-D(17)*(hs7-hs6)/20
        floor_percent = (fraction*100).__floor__()
        claimed = row[role]
        check(ref+' '+role+' frozen baselines',D(claimed['T_hs7_C'])==hs7 and D(claimed['T_hs6_C'])==hs6)
        check(ref+' '+role+' all-node max',D(claimed['T_variant_C'])==max_c and claimed['maximizing_node'] in maximizers)
        check(ref+' '+role+' exact fraction',claimed['fraction_exact']==str(fraction))
        check(ref+' '+role+' exact threshold',D(claimed['threshold_C'])==threshold)
        check(ref+' '+role+' frozen predicate',claimed['threshold_met']==(fraction>=F(17,20)))
        check(ref+' '+role+' floor display',claimed['fraction_percent']==floor_percent)
        diag = claimed['diagnostics']; peak=max(grids[4].values())
        args=[{'row':i//64,'col':i%64} for i,v in grids[4].items() if v==peak]
        check(ref+' '+role+' active grid peak',close(peak-K0,diag['active_layer_grid_peak']['peak_C']) and args==diag['active_layer_grid_peak']['argmax'])
        mapping=centre_map(directory,grids)
        for item in mapping:
            declared=next(z for z in diag['chiplet_centre_mapping']['chiplets'] if z['name']==item['name'])
            declared_cells=[(z['row'],z['col']) for z in declared['cells']]
            check(ref+' '+role+' centre cells '+item['name'],declared_cells==item['cells'])
            check(ref+' '+role+' centre value '+item['name'],close(declared['centre_C'],item['centre_C']))
            check(ref+' '+role+' centre weights '+item['name'],all(z['weight']==D(1)/len(item['cells']) for z in declared['cells']))
        check(ref+' '+role+' centre max',close(diag['chiplet_centre_mapping']['max_C'],max(x['centre_C'] for x in mapping)))
        stacks=[]
        for entry in diag['same_index_stack_at_active_argmax']:
            at=entry['at']; i=at['row']*64+at['col']; vals=[grids[n][i] for n in range(4,8)]
            check(ref+' '+role+' same-index stack',all(close(z['K'],v) for z,v in zip(entry['layers'],vals)))
            drops=[vals[n]-vals[n+1] for n in range(3)]
            check(ref+' '+role+' same-index drops',all(close(z['drop_K'],v) for z,v in zip(entry['drops'],drops)))
            stacks.append({'at':at,'layers_K':vals,'drops_K':drops})
        all_results.append({'reference':ref,'role':role,'directory':directory.name,'native_nodes':len(blocks),'native_max_C':max_c,'maximizers':maximizers,'fraction_exact':str(fraction),'floor_percent':floor_percent,'threshold_C':threshold,'predicate':fraction>=F(17,20),'grid_layers':len(grids),'grid_cells_per_layer':4096,'active_layer_peak_C':peak-K0,'active_argmax':args,'chiplet_centres':mapping,'stack':stacks,'replay_files':replay_files})
check('overall predicate',all(x['predicate'] for x in all_results) and report['coupling']['predicate'] and report['coupling']['outcome']=='MEETS')
# Explicitly exercise the parsers' principal corruption rejection paths.
for name, fn, sample in [('duplicate native',native,'x 300\nx 301'),('nonfinite native',native,'x NaN'),('duplicate layer',grid,'Layer 0:\n0 300\nLayer 0:\n0 301'),('missing cells',grid,'Layer 0:\n0 300')]:
    try: fn(sample)
    except ValueError: check('parser rejects '+name,True)
    else: check('parser rejects '+name,False)
result={'schema':'root-coupling-raw-numerical-review/1','scope':'Inert independent parsing of retained outputs, geometry-derived centre cells, exact rational threshold, byte replay; no producer code execution or new solve','packet':str(PACK),'results':all_results,'checks':checks,'passed':len(checks),'report_sha256':sha(C/'report-g1.json'),'receipt_sha256':sha(PACK/'RUN-RECEIPT.json'),'source_sha256':sha(Path(__file__))}
with (HERE/'RESULT.json').open('x') as f: json.dump(result,f,indent=2,default=str); f.write('\n')
print(json.dumps({'passed':len(checks),'results':[{'ref':x['reference'],'role':x['role'],'native_max_C':str(x['native_max_C']),'fraction':x['fraction_exact'],'floor':x['floor_percent'],'peak':str(x['active_layer_peak_C']),'maximizers':x['maximizers']} for x in all_results]},indent=2))
