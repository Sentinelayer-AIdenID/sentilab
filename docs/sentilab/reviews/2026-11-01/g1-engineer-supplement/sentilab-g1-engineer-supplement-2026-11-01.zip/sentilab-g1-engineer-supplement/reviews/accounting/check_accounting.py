"""Reviewer-only raw parsing/hashing. No producer code imports, signatures, solver or network."""
from pathlib import Path, PurePosixPath
from decimal import Decimal
from datetime import datetime, timezone
import hashlib
import json
import re

here = Path(__file__).resolve().parent
task = here.parent
raw = task / 'coupling-run-g1-review-1150/files/slab049-run-g1'
sha = lambda b: hashlib.sha256(b).hexdigest()
def unique(pairs):
    d = {}
    for k, v in pairs:
        if k in d: raise ValueError('duplicate key')
        d[k] = v
    return d
def load(p):
    return json.loads(p.read_bytes(), parse_float=Decimal, object_pairs_hook=unique,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
def dump(p, obj):
    p.write_text(json.dumps(obj, indent=2, default=str) + '\n', encoding='utf-8')

checksums = []
for line in (raw / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
    m = re.fullmatch(r'([a-f0-9]{64}) [ *](.+)', line)
    assert m, line
    relative = m[2].removeprefix('./')
    p = raw / relative
    assert p.resolve().is_relative_to(raw.resolve())
    b = p.read_bytes()
    assert sha(b) == m[1]
    checksums.append({'path': relative, 'bytes': len(b), 'sha256': sha(b)})
assert len(checksums) == 129
host = (raw / 'verification/host-readback.txt').read_text()
host_coupling = dict((m[2], m[1]) for m in re.finditer(r'^([a-f0-9]{64})  \./(.+)$', host, re.M))
actual_coupling = {p.relative_to(raw / 'coupling').as_posix(): sha(p.read_bytes())
                   for p in (raw / 'coupling').rglob('*') if p.is_file()}
assert len(host_coupling) == len(actual_coupling) == 81
assert host_coupling == actual_coupling
host_ledger = dict((m[2], m[1]) for m in re.finditer(r'^([a-f0-9]{64})  ([0-9]{6}\.json)$', host, re.M))
assert len(host_ledger) == 9
for name, h in host_ledger.items(): assert sha((raw / 'ledger' / name).read_bytes()) == h

manifest = load(task / 'coupling-presign-accounting-1120/MANIFEST.json')
call_ids = [row['id'] for row in manifest['calls']]
entries = [load(raw / 'ledger' / f'{i:06d}.json') for i in range(9)]
settlements = entries[2::2]
reservations = entries[1::2]
assert [d['call'] for d in settlements] == call_ids
assert [d['call'] for d in reservations] == call_ids
grant = entries[0]['grant']
assert grant['cpu_cap_s'] == Decimal('234')
log_bytes = (raw / 'coupling/operator-log.jsonl').read_bytes()
before_log = (raw / 'verification/operator-log.before.jsonl').read_bytes()
presign_log = (task / 'coupling-presign-raw-1120/files/slab049-presign-warden/host-presign-review-3f998f7c/coupling-dir-snapshot/operator-log.jsonl').read_bytes()
assert sha(presign_log) == '5271ada5d180ff737c7d02834ecf43bdd97caef11edc10b379f91dbe2ac3b3b9'
assert before_log.startswith(presign_log)
assert log_bytes.startswith(before_log)
before_lines = [json.loads(line, parse_float=Decimal, object_pairs_hook=unique) for line in before_log.splitlines()]
assert len(before_lines) == 2 and [d['event'] for d in before_lines] == ['report_done', 'grant_opened']
assert before_lines[1]['grant_id'] == grant['grant_id']
lines = [json.loads(line, parse_float=Decimal, object_pairs_hook=unique) for line in log_bytes.splitlines()]
assert len(lines) == 12
events = [d['event'] for d in lines]
assert events == ['report_done', 'grant_opened'] + ['reserved','settled'] * 4 + ['run_complete','report_done']
assert lines[0]['exit'] == 1 and lines[-1]['exit'] == 0
runlog = [d for d in lines if d['event'] == 'settled']
rows = []
for i, (settle, reserve, call, op) in enumerate(zip(settlements, reservations, call_ids, runlog)):
    assert settle['kind'] == 'settlement' and settle['status'] == 'exited' and settle['exit_status'] == 0
    assert settle['reserved_cpu_s'] == reserve['reserved_cpu_s'] == Decimal('58.5')
    admission = reserve['admission']
    assert admission['envelope_cpu_s'] == Decimal('58.5')
    assert admission['charged_before_cpu_s'] == Decimal('58.5') * i
    assert admission['total_cpu_s'] == Decimal('58.5') * (i + 1)
    assert admission['late'] is False
    out = PurePosixPath(settle['out'])
    assert out.parent == PurePosixPath('/srv/gate0/runs/coupling')
    receipt_path = raw / 'coupling' / out.name / 'receipt.json'
    receipt = load(receipt_path)
    assert sha(receipt_path.read_bytes()) == settle['receipt_sha256']
    values = ['solver_cpu_s','children_cpu_s','self_cpu_s','charged_cpu_s','overshoot_cpu_s']
    for key in values:
        assert receipt[key] == settle[key]
        assert Decimal(str(settle[key])).is_finite() and settle[key] >= 0
    assert abs(settle['charged_cpu_s'] - settle['children_cpu_s'] - settle['self_cpu_s']) < Decimal('0.000000000001')
    assert settle['overshoot_cpu_s'] == 0
    assert op['call'] == call and op['charged_cpu_s'] == settle['charged_cpu_s']
    rows.append({'call': call, 'out_directory': out.name, 'receipt_sha256': sha(receipt_path.read_bytes()),
                 **{key: settle[key] for key in values},
                 'reserved_cpu_s': settle['reserved_cpu_s'],
                 'supervisor_this_call_rounded_cpu_s': op['cpu_s_this_call'],
                 'supervisor_cumulative_rounded_cpu_s': op['cumulative_cpu_s'],
                 'started_utc': settle['started_utc'], 'finished_utc': settle['finished_utc'],
                 'admission_total_cpu_s': admission['total_cpu_s']})

carry = load(raw / 'coupling/cpu-used.json')
assert (raw / 'verification/cpu-used.before.json').read_bytes() == b'{"used_cpu_s": 0}'
assert carry['used_cpu_s'] == Decimal('15.093926')
assert carry['at'] == '2026-11-01T11:38:36Z'
assert lines[-2]['event'] == 'run_complete' and lines[-2]['cumulative_cpu_s'] == Decimal('15.107')
assert actual_coupling['presign-marker-20261101T105621Z.txt'] == '1501c7d8f9d15dd9e01f51e436d62c31ca80f7b4d8b6053d171f2a64472c62fa'
assert actual_coupling['presign-receipt.json'] == '8def0dfaf2a37de03218b909af8e8faebad220051a5ac1b2586d1bfb084f0625'
assert '3f57633b77964346b3f1f317fb23c6e981c04098f6ead2b653de38b7e56bbff5  /srv/gate0/runs/cpu-used.json' in host

receipt = load(raw / 'RUN-RECEIPT.json')
exits = []
for phase in ['grant','run','report']:
    assert (raw / 'invocations' / (phase + '.exit')).read_text().strip() == 'EXIT=0'
    assert (raw / 'invocations' / (phase + '.stderr')).read_bytes() == b''
    start = (raw / 'invocations' / (phase + '.t0')).read_text().strip()
    finish = (raw / 'invocations' / (phase + '.t1')).read_text().strip()
    assert receipt['invocations'][phase]['t0'] == start and receipt['invocations'][phase]['t1'] == finish
    assert datetime.fromisoformat(start) < datetime.fromisoformat(finish)
    exits.append({'phase':phase,'exit':0,'started':start,'finished':finish})
run_script = (raw / 'invocations/run-g1.sh').read_bytes()
assert sha(run_script) == 'f90d356470c5a910f077dd0c8880159bc67febbd91eef4de8dcca3e52488e442'
wrapper_path = task / 'runtime-r2-0346/files/run_gate0.sh'
wrapper_hash = sha(wrapper_path.read_bytes())
assert wrapper_hash == 'a56be0d63617a073d217559a348244a4d9aeba1e74c298ae2788258ddd944b97'
pregrant = (raw / 'verification/pregrant-state.txt').read_text()
assert wrapper_hash + '  /srv/gate0/operator/run_gate0.sh' in pregrant
die_events = re.findall(r'^(\d+) (\S+) exitCode=(\d+) image=(\S+)$',host,re.M)
assert len(die_events) == 5
assert all(exit_code == '0' and image.endswith('da4700ffdb56a55aa60ee7a4c845a4dbe08f90a1d15cb48d26299abcda597c18')
           for timestamp,name,exit_code,image in die_events)
assert '--- leftover containers:\nnone\n' in host
assert 'running init=true started=2026-11-01T08:19:36.041227276Z' in host

sums = {key: sum((row[key] for row in rows), Decimal(0))
        for key in ['solver_cpu_s','children_cpu_s','self_cpu_s','charged_cpu_s']}
assert abs(sums['charged_cpu_s'] - receipt['cpu_reconciliation']['sum_charged_cpu_s']) < Decimal('0.000000000001')
assert sums['charged_cpu_s'].quantize(Decimal('0.000001')) == Decimal('14.321631')
assert sums['solver_cpu_s'].quantize(Decimal('0.000001')) == Decimal('13.252760')
result = {
    'at': datetime.now(timezone.utc).isoformat(), 'rawRoot': str(raw),
    'rawPackageListedHashesVerified': len(checksums), 'postContainerCouplingFilesHashMatched': len(actual_coupling),
    'postContainerLedgerFilesHashMatched': len(host_ledger), 'ledgerSignatureReviewOwner': 'api_batch_review',
    'grantId': grant['grant_id'], 'callAccounting': rows, 'sumsFromRawNumericLexemes': sums,
    'admissionEnvelopesConsumedCpuS': Decimal('234'), 'admissionRefundCpuS': Decimal('0'),
    'persistedCarryCpuS': carry['used_cpu_s'], 'persistedCarryAt': carry['at'],
    'laterRunCompleteRoundedCpuS': lines[-2]['cumulative_cpu_s'],
    'carryMinusChargeApproxCpuS': carry['used_cpu_s'] - sums['charged_cpu_s'],
    'laterReadingMinusCarryNominalCpuS': lines[-2]['cumulative_cpu_s'] - carry['used_cpu_s'],
    'sumRoundedPerCallCgroupCpuS': sum(row['supervisor_this_call_rounded_cpu_s'] for row in rows),
    'carryScope': 'Baseline-adjusted cgroup interval saved after final child reap; not lifetime container CPU.',
    'wholeContainerOrWholeJobCpuS': None, 'buildGrantReportVerifierCpuS': None, 'totalDollars': None,
    'oldGateZeroCarryCpuSPreserved': Decimal('22.970797'),
    'oldGateZeroCurrentObservation': 'unchanged raw-file hash in retained host transcript; no old carry rewrite',
    'failedPresignReportLineBytePreserved': True,
    'failedPresignReportPrefixSha256': sha(presign_log),
    'beforeRunLogSha256': sha(before_log), 'beforeRunLogIncludesGrantEntry': True,
    'operatorLogEntries':len(lines),
    'invocations': exits, 'dockerDieEvents': die_events,
    'hostReadbackAt': '2026-11-01T11:40:26.767974910Z',
    'wrapperHashRetainedAndMatchesCurrentHostTranscript': wrapper_hash,
    'detachedRunLauncherSha256': sha(run_script),
    'hostProcessPidOrFullDescendantAuditProvided': False,
    'capturedLeftoverContainerCheck': 'none',
    'solverOrProducerCodeExecutedByReviewer': False, 'networkRequestsByReviewer':0,
    'numericalOutcomeReviewOwner':'root', 'noNewExecutionRelease':True,
}
selected = [p for p in (raw / 'invocations').iterdir() if p.is_file()]
selected += [raw / 'verification' / name for name in ['host-readback.txt','pregrant-state.txt','cpu-used.before.json','operator-log.before.jsonl']]
selected += [raw / name for name in ['RUN-RECEIPT.json','README.md','SHA256SUMS.txt']]
selected += list((raw / 'ledger').glob('*.json'))
selected += [raw / 'coupling' / name for name in ['cpu-used.json','operator-log.jsonl','presign-marker-20261101T105621Z.txt','presign-receipt.json','report-g1.json']]
selected += list((raw / 'coupling').glob('*/receipt.json'))
selected += list((raw / 'coupling').glob('*.stdout')) + list((raw / 'coupling').glob('*.stderr'))
bindings = []
for p in selected:
    rel = p.relative_to(raw); dst = here / 'evidence' / rel; dst.parent.mkdir(parents=True, exist_ok=True)
    b = p.read_bytes(); dst.write_bytes(b)
    bindings.append({'source':str(p),'copy':dst.relative_to(here).as_posix(),'bytes':len(b),'sha256':sha(b)})
source_dir = here / 'source'; source_dir.mkdir(exist_ok=True)
for name in ['gate0_operator.py','reference_validation.py','gate0_anchor.py']:
    original = task / 'coupling-presign-accounting-1120' / name
    b = original.read_bytes(); (source_dir/name).write_bytes(b)
    bindings.append({'source':str(original),'copy':'source/'+name,'bytes':len(b),'sha256':sha(b)})
(source_dir/'run_gate0.sh').write_bytes(wrapper_path.read_bytes())
bindings.append({'source':str(wrapper_path),'copy':'source/run_gate0.sh','bytes':wrapper_path.stat().st_size,'sha256':wrapper_hash})
dump(here / 'ACCOUNTING.json', result)
dump(here / 'EVIDENCE-INDEX.json', {'bindings':bindings,'packageChecksums':checksums,
    'postContainerCouplingHashes':host_coupling,'postContainerLedgerHashes':host_ledger})
print(json.dumps({'listedHashes':len(checksums),'couplingHostMatches':len(host_coupling),'ledgerHostMatches':len(host_ledger),
    'charges':str(sums['charged_cpu_s']),'solver':str(sums['solver_cpu_s']),'carry':str(carry['used_cpu_s']),
    'laterRounded':str(lines[-2]['cumulative_cpu_s']),'selectedFilesCopied':len(selected)}))
