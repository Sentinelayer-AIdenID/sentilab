#!/usr/bin/env bash
# SLAB-049 gate zero on the grant host (sl-mint): runs one operator subcommand inside the merged build's own image.
# usage: sudo bash run_gate0.sh <image-tag> <merged-build-sha40> <grant-id> grant|run|record|report [extra args...]
# The operator is the image's own module (sundai_hotspot.gate0_operator, merged in #75 at 5cedde11), so the code that
# enforces the cap is the reviewed code at the image's commit; no side-mounted copy. Every step uses the same absolute
# paths inside and outside the container, because the grant binds the ledger's directory. The container is limited to
# one CPU (concurrency 1) and its cgroup holds every process the calls start; the operator enforces the cumulative CPU
# cap from that cgroup's cpu.stat, kills on a failed meter read, and records unknown usage as unknown.
set -euo pipefail
IMAGE="$1"; BUILD="$2"; GRANT="$3"; CMD="$4"; shift 4
[[ "$BUILD" =~ ^[0-9a-f]{40}$ ]] || { echo "build sha must be 40 lowercase hex" >&2; exit 2; }
docker image inspect "$IMAGE" >/dev/null
EXTRA=()
case "$CMD" in
  grant|run) EXTRA=(--grant-id "$GRANT") ;;
  record) EXTRA=(--out "/srv/gate0/runs/RECORD-$(date -u +%Y%m%dT%H%M%SZ).json") ;;
  report) EXTRA=(--out "/srv/gate0/runs/REPORT-$(date -u +%Y%m%dT%H%M%SZ).json") ;;
  *) echo "unknown subcommand $CMD" >&2; exit 2 ;;
esac
exec docker run --rm --name "gate0-$CMD-$(date -u +%H%M%S)" \
  --cpus 1 --memory 6g --pids-limit 1024 \
  --env-file /srv/gate0/secrets.env \
  -e BUILD_SHA="$BUILD" -e PYTHONDONTWRITEBYTECODE=1 -e SLAB049_LEDGER_ROOT=/srv/gate0/ledger \
  -v /srv/gate0/ledger:/srv/gate0/ledger \
  -v /srv/gate0/key:/srv/gate0/key:ro \
  -v /srv/gate0/runs:/srv/gate0/runs \
  -w /app \
  "$IMAGE" python3 -m sundai_hotspot.gate0_operator "$CMD" "${EXTRA[@]}" "$@"
