"""Independent checks of retained authenticated GitHub GET responses; no producer execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json

OUT=Path(__file__).resolve().parent
TASK=OUT.parent
ZIPREVIEW=TASK/'coupling-run-g1-review-1150'
BASE=ZIPREVIEW/'files/slab049-run-g1'
sha=lambda b:hashlib.sha256(b).hexdigest()
tool=TASK/'coupling-postrun-review-1140/verify_ledger.py'
assert sha(tool.read_bytes())=='8088aca74f3b7361da0ca93dcbe124470114dfda4b20962f5acba728325aa7d6'
spec=importlib.util.spec_from_file_location('reviewer_ledger',tool)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
read=lambda p:v.parse(p.read_bytes())
checks=[]
def check(name,ok):
    checks.append({'check':name,'passed':bool(ok)})
    if not ok:raise ValueError(name)

sealraw=(ZIPREVIEW/'SEAL.json').read_bytes()
check('earlier ZIP review seal unchanged',sha(sealraw)=='e8001fad4205130e9102cc2885e5fc951d94f5bc2f512eba38324629f7e314fa')
seal=v.parse(sealraw)
check('all151 sealed ZIP-review files unchanged',len(seal['files'])==151 and all(
    (ZIPREVIEW/r['path']).stat().st_size==r['bytes'] and sha((ZIPREVIEW/r['path']).read_bytes())==r['sha256'] for r in seal['files']))
cap=read(OUT/'CAPTURE.json')
check('exact32 successful bounded GETs',cap['actualRequests']==32 and cap['retries']==0 and all(r['status']==200 and r['identityMatches'] for r in cap['requests']))
refs={};commits={}
for row in cap['requests']:
    name=row['name'];h=(OUT/(name+'.http')).read_bytes();b=(OUT/(name+'.json')).read_bytes()
    check('retained response hashes '+name,sha(h)==row['httpSha256'] and sha(b)==row['jsonSha256'] and len(h)==row['httpBytes'] and len(b)==row['jsonBytes'])
    r=v.parse(b)
    if row['kind']=='ref':
        check('exact ref identity '+row['ref'],r['ref']==row['ref'] and r['object']['type']=='commit' and r['object']['sha']==row['id'])
        refs[row['ref']]=r
    else:
        check('exact commit identity '+row['id'],r['sha']==row['id'])
        commits[row['id']]=r
check('sixteen unique refs and objects',len(refs)==len(commits)==16)
ledger=[read(BASE/'ledger'/f'{i:06d}.json') for i in range(9)]
grant=ledger[0]['grant'];gid=grant['grant_id'];prefix='refs/tags/gate0-'+gid+'/'
expected_refs={prefix+f'admit-{i:02d}' for i in range(1,5)}|{prefix+k+'-'+cid for cid in v.CALLS for k in ('reserve','launch','settle')}
check('no extra or missing authorization anchor refs',set(refs)==expected_refs)
messages=[];reconstructed=[];prior_admit=None
for i,cid in enumerate(v.CALLS):
    reserve=refs[prefix+'reserve-'+cid]['object']['sha']
    admit=refs[prefix+f'admit-{i+1:02d}']['object']['sha']
    launch=refs[prefix+'launch-'+cid]['object']['sha']
    settle=refs[prefix+'settle-'+cid]['object']['sha']
    reservation,settlement=ledger[2*i+1:2*i+3]
    admission=reservation['admission']
    check('signed admission/claim commit identities '+cid,admit==admission['commit_sha'] and launch==settlement['claim']['commit_sha'])
    receipt_path=BASE/'coupling'/Path(reservation['out']).name/'receipt.json'
    raw_receipt=receipt_path.read_bytes();receipt=v.parse(raw_receipt)
    check('settlement still binds actual receipt bytes '+cid,sha(raw_receipt)==settlement['receipt_sha256'])
    common={'schema':'sentilab-slab049-gate0-tag-v1','grant_id':gid,'manifest_sha256':v.MANIFEST,'call':cid}
    expects={
      'reserve':(reserve,{**common,'kind':'reserve'},[v.SOURCE]),
      'admit':(admit,{**common,'kind':'admit','seq':i+1,'envelope_cpu_s':58.5,'total_cpu_s':58.5*(i+1),'previous_sha':prior_admit},[prior_admit or reserve]),
      'launch':(launch,{**common,'kind':'launch','reservation_sha256':sha(v.canon(reservation))},[reserve]),
      'settle':(settle,{**common,'kind':'settle','status':settlement['status'],'receipt_sha256':sha(raw_receipt),
          'outputs':receipt['outputs'],'charged_cpu_s':settlement['charged_cpu_s']},[launch])}
    for kind,(commit_id,expected,parents) in expects.items():
        obj=commits[commit_id];msg=v.parse(obj['message'])
        check('exact closed message fields/values '+kind+' '+cid,msg==expected)
        check('canonical message bytes '+kind+' '+cid,obj['message'].encode()==v.canon(expected))
        check('exact source tree '+kind+' '+cid,obj['tree']['sha']==v.TREE)
        check('exact parent chain '+kind+' '+cid,[r['sha'] for r in obj['parents']]==parents)
        check('Git signature status preserved '+kind+' '+cid,obj['verification']['verified'] is False and obj['verification']['reason']=='unsigned')
        # GitHub Git-data commits here have UTC identities and no extra signed headers.
        # Try the two explicit message-final-LF possibilities, accepting only a SHA1 match.
        headers='tree '+obj['tree']['sha']+'\n'+''.join('parent '+p+'\n' for p in parents)
        for key in ('author','committer'):
            who=obj[key];epoch=int(v.utc(who['date']).timestamp())
            headers+=f"{key} {who['name']} <{who['email']}> {epoch} +0000\n"
        candidates=[]
        for suffix in ('','\n'):
            payload=(headers+'\n'+obj['message']+suffix).encode('utf-8')
            computed=hashlib.sha1(b'commit '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
            if computed==commit_id:candidates.append({'finalMessageLf':bool(suffix),'payloadBytes':len(payload),'gitObjectSha1':computed})
        check('reconstructed Git object identity '+kind+' '+cid,len(candidates)==1)
        reconstructed.append({'kind':kind,'call':cid,**candidates[0]})
        messages.append({'kind':kind,'call':cid,'commit':commit_id,'tree':obj['tree']['sha'],'parents':parents,
                         'canonicalMessageSha256':sha(v.canon(expected)),'message':expected,
                         'authorDate':obj['author']['date'],'committerDate':obj['committer']['date']})
    prior_admit=admit

result={'at':datetime.now(timezone.utc).isoformat(),'checksPassed':len(checks),'checks':checks,'requests':32,
 'refsVerified':16,'commitObjectsVerified':16,'gitObjectsReconstructed':len(reconstructed),
 'allSourceTreesEqual':v.TREE,'sourceParentCommit':v.SOURCE,'grantId':gid,'manifestSha256':v.MANIFEST,
 'messages':messages,'reconstructed':reconstructed,
 'closures':['all sixteen exact live ref identities match the retained ZIP listing','canonical grant/call/admission/launch/settle messages match signed ledger and raw receipts','reserve/admit/launch/settle parent relationships verified','all anchors point to the accepted source tree'],
 'scope':'Authenticated current GitHub GET evidence and local inert byte/hash verification. Git commits are unsigned; separate operator Ed25519 ledger/receipt signatures were verified in the sealed ZIP review. Commit dates are Git metadata, not independent solver-start timestamps.',
 'producerCodeExecuted':False,'newGrantOrSignatureIssued':False,'modelsSolversBuilds':0,'artifactRedownloads':0}
with (OUT/'ANCHORS-VERIFIED.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checksPassed':len(checks),'refsVerified':16,'commitObjectsVerified':16,'gitObjectsReconstructed':len(reconstructed)},indent=2))
