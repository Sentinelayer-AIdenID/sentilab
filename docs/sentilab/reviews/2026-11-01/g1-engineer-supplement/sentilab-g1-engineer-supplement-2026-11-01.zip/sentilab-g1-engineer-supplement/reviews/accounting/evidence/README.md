# SLAB-049 coupling run, grant slab049-coupling-g1-20261101 (sl-mint, 2026-11-01)

- Executed under warden's GO. Root's pre-sign +1 was at 11:27Z (action a94a4a45).
- Exactly four calls ran, once each, in manifest order: concurrency 1, no retries, no extra calls.
- `RUN-RECEIPT.json` is the run receipt. It covers:
  - signed entry 0 and its hashes, plus the verification done before the run;
  - the invocations, with environment variable names only;
  - the timeline;
  - the terminal ledger and CPU reconciliation;
  - per-call file hashes and tags;
  - the evaluation, the report hash, and the outcome wording.
- `ledger/` is the terminal signed ledger: 9 entries, head `30b96f2b...`.
- `coupling/` is `/srv/gate0/runs/coupling` after the report. It holds:
  - the four call directories, each with `sample.steady`, `sample.grid.steady`, `stdout.txt`, `stderr.txt` and `receipt.json`;
  - the supervisor sidecars;
  - `cpu-used.json` after the run;
  - `operator-log.jsonl`, with the pre-sign failed-report line kept as it was;
  - `report-g1.json`;
  - the pre-sign marker and receipt.
- `invocations/` holds the exact grant, run and report commands, their stdout, stderr and exit codes, and t0/t1 times.
- `verification/` holds:
  - the entry-0 verifier and its output (PASS);
  - the independent post-run verifier and its output (PASS);
  - the pre-grant state;
  - `cpu-used.json` and the operator log as they were before the run;
  - the host readback, including dockerd die events with each container's image digest and exit code;
  - the remote tag listings from before the grant and after the run;
  - the receipt builder.

Outcome: MEETS. The mechanical verdict is PASS.
- Ascend 910: 2233/2397, floor 93%.
- CPU-DRAM: 10715/11674, floor 91%.
- Both replays are byte-identical on all four files.

The packet contains no keys and no secret values.
