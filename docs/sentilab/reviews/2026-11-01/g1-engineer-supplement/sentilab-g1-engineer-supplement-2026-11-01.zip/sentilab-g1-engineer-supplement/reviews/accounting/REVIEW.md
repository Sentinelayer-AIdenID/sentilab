# Coupling g1 accounting, persistence, and launcher review

Scoped +1 for the four-call accounting and retained storage evidence, with one required wording correction: the persisted carry is a baseline-adjusted monitored cgroup interval, not the container's whole lifetime CPU. That correction does not reject the thermal result or require a new run.

Review performed by `/root/web714_720_review` using local parsing and hashing only. Producer scripts and native workloads were not executed. Root owns numerical/replay acceptance; `api_batch_review` owns signatures, anchors, and sole packet retrieval.

## Packet and identity

- Raw ZIP: 706,172 bytes; SHA256 `5d87a5fe795d6c45aa1d93f304892d729d083a932f1c3fc6660618282b93c3a2` (extractor receipt).
- Shared raw root: `../coupling-run-g1-review-1150/files/slab049-run-g1`.
- This lane independently verified all 129 listed payload hashes. The packet also contains its checksum list, for 130 files total.
- `RUN-RECEIPT.json`: 36,997 bytes; SHA256 `6a2a4ac9e60a1d5b98a48c701d1c82333c0e31bd5f06a4d2b89fe5ac533dbb5b`.
- Grant `slab049-coupling-g1-20261101`; manifest `9f9febcb43d0c1b967bf6e45ff883121e49d593453a009bab38675c9ccf5afdd`.
- Source `3f998f7cfea3f55eec9267b03ff6e2ad207af72b`, tree `8dfa9e889b316da745c71a453daf5d42e388d120`.
- Image `sentilab-gate0@sha256:da4700ffdb56a55aa60ee7a4c845a4dbe08f90a1d15cb48d26299abcda597c18`; binary `6ea3b7813412c13d20c92adc6449fbc0bc87c46b521d4d5eaf80b8abc7900609`.
- Warden's authenticated announcement: source `2104237a-e8eb-4368-b51e-fea2b0811f17`, server time `2026-11-01T11:47:02.801Z`, retained record SHA256 `2213dda3a715dcb402d3e13be574db184b20c8b83283bdbebe30c01ec22d55ce`. Its private retrieval URL is not copied here.

## Accounting

Call order is Ascend primary/replay, then CPU-DRAM primary/replay (historical file identifier `micro150`). All four settlements say `exited`, exit 0; each receipt hash and accounting field matches its ledger settlement. All overshoot fields are zero.

| Call | Charged CPU-s, raw numeric lexeme | Solver CPU-s, raw numeric lexeme |
| --- | ---: | ---: |
| Ascend primary | 3.4857609999999997 | 3.288866 |
| Ascend replay | 3.7223019999999996 | 3.4175709999999997 |
| CPU-DRAM primary | 3.5071890000000003 | 3.2735290000000004 |
| CPU-DRAM replay | 3.606379 | 3.2727939999999998 |

Decimal sums from the raw lexemes are charged `14.3216309999999996` (14.321631 CPU-s at six places), solver `13.2527599999999999` (13.252760), children `13.4115809999999996`, and self `0.910050`. Each charge agrees with children plus self within the floating-point serialization residual.

Each admission consumes 58.5 CPU-s. Recorded cumulative envelopes are 58.5, 117, 175.5, and 234; every `late` flag is false. The full **234 CPU-s admission allocation remains consumed, with no refund**. `gate0_anchor.py:418` takes the maximum of each envelope and available measured charges; low measured use does not make another call available.

Keep these three scopes separate:

1. Validation receipt charges: **14.321631 CPU-s**.
2. Persisted carry: **15.093926 CPU-s**, written at `11:38:36Z`.
3. Later `run_complete` reading: **15.107 CPU-s**, rounded to three places and logged at `11:38:37Z`.

The source initializes `budget.carried` by subtracting the current cgroup reading after startup, key/ledger checks and build-tree retrieval (`gate0_operator.py:425`). It persists the adjusted cumulative reading after each final child reap (`:389`, via `save_cpu` at `:159`), before subsequent tag/log work. The later `run_complete` read (`:485`) is not saved again. Thus neither the saved 15.093926 nor the later 15.107 is a whole-lifetime container/job measurement.

Carry minus validation charges is approximately 0.772295 CPU-s. The later rounded reading exceeds carry by about 0.013 CPU-s; the nominal subtraction is 0.013074, without that many justified significant figures. The per-call supervisor readings are separately rounded 3.636, 3.875, 3.662, 3.765 (sum of rounded values 14.938), while settled cumulative readings are 3.672, 7.587, 11.289, 15.094.

Required correction to `RUN-RECEIPT.json`'s explanatory note: replace “the supervisor container's whole cgroup CPU” with “the persisted baseline-adjusted cgroup interval after the final child reap; later run completion logged 15.107 CPU-s rounded.” Preserve the original packet and append the correction.

Build/native smoke/test, grant/report/verifier/launcher CPU, unmeasured startup/tail, and dollar totals remain separate and unquantified here. The prior build's eight native probes and original build exit 1 / cached probe exit 0 remain historical records; none is retroactively charged to this 234 allocation or declared free. The old gate-zero carry **22.970797 CPU-s** remains separate.

## Persistence

At the host readback's `2026-11-01T11:40:26.767974910Z` snapshot, all **81 coupling-file hashes and all 9 ledger-file hashes** exactly match the extracted files. This includes every retained result, receipt, sidecar, carry, operator log, marker, and report. `report-g1.json` hashes to `5b0f81ff4a7f057ebee11225f047945b08fa553523423255110b495954e2f0ba`.

The carry before run is the exact zero object `{"used_cpu_s": 0}`; the post-run object retains 15.093926. The operator log has 12 records: the failed pre-sign report; grant opened; four reservation/settlement pairs; run complete; successful report. The original failed-report prefix retains SHA256 `5271ada5d180ff737c7d02834ecf43bdd97caef11edc10b379f91dbe2ac3b3b9`. The before-run log also includes the grant entry (SHA256 `19ebd98476b77f43c3f20395b57727854de747a199b68f10aa5987c802ae6186`); it is an exact prefix of the final log. The final log is 3,735 bytes, SHA256 `cec0214010504c4f54aff6ec59d4601332d9f9ee5b0d4289aad0086cd84c3975`.

The pre-sign marker and receipt remain exact. The host transcript records the old gate-zero carry's unchanged SHA256 `3f57633b77964346b3f1f317fb23c6e981c04098f6ead2b653de38b7e56bbff5`, its 25-entry ledger, and both old/new ledger directories. This is retained host-readback evidence, not an independent live host inspection.

## Launcher and process scope

The retained wrapper is 1,780 bytes, SHA256 `a56be0d63617a073d217559a348244a4d9aeba1e74c298ae2788258ddd944b97`; the pregrant host readback records that same hash, mode 555, and mtime `03:05:47.777620857Z`. It uses the pinned image's `/app` operator, one CPU, 6 GiB memory, 1,024 PID limit, writable runs/ledger mounts and a read-only key mount. The ZIP does not contain a freshly retrieved wrapper file; this comparison uses the earlier retained exact wrapper plus current hash observation.

The new host launcher `invocations/run-g1.sh` hashes to `f90d356470c5a910f077dd0c8880159bc67febbd91eef4de8dcca3e52488e442`. It invokes the unchanged wrapper once with the pinned image/source/grant and `run --manifest coupling`, retains stdout/stderr, immediately captures `EXIT=$?`, and writes start/end times. It adds no solver flags or retry loop. Warden reports the host launch used `nohup setsid` to survive SSH loss; the packet supports launcher bytes and container exit observations, but does not provide a complete host PID/descendant audit.

Grant, run and report all retain exit 0 and empty invocation stderr. Their recorded intervals are respectively `11:37:13.067982533Z–11:37:13.923358643Z`, `11:37:48.456027479Z–11:38:37.720022297Z`, and `11:38:55.142473098Z–11:39:05.092806150Z`. Five captured dockerd die events (grant, entry-0 verifier, run, report, postrun verifier) all identify the pinned image and exit 0. The report explicitly selects the fresh coupling `report-g1.json` path. At the captured readback, leftover session containers are `none`; unrelated door-scorer remains `running init=true`, start `08:19:36.041227276Z`.

## Verification record

`check_accounting.py` is reviewer-authored and imports only Python standard-library parsing/hashing utilities. It verifies packet hashes, post-container file matches, ledger/receipt accounting, order, admission totals, history preservation, invocation evidence and source-copy bindings. `ACCOUNTING.json` preserves exact decimal strings; `EVIDENCE-INDEX.json` binds evidence copies to original paths, sizes and SHA256 values. The initial reviewer assertion incorrectly treated the two-line before-run log as the one-line pre-sign snapshot; correcting that assumption preserved and verified both historical prefixes. No packet bytes changed.

This report grants no new execution, source merge, physical-accuracy, whole-job cost, or complete host-process claim. Numerical acceptance and cryptographic identity conclusions are supplied by their separate review owners.
