#!/bin/bash
E=/srv/gate0/image/run-g1-3f998f7c
date -u +%Y-%m-%dT%H:%M:%S.%NZ > $E/run.t0
bash /srv/gate0/operator/run_gate0.sh sentilab-gate0@sha256:da4700ffdb56a55aa60ee7a4c845a4dbe08f90a1d15cb48d26299abcda597c18 3f998f7cfea3f55eec9267b03ff6e2ad207af72b slab049-coupling-g1-20261101 run --manifest coupling > $E/run.stdout 2> $E/run.stderr
echo "EXIT=$?" > $E/run.exit
date -u +%Y-%m-%dT%H:%M:%S.%NZ > $E/run.t1
