# Independent review of the coupling ledger reviewer

**Scoped reviewer-tool +1** for `verify_ledger.py` SHA-256 `8088aca74f3b7361da0ca93dcbe124470114dfda4b20962f5acba728325aa7d6` (15,795 bytes), bound by final `READY.json` `9b51511591f25140a64f3d0357f896c704a9ab32d1a0fe9bf2cd51c25096ff91`. No remaining blocking finding in this tool's stated ledger-identity/order scope. This approval neither authenticates an actual coupling packet nor adds a scientific grant or execution.

## Finding and closure

The initial script `c2488b1742814a010f150eca01d4dc3dce9da38e4f1a0b1d02bf68da555a23e7` allowed punctuation at the start of a grant ID. Its `check_grant` accepted `.leading`, `-leading`, `_leading` and `.` in schema-only controls, including when `expected_grant_id` matched. The pinned producer's `gate0_anchor._GRANT_ID` requires the first character to be alphanumeric. This was a narrow reviewer strictness defect, not a scientific pre-sign blocker.

The author corrected the pattern to `[A-Za-z0-9][A-Za-z0-9._-]{0,63}` at line 110. This lane independently verified that the entire script differs by exactly that one pattern substitution. Nine malformed IDs now refuse and five valid/boundary IDs pass schema validation. These fixtures are unsigned in-memory dictionaries; no actual grant or new signature was created. Initial script/READY/control bytes remain retained here, and the author's history also preserves the old readiness files.

## Checked behavior

The Ed25519 signature covers canonical JSON of the unsigned body. The chain digest covers canonical JSON of the signed entry. Raw file hashes remain separate, including signed-receipt byte digests. Canonical serialization matches the producer's sorted, compact, ASCII-escaped, non-NaN domain. This lane independently reverified all 25 retained historical ledger signatures and 12 receipt signatures, plus the historical chain; modified bodies and the raw-file signature domain were rejected. No historical or producer module was imported or executed.

The strict parser rejects nested and escaped duplicate members, NaN/infinity, overflow to nonfinite values, Boolean CPU fields and unknown/missing schema fields. Sequence numbers and the late flag use exact types. The production verification path explicitly validates signature encoding before calling the copied primitive, so disabling assertions does not disable its input checks. Five focused controls also refused under Python `-O`.

The accepted manifest and pre-sign receipt are byte-pinned before their nested values are used. The grant requires exactly the sorted four-call authorization set, finite 234 CPU-s cap, canonical operator ledger directory and unchanged deadline. Optional authenticated grant-ID and approval-time bindings work; supply them for the actual packet. The ordered manifest prefix, admission indices/balances, signature chain and signed timing are checked independently of the sorted authorization set. Unknown or missing ledger-entry fields refuse rather than being silently ignored.

The return stages `grant_only`, `partial_ledger` and `four_settlements_present` correctly describe entry presence, not success. Missing settlements remain explicit; four settlements may include failures. The result never marks tags/receipts/raw outputs verified, numerical acceptance true, or aggregate accounting recomputed. Successful-looking signed settlements require their stated output hashes, receipt hash and launch claim, but those claims still need the separately assigned raw/tag checks. Unsupported raw or producer claims cannot silently become numerical acceptance through this output.

The tool reads evidence without modification. It caps ledger/manifest file reads, rejects leaf symlink/nonregular inputs, requires a contiguous numbered ledger prefix and permits only the producer's optional `.lock` beside it. Output is opened exclusively, must not already exist and must resolve outside the captured ledger. Independent checks confirmed that an existing output remained byte-identical, a proposed output within the ledger was not created, and bad input produced no result file.

## Evidence and limits of this review

`CHECKS.json` retains 25 independent helper/crypto/path controls (24 refusals and one valid shape), 37 historical signature verifications and the original grant-ID finding. `OPTIMIZED-CHECKS.json` retains five assertion-disabled refusals. `FIX-VERIFIED.json` retains the exact one-pattern delta and nine negative/five positive ID controls. Original and corrected tool/README/READY bytes are stored separately with bindings.

No actual coupling grant or post-run packet was used. Full coupling ledger branches still run only when the assigned actual packet arrives. This review inspected their source and partial-stage logic; it did not manufacture signed coupling data to claim an end-to-end acceptance. Operator host/image identity, raw output validity, tags, numerical predicates and complete cost accounting remain their existing review scopes. No network, model, solver or build was executed, no private signing material was read, and no historical evidence was edited.
