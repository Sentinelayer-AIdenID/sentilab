"""Runs only the exact reviewer numerical parser in temporary isolated layout, never producer code."""
from pathlib import Path
import json, subprocess, sys, tempfile
sys.dont_write_bytecode = True
import verify_bytes as v

root = Path(__file__).resolve().parents[1]
v.verify(root)
pins = v.parse((root/'PINS.json').read_bytes())
raw = v.raw_members(root/pins['originalZip']['path'], pins['originalZip'])
script = (root/'reviews/numerics/check_raw.py').read_bytes()
v.require(v.sha(script) == '9d16175d836da34a9cb45ca557a02719d7b8b96e7444f4769030347e6d70710e', 'reviewer parser identity')
with tempfile.TemporaryDirectory(prefix='sentilab-g1-offline-review-') as scratch:
    task = Path(scratch)
    for name, data in raw.items():
        p = task/'coupling-run-g1-review-1150/files'/name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    numeric = task/'coupling-numerical-review-1153'
    numeric.mkdir()
    (numeric/'check_raw.py').write_bytes(script)
    done = subprocess.run([sys.executable,'-I',str(numeric/'check_raw.py')],cwd=numeric,capture_output=True,text=True,timeout=60)
    v.require(done.returncode == 0, 'reviewer parser failed: '+done.stderr)
    expected = v.parse((root/'reviews/numerics/RESULT.json').read_bytes())
    result = v.parse((numeric/'RESULT.json').read_bytes())
    fields = ('results','checks','passed','report_sha256','receipt_sha256','source_sha256','scope','schema')
    for field in fields: v.require(result[field] == expected[field], 'numerical output difference: '+field)
    print(json.dumps({'result':'PASS','reviewerChecksReproduced':result['passed'],
                     'retainedResultFieldsExactlyEqual':list(fields),
                     'onlyExcludedField':'packet absolute temporary path',
                     'producerCodeExecuted':False,'newSolves':0,'networkRequests':0},indent=2))
