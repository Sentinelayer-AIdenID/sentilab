"""Independent inert SLAB-049 coupling grant/ledger verifier; never imports producer code.

sha/canon/unique/signed are copied from the reviewed historical verifier d811674e...
Only those pure primitives are reused. No historical module is imported/executed.
This checks captured ledger identity/order, not output numerics, tags or accounting totals.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import re
import sys
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

MANIFEST = '9f9febcb43d0c1b967bf6e45ff883121e49d593453a009bab38675c9ccf5afdd'
KEY = 'aedce64bbc007b3538c02d302da9cedbce1465c409efac8589477284bdbd2132'
SOURCE = '3f998f7cfea3f55eec9267b03ff6e2ad207af72b'
TREE = '8dfa9e889b316da745c71a453daf5d42e388d120'
IMAGE = 'sentilab-gate0@sha256:da4700ffdb56a55aa60ee7a4c845a4dbe08f90a1d15cb48d26299abcda597c18'
BINARY = '6ea3b7813412c13d20c92adc6449fbc0bc87c46b521d4d5eaf80b8abc7900609'
PRESIGN = '8def0dfaf2a37de03218b909af8e8faebad220051a5ac1b2586d1bfb084f0625'
DEADLINE = '2026-11-02T06:00:00Z'
CALLS = [
 'p-hs7material-ascend910-tap25d-fig6a-raw-g64',
 'r-hs7material-ascend910-tap25d-fig6a-raw-g64',
 'p-hs7material-micro150-tap25d-fig5a-raw-g64',
 'r-hs7material-micro150-tap25d-fig5a-raw-g64']
PUBLIC = Ed25519PublicKey.from_public_bytes(bytes.fromhex(KEY))

def sha(data): return hashlib.sha256(data).hexdigest()
def canon(obj): return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('utf8')
def unique(pairs):
    obj = {}
    for key, value in pairs:
        assert key not in obj, ('duplicate JSON key', key)
        obj[key] = value
    return obj
def signed(obj):
    assert len(obj['signature']) == 128
    body = {k:v for k,v in obj.items() if k != 'signature'}
    PUBLIC.verify(bytes.fromhex(obj['signature']), canon(body))
    return body

def require(ok, message):
    if not ok:
        raise ValueError(message)

def strict_pairs(pairs):
    # Keep the copied primitive unchanged but do not rely on assertions (-O).
    require(len({k for k, _ in pairs}) == len(pairs), 'duplicate JSON member')
    return unique(pairs)

def reject_constant(value):
    raise ValueError('nonfinite JSON constant: '+value)

def finite_tree(value):
    if isinstance(value, float):
        require(math.isfinite(value), 'nonfinite numeric field')
    elif isinstance(value, dict):
        for item in value.values(): finite_tree(item)
    elif isinstance(value, list):
        for item in value: finite_tree(item)

def parse(raw):
    value = json.loads(raw, object_pairs_hook=strict_pairs, parse_constant=reject_constant)
    finite_tree(value)
    return value

def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'input is not a regular, non-symlink file')
    require(path.stat().st_size <= 2_000_000, 'input exceeds 2 MB ledger/manifest cap')
    raw = path.read_bytes()
    return raw, parse(raw)

def fields(value, expected, label):
    require(isinstance(value, dict), label+' must be an object')
    require(set(value) == set(expected.split()), label+' has unknown or missing fields')

def number(value, label, nullable=False):
    if nullable and value is None: return
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, label+' must be finite nonnegative numeric')

def digest(value, length=64):
    require(isinstance(value, str) and re.fullmatch('[0-9a-f]{'+str(length)+'}', value) is not None, 'invalid hexadecimal digest')

def utc(value):
    require(isinstance(value, str), 'timestamp must be a string')
    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(dt.tzinfo is not None and dt.utcoffset().total_seconds() == 0, 'timestamp must carry UTC offset')
    return dt

BASE = 'schema seq prev_sha256 kind manifest_sha256 call signature'
GRANT_FIELDS = 'schema grant_id manifest_sha256 calls not_before_utc not_after_utc cpu_cap_s ledger_dir'
ADMISSION_FIELDS = 'ref seq commit_sha envelope_cpu_s total_cpu_s charged_before_cpu_s checked_utc created_utc late'
SETTLE_FIELDS = ('out reserved_cpu_s status exit_status started_utc finished_utc wall_s solver_cpu_s '
 'children_cpu_s self_cpu_s charged_cpu_s overshoot_cpu_s outputs error receipt_error claim receipt_sha256 cpu_baseline')
STATUSES = {'exited','window_closed','runtime_refused','wall_timeout','cpu_limit','signalled','runtime_changed',
 'claim_refused','claim_uncertain','claim_unavailable','stage_error','setup_error','precheck_error','launch_error','error','record_error'}
OUTPUTS = {'sample.steady','sample.grid.steady','stdout.txt','stderr.txt'}

def check_grant(entry, expected_grant_id=None, approved_at=None):
    fields(entry, BASE+' grant', 'grant entry')
    grant = entry['grant']
    fields(grant, GRANT_FIELDS, 'grant')
    require(grant['schema'] == 'sentilab-slab049-grant-v1', 'unknown grant schema')
    require(grant['manifest_sha256'] == MANIFEST, 'wrong grant manifest')
    require(isinstance(grant['grant_id'],str) and re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]{0,63}',grant['grant_id']), 'invalid dynamic grant ID')
    if expected_grant_id is not None:
        require(grant['grant_id'] == expected_grant_id, 'grant ID differs from authenticated expected ID')
    require(grant['calls'] == sorted(CALLS), 'grant must contain the exact sorted authorization set')
    number(grant['cpu_cap_s'],'grant cap')
    require(grant['cpu_cap_s'] == 234, 'wrong grant cap')
    require(grant['ledger_dir'] == '/srv/gate0/ledger/slab049-'+MANIFEST, 'wrong canonical ledger directory')
    require(grant['not_after_utc'] == DEADLINE, 'changed grant deadline')
    opens, closes = utc(grant['not_before_utc']), utc(grant['not_after_utc'])
    require(opens < closes, 'empty/reversed grant window')
    if approved_at is not None:
        require(opens >= utc(approved_at), 'grant predates supplied root authorization time')
    require(entry['call'] is None, 'grant entry must have null call')
    return grant, opens, closes

def check_settlement(entry, reservation, grant_id):
    fields(entry, BASE+' '+SETTLE_FIELDS, 'settlement')
    require(entry['out'] == reservation['out'] and entry['reserved_cpu_s'] == 58.5, 'settlement reservation mismatch')
    require(entry['status'] in STATUSES, 'unknown terminal status')
    require(entry['exit_status'] is None or type(entry['exit_status']) is int, 'invalid exit status')
    for key in ('wall_s','solver_cpu_s','children_cpu_s','self_cpu_s','charged_cpu_s','overshoot_cpu_s'):
        number(entry[key], key, nullable=key=='solver_cpu_s')
    fields(entry['cpu_baseline'],'children_s self_s','CPU baseline')
    for value in entry['cpu_baseline'].values(): number(value, 'CPU baseline value')
    for key in ('error','receipt_error'):
        require(entry[key] is None or isinstance(entry[key],str), 'invalid '+key)
    require(isinstance(entry['outputs'],dict) and set(entry['outputs']) <= OUTPUTS, 'unknown output field')
    for value in entry['outputs'].values(): digest(value)
    if entry['receipt_sha256'] is not None: digest(entry['receipt_sha256'])
    if entry['claim'] is not None:
        fields(entry['claim'],'ref commit_sha','launch claim')
        digest(entry['claim']['commit_sha'],40)
        require(entry['claim']['ref'] == 'tags/gate0-'+grant_id+'/launch-'+entry['call'], 'wrong launch ref')
    if entry['status']=='exited' and entry['exit_status']==0:
        require(entry['claim'] is not None and entry['receipt_sha256'] is not None and entry['error'] is None
                and entry['receipt_error'] is None and set(entry['outputs']) == OUTPUTS, 'incomplete successful settlement')
    start, finish = utc(entry['started_utc']), utc(entry['finished_utc'])
    admission = reservation['admission']
    require(start <= utc(admission['checked_utc']) <= utc(admission['created_utc']) <= finish, 'signed call chronology mismatch')
    if admission['late']:
        require(entry['status']=='window_closed' and entry['claim'] is None, 'late admission claims execution')
    return start, finish

def verify(manifest_path, presign_path, ledger_dir, expected_grant_id=None, approved_at=None):
    mr, manifest = read(manifest_path)
    require(len(mr)==20834 and sha(mr)==MANIFEST, 'accepted manifest bytes changed')
    require(manifest['operator']['public_key_ed25519']==KEY and manifest['operator']['status']=='pinned', 'wrong key pin')
    require([c['id'] for c in manifest['calls']]==CALLS and all(c['binary_sha256']==BINARY for c in manifest['calls']), 'wrong manifest calls/binary')
    require(manifest['accounting']['manifest_cpu_cap_s']==234 and manifest['accounting']['concurrency']==1
            and manifest['accounting']['retries']==0, 'wrong manifest envelope')
    pr, presign = read(presign_path)
    require(sha(pr)==PRESIGN, 'accepted pre-sign receipt bytes changed')
    require(presign['source']['commit']==SOURCE and presign['source']['tree']==TREE
            and presign['image']['pinned_ref']==IMAGE and presign['pinned_request']['material_only_binary_sha256']==BINARY,
            'pre-sign source/image/binary mismatch')
    directory = Path(ledger_dir)
    require(directory.is_dir() and not directory.is_symlink() and directory.name=='slab049-'+MANIFEST, 'wrong local ledger directory')
    names = sorted(p.name for p in directory.iterdir())
    require(all(n=='.lock' or re.fullmatch('[0-9]{6}\\.json',n) for n in names), 'unknown ledger-directory entry')
    paths = sorted(directory.glob('*.json'))
    require(1 <= len(paths) <= 9 and [p.name for p in paths]==[f'{i:06d}.json' for i in range(len(paths))], 'noncontiguous/excess ledger entries')
    previous = None; grant = None; reservation = None; signatures = []; order = []; calls = []; prior_finish = None
    for seq,path in enumerate(paths):
        raw, entry = read(path)
        kind = 'grant' if seq==0 else 'reservation' if seq%2 else 'settlement'
        require(isinstance(entry,dict) and entry.get('kind')==kind, 'unexpected ledger kind/order')
        fields(entry, BASE+(' grant' if kind=='grant' else ' out reserved_cpu_s admission' if kind=='reservation' else ' '+SETTLE_FIELDS), kind)
        require(type(entry['seq']) is int and entry['seq']==seq and entry['prev_sha256']==previous, 'chain sequence/digest mismatch')
        require(entry['schema']=='sentilab-slab049-ledger-entry-v1' and entry['manifest_sha256']==MANIFEST, 'wrong entry schema/manifest')
        require(isinstance(entry['signature'],str) and re.fullmatch('[0-9a-f]{128}',entry['signature']), 'invalid signature encoding')
        signed(entry)
        if kind=='grant':
            grant, opens, closes = check_grant(entry,expected_grant_id,approved_at)
        else:
            index=(seq-1)//2
            require(entry['call']==CALLS[index], 'runtime sequence differs from ordered manifest prefix')
            if kind=='reservation':
                reservation=entry; admission=entry['admission']
                fields(admission,ADMISSION_FIELDS,'admission')
                require(type(admission['seq']) is int and admission['seq']==index+1, 'wrong admission index')
                digest(admission['commit_sha'],40)
                require(admission['ref']=='tags/gate0-'+grant['grant_id']+f'/admit-{index+1:02d}', 'wrong admission ref')
                for key in ('envelope_cpu_s','total_cpu_s','charged_before_cpu_s'): number(admission[key],key)
                require(entry['reserved_cpu_s']==admission['envelope_cpu_s']==58.5 and admission['total_cpu_s']==58.5*(index+1), 'wrong admission envelope')
                require(admission['charged_before_cpu_s']>=58.5*index and admission['charged_before_cpu_s']+58.5<=234, 'invalid signed admission balance')
                checked,created=utc(admission['checked_utc']),utc(admission['created_utc'])
                require(opens<=checked<=closes and checked<=created, 'admission checked outside window/order')
                require(type(admission['late']) is bool and admission['late']==(created>closes), 'late-admission flag mismatch')
                require(prior_finish is None or prior_finish<=checked, 'next admission overlaps prior signed settlement')
                out=PurePosixPath(entry['out'])
                require(out.parent==PurePosixPath('/srv/gate0/runs/coupling') and
                        re.fullmatch(re.escape(entry['call'])+'-[0-9]+',out.name), 'wrong coupling output directory')
                order.append(entry['call'])
            else:
                start,finish=check_settlement(entry,reservation,grant['grant_id'])
                require(prior_finish is None or prior_finish<=start, 'signed accounting intervals overlap')
                prior_finish=finish
                calls.append({'call':entry['call'],'status':entry['status'],'exit_status':entry['exit_status'],
                              'receiptRawSha256':entry['receipt_sha256'],'startedUtc':entry['started_utc'],'finishedUtc':entry['finished_utc']})
        previous=sha(canon(entry))
        signatures.append({'file':path.name,'rawFileSha256':sha(raw),'canonicalSignedSha256':previous,'signatureVerified':True})
    stage='grant_only' if len(paths)==1 else 'four_settlements_present' if len(paths)==9 else 'partial_ledger'
    return {'schema':'sentilab-independent-coupling-ledger-review/1','verifiedAt':datetime.now(timezone.utc).isoformat(),
      'stage':stage,'grantVerified':True,'grant':grant,'signatureCount':len(signatures),'signatures':signatures,
      'authorizationCallsSorted':grant['calls'],'observedReservationOrder':order,'signedRuntimeOrderMatchesManifestPrefix':True,
      'terminalCalls':calls,'missingSettlements':[c for c in CALLS if c not in {r['call'] for r in calls}],
      'pins':{'manifestSha256':MANIFEST,'publicKey':KEY,'sourceCommit':SOURCE,'sourceTree':TREE,'imageRef':IMAGE,'binarySha256':BINARY,'cpuCapS':234},
      'sourceImageScope':'Accepted pre-sign bytes pinned; no new post-run host/image attestation inferred.',
      'orderScope':'Signed ledger sequence and signed host timing only; not independent process-start attestation.',
      'hashDomains':'Signatures cover canonical unsigned body; chain covers canonical signed entry; receipt digests denote raw file bytes.',
      'postrunReceiptsAndTagsVerified':False,'numericalAcceptance':False,'accountingTotalsRecomputed':False,
      'grantIssued':False,'producerOrHistoricalCodeExecuted':False,'networkCalls':0}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--presign-receipt',type=Path,required=True)
    parser.add_argument('--ledger-dir',type=Path,required=True)
    parser.add_argument('--expected-grant-id')
    parser.add_argument('--approved-at',help='Authenticated root authorization time, UTC; optional stricter temporal binding')
    parser.add_argument('--out',type=Path,required=True,help='New result file; never overwritten')
    args=parser.parse_args()
    require(not args.out.exists(),'output already exists')
    require(not args.out.resolve().is_relative_to(args.ledger_dir.resolve()),'output must be outside captured ledger')
    result=verify(args.manifest,args.presign_receipt,args.ledger_dir,args.expected_grant_id,args.approved_at)
    with args.out.open('x',encoding='utf-8',newline='\n') as handle:
        handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'stage':result['stage'],'signatureCount':result['signatureCount'],'out':str(args.out)}))

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(json.dumps({'status':'REFUSED','type':type(exc).__name__,'reason':str(exc)}),file=sys.stderr)
        sys.exit(2)
