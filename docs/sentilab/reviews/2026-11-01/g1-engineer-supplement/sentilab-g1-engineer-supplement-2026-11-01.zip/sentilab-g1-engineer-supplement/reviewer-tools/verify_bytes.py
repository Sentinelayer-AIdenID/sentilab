"""Portable offline supplement integrity check. Reads bytes only; never imports evidence code."""
from pathlib import Path, PurePosixPath
import hashlib, json, re, stat, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
sha = lambda data: hashlib.sha256(data).hexdigest()

def require(ok, detail):
    if not ok: raise ValueError(detail)

def safe_name(name):
    p = PurePosixPath(name)
    require(bool(name) and p.as_posix() == name and not p.is_absolute() and
            not any(c in name for c in ('\\', ':', '\x00')) and
            not any(x in ('', '.', '..') for x in p.parts), 'unsafe relative path')
    return p

def unique(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

def parse(raw):
    def reject(value): raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject)

def raw_members(path, pins):
    blob = path.read_bytes()
    require(len(blob) == pins['bytes'] and sha(blob) == pins['sha256'], 'original ZIP identity')
    out = {}; seen = set(); total = 0
    with zipfile.ZipFile(path) as z:
        require(len(z.infolist()) == pins['files'], 'ZIP member count')
        for item in z.infolist():
            safe_name(item.filename)
            require(item.filename.startswith('slab049-run-g1/') and not item.is_dir(), 'ZIP root or directory')
            require(item.filename.casefold() not in seen, 'ZIP case or name alias')
            seen.add(item.filename.casefold())
            mode = item.external_attr >> 16
            require(not stat.S_ISLNK(mode) and not item.flag_bits & 1, 'ZIP link/encryption')
            require(item.file_size <= 5_000_000, 'ZIP member size')
            total += item.file_size
            require(total <= pins['expandedBytes'], 'ZIP expanded size')
            data = z.read(item)  # zipfile validates CRC on full read.
            require(len(data) == item.file_size, 'ZIP member length')
            out[item.filename] = data
    require(total == pins['expandedBytes'], 'ZIP total expanded size')
    checksums = out['slab049-run-g1/SHA256SUMS.txt'].decode('utf-8-sig').splitlines()
    listed = set()
    for line in checksums:
        m = re.fullmatch(r'([a-f0-9]{64}) [ *](.+)', line)
        require(m is not None, 'checksum syntax')
        relative = m[2].removeprefix('./'); safe_name(relative)
        name = 'slab049-run-g1/' + relative
        require(name not in listed and name in out and sha(out[name]) == m[1], 'payload checksum')
        listed.add(name)
    require(len(listed) == pins['checksumListedFiles'], 'checksum count')
    require(listed | {'slab049-run-g1/SHA256SUMS.txt'} == set(out), 'unlisted ZIP file')
    return out

def verify(root=ROOT):
    root = root.resolve()
    m = parse((root/'MANIFEST.json').read_bytes())
    require(m['schema'] == 'sentilab-g1-engineer-supplement/1', 'manifest schema')
    wanted = set(); folded = set()
    for row in m['files']:
        name = row['path']; safe_name(name)
        require(name not in wanted and name.casefold() not in folded and name != 'MANIFEST.json', 'manifest alias')
        wanted.add(name); folded.add(name.casefold())
        p = root/name
        require(not p.is_symlink() and p.resolve().is_relative_to(root), 'file confinement')
        data = p.read_bytes()
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'file identity: ' + name)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(actual == wanted | {'MANIFEST.json'}, 'missing or extra supplement files')
    pins = parse((root/'PINS.json').read_bytes())
    raw = raw_members(root/pins['originalZip']['path'], pins['originalZip'])
    for key in ('report', 'runReceipt'):
        row = pins[key]; data = raw[row['zipMember']]
        require(len(data) == row['bytes'] and sha(data) == row['sha256'], key + ' pin')
    row = pins['manifest']; b = (root/row['path']).read_bytes()
    require(len(b) == row['bytes'] and sha(b) == row['sha256'], 'accepted manifest pin')
    require(sha((root/'evidence/presign/provenance-baked.json').read_bytes()) == pins['provenanceSha256'], 'baked provenance pin')
    copies = parse((root/'SOURCE-COPIES.json').read_bytes())
    for row in copies['copies']:
        b = (root/row['path']).read_bytes()
        require(len(b) == row['bytes'] and sha(b) == row['sha256'], 'exact source copy')
    identity = parse((root/'reviews/identity/RECEIPTS-VERIFIED.json').read_bytes())
    require(identity['checksPassed'] == 421 and identity['totalVerifiedSignatures'] == 13, 'identity review count')
    require(all(x['passed'] for x in identity['checks']), 'identity review result')
    numerics = parse((root/'reviews/numerics/RESULT.json').read_bytes())
    require(numerics['passed'] == 151 and all(x['pass'] for x in numerics['checks']), 'numerical review result')
    anchors = parse((root/'reviews/anchors/ANCHORS-VERIFIED.json').read_bytes())
    require(anchors['checksPassed'] == 157 and all(x['passed'] for x in anchors['checks']), 'anchor review result')
    correction = parse((root/'CORRECTION-2026-11-01.json').read_bytes())
    require(correction['originalBytesPreserved'] and correction['consumedAdmissionCpuS'] == '234' and correction['refundCpuS'] == '0', 'preserved accounting scope')
    return {'schema':'sentilab-g1-supplement-byte-verification/1','result':'PASS',
            'supplementFilesVerified':len(wanted),'exactSourceCopiesVerified':len(copies['copies']),
            'originalZipMembersVerified':len(raw),'originalPayloadChecksumsVerified':129,
            'originalExpandedBytes':sum(map(len,raw.values())),
            'retainedReviewChecks':{'identity':421,'numerics':151,'anchors':157},
            'signaturesReexecutedByThisByteVerifier':False,'producerCodeExecuted':False,'networkRequests':0}

if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
