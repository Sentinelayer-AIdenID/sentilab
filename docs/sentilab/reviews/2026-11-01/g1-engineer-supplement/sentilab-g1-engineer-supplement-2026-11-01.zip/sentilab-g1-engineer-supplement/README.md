# SentiLab g1 engineer supplement

This packet supplements the accepted four-call SLAB-049 g1 diagnostic. It contains the unchanged original raw ZIP, the three independent review scopes, the additive GitHub anchor closure, exact pins, and a separately dated accounting correction. It is a focused supplement for the engineer handoff. The earlier engineer archive and frozen historical reports remain separate.

The retained diagnostic meets the exact frozen 17/20 predicate. Ascend 910 has native all-block maximum 78.76 C, fraction 2233/2397 and floor display 93%. CPU-DRAM has 125.52 C, fraction 10715/11674 and floor display 91%. Both primary/replay pairs match byte-for-byte on all four required output files. These statements describe the configured HotSpot material-only diagnostic; they do not establish physical accuracy, authors' intent or a general optimum. The historical `micro150` identifier in filenames refers to this CPU-DRAM reference.

## Start here

- `PINS.json` records exact source, tree, image, binary, provenance, manifest, grant, raw-packet and report identities, runtime order, result and cost envelope. `evidence/presign/accepted-manifest.json` supplies the exact full prospective contract.
- `reviews/identity/REVIEW.md` covers the nine ledger signatures, four receipt signatures and saved-byte/input bindings: 421 inert checks and 13 signatures. Its original missing-anchor boundary is closed additively by `reviews/anchors/REVIEW.md`: 32 authenticated GETs, 16 refs and 16 commit objects, with 157 inert checks. Git commits are unsigned; the operator Ed25519 signatures are a separate domain.
- `reviews/numerics/REVIEW.md`, `RESULT.json` and `check_raw.py` contain root's independent raw numerical/replay review: 151 checks, exact rational predicate, all eight grid layers with 4096 cells each, centre mappings and same-index stack values. Active grid peaks 78.77 C and 128.50 C are distinct from the frozen native all-block maximum.
- `reviews/accounting/REVIEW.md` and `ACCOUNTING.json` cover persistence, launcher evidence and CPU scopes. Its independent cross-check verifies 56 evidence bindings. The included original source copies are static evidence.
- `CORRECTION-2026-11-01.json` is the dated additive correction to the original receipt wording. Read it together with the unmodified receipt.

## CPU correction and preserved history

Validation charges sum to 14.3216309999999996 CPU-s (14.321631 at six places); native solver CPU sums to 13.2527599999999999 (13.252760). The persisted 15.093926 CPU-s is the baseline-adjusted cgroup interval after the final child reap at 11:38:36Z. The later run-completion reading is 15.107 CPU-s, rounded to three places, at 11:38:37Z. Neither is whole-lifetime container/job CPU. Build/native smoke/test, grant/report/verifier/launcher, startup/tails and dollars remain separate unquantified scopes.

The original phrase “the supervisor container's whole cgroup CPU” remains in the raw receipt as historical evidence. The separate correction supplies the accurate wording. The full 234 CPU-s admission allocation remains consumed, with zero refund or additional call availability. Old gate-zero carry 22.970797 CPU-s remains separate and unchanged. The pre-sign failed report, prior build exit 1 / cached probe exit 0 and eight native probes, reviewer input-layout refusals and optional raw-Git reconstruction refusal remain recorded. No prior failed work is erased or reclassified as free.

## Verify existing bytes offline

Use the externally supplied seal to compare the SHA256 of this ZIP and `MANIFEST.json` before running any included code. A hash received only inside the same untrusted archive is an integrity cross-check, not independent authentication.

Extract this outer supplement into a new directory. With an existing Python 3.11+ installation, run:

```text
python reviewer-tools/verify_bytes.py
python reviewer-tools/recheck_numerics.py
```

`verify_bytes.py` reads the manifest, all listed supplement files, exact source-copy bindings and the nested original ZIP. It checks confined paths, duplicate/case aliases, sizes, CRCs and all 129 payload checksums in memory. It does not extract or execute producer content, use the network, or reverify signatures. Its review counts describe the retained sealed review records.

`recheck_numerics.py` first performs those byte checks, then stages the exact raw ZIP in a temporary directory and runs only the pinned reviewer-authored `check_raw.py` in Python isolated mode. It requires all 151 checks and eight stable result fields to equal the retained result; the temporary absolute path is the only excluded field. It invokes no model, solver, producer helper, build, grant, signing or remote operation. It writes only disposable temporary files and leaves this packet unchanged.

The original reviewer scripts in the review folders are preserved byte-for-byte. Their original workspace paths and output expectations are evidence, not portable command recipes. `reviewer-tools/verify_ledger.py` is the previously independently approved reviewer CLI and needs the existing Python `cryptography` package; its approved original hash and audit report are included. It checks grant/ledger signatures, distinct from the receipt/numerical/accounting scopes. This supplement does not require installing dependencies or rerunning that CLI. The original producer `.sh`, `.py`, command files and the network capture `.cjs` are included solely as inert evidence; do not run them as verification steps.

## Package and provenance

`SOURCE-COPIES.json` binds every copied file to its original task-relative path, size and SHA256. All 288 entries in the four prior source seals were reverified before assembly. The complete accounting, anchor and numerical review folders are included; selected identity review files accompany the unchanged raw ZIP. Historical `SEAL.json` files retain their original coverage and are not this supplement's file inventory. In particular the identity seal references omitted private retrieval records and an earlier expanded layout. The numerical seal covers its original three core files; its later cross-lane seal index is separately copied and bound by this supplement manifest.

`MANIFEST.json` inventories every other file in the supplement without a self-hash cycle. The external seal records the manifest and ZIP identities plus final validation and scanning receipts. Gitleaks scanning uses the verified existing binary, explicit default rules, an empty ignore file, inline suppressions disabled and redacted output. The nested ZIP's 130 members are separately scanned after safe extraction for scanning only. See `SECRET-SCAN.json` for exact scope and results; the final scan is retained in the external validation directory.

No raw room actions or `source-record.json` retrieval records are included. Private URL query credentials are excluded. Ordinary original local paths, public keys, hashes and query-free source URLs remain as technical provenance. The original binary/image and complete source archive are pinned rather than repackaged. Baked BUILD_SHA was `unknown`, with runtime injection of the source label; source/image binding is based on the retained manifest and evidence, not that label alone.

This supplement issues no execution grant. It authorizes no new solve, retry, model call, publication, upload or replacement of the original archive.
